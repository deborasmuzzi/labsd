library ieee;
use ieee.std_logic_1164.all;

-- Entity declaration
entity tb_coin_detector is
end tb_coin_detector;

-- Architecture declaration
architecture test of tb_coin_detector is

	-- Component declaration
	component coin_detector is
		port(
			a2, a1, a0 : in std_logic;
			c          : out std_logic
		);
	end component;

	signal pin_a2, pin_a1, pin_a0, pin_c : std_logic;

begin

	-- Instantiate the design under test
	dut: coin_detector
		port map(
			a2 => pin_a2,
			a1 => pin_a1,
			a0 => pin_a0,
			c  => pin_c
			);

	-- Stimulus generation
	pin_a2 <= '0', '1' after 400 ns;
	pin_a1 <= '0', '1' after 200 ns, '0' after 400 ns, '1' after 600 ns;
	pin_a0 <= '0', '1' after 100 ns, '0' after 200 ns, '1' after 300 ns, '0' after 400 ns, '1' after 500 ns,
             '0' after 600 ns, '1' after 700 ns;

end test;