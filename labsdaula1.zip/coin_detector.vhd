library ieee;
use ieee.std_logic_1164.all;

-- Description: The detector validates R$ 0,25, R$ 0,50 and R$ 1,00 coins.
-- They are represented by the following combinations:
--
--             INPUTS           OUTPUT
--      a2      a1      a0      c (Coin)
--      0       0       0       0 (None)
--      0       0       1       1 (R$0,25)
--      0       1       0       1 (R$0,50)
--      1       0       0       1 (R$1,00)
--
-- The system flags a valid coin (c = 1) whenever a R$ 0,25, R$ 0,50 or R$ 1,00 coin is detected.
-- Any other combination is treated as invalid/unknown.
-- This yields the following detector logic: c = (a2'*a1'*a0) + (a2'*a1*a0') + (a2*a1'*a0').

-- Entity declaration
entity coin_detector is
	port(
		a2, a1, a0 : in std_logic;
		c          : out std_logic
		);
end coin_detector;

-- Architecture declaration
architecture arch of coin_detector is
begin

	-- Sum-of-products expression
	c <= ((not a2) and (not a1) and a0) or ((not a2) and a1 and (not a0)) or (a2 and (not a1) and (not a0));

end arch;