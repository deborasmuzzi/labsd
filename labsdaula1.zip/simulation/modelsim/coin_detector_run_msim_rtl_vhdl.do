transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {/home/usuario/lab_sd08/coin_detector.vhd}

vcom -93 -work work {/home/usuario/lab_sd08/tb_coin_detector.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L fiftyfivenm -L rtl_work -L work -voptargs="+acc"  tb_coin_detector

add wave *
view structure
view signals
run -all
