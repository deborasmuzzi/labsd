library IEEE;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity adder is
generic (W : positive := 4);
port(
	a, b : in std_logic_vector( W-1 downto 0 );
	sum : out std_logic_vector(W downto 0)
	);
end adder;

architecture arch of adder is
begin
	sum <= std_logic_vector(
	resize(unsigned(a), W+1) +
	resize(unsigned(b), W+1)
	);
end arch;


	