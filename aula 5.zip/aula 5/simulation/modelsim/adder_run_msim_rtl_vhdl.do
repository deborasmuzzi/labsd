transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {/home/usuario/lab_sd08/aula 5/adder.vhd}

vcom -93 -work work {/home/usuario/lab_sd08/aula 5/tb_adder.vhd}

vsim -t 1ps -L altera -L lpm -L sgate -L altera_mf -L altera_lnsim -L fiftyfivenm -L rtl_work -L work -voptargs="+acc"  tb_adder

add wave *
view structure
view signals
run -all
