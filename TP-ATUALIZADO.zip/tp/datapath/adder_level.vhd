library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity adder_level is
	PORT (
	PL : in std_logic_vector(2 downto 0);
	NL : out std_logic_vector(2 downto 0)
	);
end;

architecture arch of adder_level is
constant ONE : std_logic_vector (2 downto 0) := "001";
begin
	add_lev : entity work.adder
		generic map (W => 3)
		port map(
			A => PL,
			B => ONE,
			S => NL
			);
end;