library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity comparator_zero is
	port(
	SW : in std_logic_vector(9 downto 0);
	eq   : out std_logic
	);
end;

architecture arch of comparator_zero is
constant L : std_logic_vector(9 downto 0) := "0000000000";

begin
comp_lev : entity work.comparator
	generic map (data_width => 10)
	port map (
	a => SW,
	b => L,
	eq => eq,
	gt => open, 
	lt => open
	);

end;