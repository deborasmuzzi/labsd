-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "11/09/2026 22:33:59"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	datapath IS
    PORT (
	SW : IN std_logic_vector(9 DOWNTO 0);
	STG : IN std_logic_vector(2 DOWNTO 0);
	ld_lev : IN std_logic;
	ld_tim : IN std_logic;
	ld_rand : IN std_logic;
	d : IN std_logic;
	clr_lev : IN std_logic;
	clr_tim : IN std_logic;
	clr_rand : IN std_logic;
	clk : IN std_logic;
	eq : OUT std_logic;
	l : OUT std_logic;
	sw_z : OUT std_logic;
	RS : OUT std_logic_vector(9 DOWNTO 0);
	u : OUT std_logic_vector(6 DOWNTO 0);
	dz : OUT std_logic_vector(6 DOWNTO 0);
	c : OUT std_logic_vector(6 DOWNTO 0)
	);
END datapath;

-- Design Ports Information
-- eq	=>  Location: PIN_C8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- l	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- sw_z	=>  Location: PIN_E10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[0]	=>  Location: PIN_F7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[1]	=>  Location: PIN_C4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[2]	=>  Location: PIN_E8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[3]	=>  Location: PIN_B3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[4]	=>  Location: PIN_B7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[5]	=>  Location: PIN_A2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[6]	=>  Location: PIN_A3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[7]	=>  Location: PIN_C5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[8]	=>  Location: PIN_J10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[9]	=>  Location: PIN_H11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[0]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[1]	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[2]	=>  Location: PIN_C9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[3]	=>  Location: PIN_J11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[4]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[5]	=>  Location: PIN_A8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[6]	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[0]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[1]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[2]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[3]	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[4]	=>  Location: PIN_H13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[5]	=>  Location: PIN_C10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[6]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[0]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[1]	=>  Location: PIN_B12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[2]	=>  Location: PIN_A9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[3]	=>  Location: PIN_J12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[4]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[5]	=>  Location: PIN_Y11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[6]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[2]	=>  Location: PIN_D8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[3]	=>  Location: PIN_A6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- STG[0]	=>  Location: PIN_B4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- STG[1]	=>  Location: PIN_B5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- STG[2]	=>  Location: PIN_C6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[0]	=>  Location: PIN_A4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[1]	=>  Location: PIN_D9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[4]	=>  Location: PIN_D10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[5]	=>  Location: PIN_C7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[6]	=>  Location: PIN_D5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[7]	=>  Location: PIN_E9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[8]	=>  Location: PIN_D7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[9]	=>  Location: PIN_A5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- d	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_M8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clr_rand	=>  Location: PIN_M9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ld_rand	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ld_lev	=>  Location: PIN_C14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clr_lev	=>  Location: PIN_N5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ld_tim	=>  Location: PIN_A7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clr_tim	=>  Location: PIN_N4,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF datapath IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_SW : std_logic_vector(9 DOWNTO 0);
SIGNAL ww_STG : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_ld_lev : std_logic;
SIGNAL ww_ld_tim : std_logic;
SIGNAL ww_ld_rand : std_logic;
SIGNAL ww_d : std_logic;
SIGNAL ww_clr_lev : std_logic;
SIGNAL ww_clr_tim : std_logic;
SIGNAL ww_clr_rand : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_eq : std_logic;
SIGNAL ww_l : std_logic;
SIGNAL ww_sw_z : std_logic;
SIGNAL ww_RS : std_logic_vector(9 DOWNTO 0);
SIGNAL ww_u : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_dz : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_c : std_logic_vector(6 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \clr_tim~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clr_lev~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clr_rand~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \eq~output_o\ : std_logic;
SIGNAL \l~output_o\ : std_logic;
SIGNAL \sw_z~output_o\ : std_logic;
SIGNAL \RS[0]~output_o\ : std_logic;
SIGNAL \RS[1]~output_o\ : std_logic;
SIGNAL \RS[2]~output_o\ : std_logic;
SIGNAL \RS[3]~output_o\ : std_logic;
SIGNAL \RS[4]~output_o\ : std_logic;
SIGNAL \RS[5]~output_o\ : std_logic;
SIGNAL \RS[6]~output_o\ : std_logic;
SIGNAL \RS[7]~output_o\ : std_logic;
SIGNAL \RS[8]~output_o\ : std_logic;
SIGNAL \RS[9]~output_o\ : std_logic;
SIGNAL \u[0]~output_o\ : std_logic;
SIGNAL \u[1]~output_o\ : std_logic;
SIGNAL \u[2]~output_o\ : std_logic;
SIGNAL \u[3]~output_o\ : std_logic;
SIGNAL \u[4]~output_o\ : std_logic;
SIGNAL \u[5]~output_o\ : std_logic;
SIGNAL \u[6]~output_o\ : std_logic;
SIGNAL \dz[0]~output_o\ : std_logic;
SIGNAL \dz[1]~output_o\ : std_logic;
SIGNAL \dz[2]~output_o\ : std_logic;
SIGNAL \dz[3]~output_o\ : std_logic;
SIGNAL \dz[4]~output_o\ : std_logic;
SIGNAL \dz[5]~output_o\ : std_logic;
SIGNAL \dz[6]~output_o\ : std_logic;
SIGNAL \c[0]~output_o\ : std_logic;
SIGNAL \c[1]~output_o\ : std_logic;
SIGNAL \c[2]~output_o\ : std_logic;
SIGNAL \c[3]~output_o\ : std_logic;
SIGNAL \c[4]~output_o\ : std_logic;
SIGNAL \c[5]~output_o\ : std_logic;
SIGNAL \c[6]~output_o\ : std_logic;
SIGNAL \SW[7]~input_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[0]~21_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[1]~7_combout\ : std_logic;
SIGNAL \rand|reg_rand|q[1]~feeder_combout\ : std_logic;
SIGNAL \clr_rand~input_o\ : std_logic;
SIGNAL \clr_rand~inputclkctrl_outclk\ : std_logic;
SIGNAL \ld_rand~input_o\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[1]~8\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[2]~9_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[2]~10\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[3]~11_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[3]~12\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[4]~13_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[4]~14\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[5]~15_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[5]~16\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[6]~17_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[6]~18\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q[7]~19_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~7\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~7\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~9\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ : std_logic;
SIGNAL \rand|reg_rand|q[2]~feeder_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~7\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~9\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~11\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~7\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~9\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~11\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~13\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ : std_logic;
SIGNAL \rand|reg_rand|q[0]~feeder_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~1\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~10_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_5~2_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~3\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~5\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~7\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~9\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~11\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~13\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~15\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~6_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~12_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~10_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~8_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~14_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\ : std_logic;
SIGNAL \rand|Equal2~0_combout\ : std_logic;
SIGNAL \rand|ShiftLeft2~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~1\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~3\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~5\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~7\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~2_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_2~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~1\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~3\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~5\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~7\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~9\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~1\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~3\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~5\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~7\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~9\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~11\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~1\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~3\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~5\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~7\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~9\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~11\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~13\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~12_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~10_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~6_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~2_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_5~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~1\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~3\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~5\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~7\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~9\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~11\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~13\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~14_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~15\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~10_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~8_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~12_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\ : std_logic;
SIGNAL \rand|Equal1~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~0_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~2_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~6_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ : std_logic;
SIGNAL \rand|ShiftLeft1~0_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|op_6~4_combout\ : std_logic;
SIGNAL \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|op_6~4_combout\ : std_logic;
SIGNAL \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\ : std_logic;
SIGNAL \rand|S_3~10_combout\ : std_logic;
SIGNAL \STG[2]~input_o\ : std_logic;
SIGNAL \STG[0]~input_o\ : std_logic;
SIGNAL \rand|Equal0~2_combout\ : std_logic;
SIGNAL \rand|Equal0~6_combout\ : std_logic;
SIGNAL \rand|Equal0~3_combout\ : std_logic;
SIGNAL \rand|Equal0~4_combout\ : std_logic;
SIGNAL \rand|Equal0~5_combout\ : std_logic;
SIGNAL \rand|Mux5~4_combout\ : std_logic;
SIGNAL \STG[1]~input_o\ : std_logic;
SIGNAL \rand|Equal2~2_combout\ : std_logic;
SIGNAL \rand|Equal2~1_combout\ : std_logic;
SIGNAL \rand|Equal1~1_combout\ : std_logic;
SIGNAL \rand|Equal1~2_combout\ : std_logic;
SIGNAL \rand|Mux5~3_combout\ : std_logic;
SIGNAL \rand|Mux5~6_combout\ : std_logic;
SIGNAL \rand|Mux5~5_combout\ : std_logic;
SIGNAL \rand|Mux5~11_combout\ : std_logic;
SIGNAL \rand|Mux2~0_combout\ : std_logic;
SIGNAL \rand|Mux2~1_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~4_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~14_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~2_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~3_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~5_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ : std_logic;
SIGNAL \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~6_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~13_combout\ : std_logic;
SIGNAL \rand|Mux2~2_combout\ : std_logic;
SIGNAL \rand|Mux2~3_combout\ : std_logic;
SIGNAL \SW[6]~input_o\ : std_logic;
SIGNAL \rand|ShiftLeft0~12_combout\ : std_logic;
SIGNAL \rand|Mux3~0_combout\ : std_logic;
SIGNAL \rand|Mux3~2_combout\ : std_logic;
SIGNAL \rand|ShiftLeft1~1_combout\ : std_logic;
SIGNAL \rand|ShiftLeft2~1_combout\ : std_logic;
SIGNAL \rand|S_3~11_combout\ : std_logic;
SIGNAL \rand|Mux3~1_combout\ : std_logic;
SIGNAL \rand|Mux3~3_combout\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~4_combout\ : std_logic;
SIGNAL \rand|Mux0~2_combout\ : std_logic;
SIGNAL \rand|ShiftLeft2~4_combout\ : std_logic;
SIGNAL \rand|ShiftLeft1~4_combout\ : std_logic;
SIGNAL \rand|S_3~12_combout\ : std_logic;
SIGNAL \rand|Mux1~0_combout\ : std_logic;
SIGNAL \rand|Equal0~7_combout\ : std_logic;
SIGNAL \rand|Mux0~0_combout\ : std_logic;
SIGNAL \rand|Mux0~1_combout\ : std_logic;
SIGNAL \rand|Mux1~1_combout\ : std_logic;
SIGNAL \SW[8]~input_o\ : std_logic;
SIGNAL \rand|Mux4~0_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~11_combout\ : std_logic;
SIGNAL \rand|Mux4~2_combout\ : std_logic;
SIGNAL \rand|ShiftLeft2~3_combout\ : std_logic;
SIGNAL \rand|ShiftLeft1~3_combout\ : std_logic;
SIGNAL \rand|S_3~8_combout\ : std_logic;
SIGNAL \rand|Mux4~1_combout\ : std_logic;
SIGNAL \rand|Mux4~3_combout\ : std_logic;
SIGNAL \SW[4]~input_o\ : std_logic;
SIGNAL \rand|Mux5~7_combout\ : std_logic;
SIGNAL \rand|Mux5~9_combout\ : std_logic;
SIGNAL \rand|S_3~9_combout\ : std_logic;
SIGNAL \rand|Mux5~8_combout\ : std_logic;
SIGNAL \rand|Mux5~10_combout\ : std_logic;
SIGNAL \SW[5]~input_o\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~3_combout\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~5_combout\ : std_logic;
SIGNAL \SW[0]~input_o\ : std_logic;
SIGNAL \rand|Mux8~0_combout\ : std_logic;
SIGNAL \rand|ShiftLeft1~2_combout\ : std_logic;
SIGNAL \rand|ShiftLeft2~2_combout\ : std_logic;
SIGNAL \rand|S_3~4_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~9_combout\ : std_logic;
SIGNAL \rand|S_2~2_combout\ : std_logic;
SIGNAL \rand|Mux5~2_combout\ : std_logic;
SIGNAL \rand|Mux8~1_combout\ : std_logic;
SIGNAL \rand|Mux8~2_combout\ : std_logic;
SIGNAL \rand|Mux9~0_combout\ : std_logic;
SIGNAL \rand|Mux9~1_combout\ : std_logic;
SIGNAL \rand|Mux9~2_combout\ : std_logic;
SIGNAL \rand|Mux9~3_combout\ : std_logic;
SIGNAL \rand|Mux8~3_combout\ : std_logic;
SIGNAL \rand|S_3~5_combout\ : std_logic;
SIGNAL \rand|Mux9~4_combout\ : std_logic;
SIGNAL \rand|S_3~6_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~10_combout\ : std_logic;
SIGNAL \rand|S_2~3_combout\ : std_logic;
SIGNAL \rand|Mux8~4_combout\ : std_logic;
SIGNAL \rand|Mux8~5_combout\ : std_logic;
SIGNAL \rand|Mux8~6_combout\ : std_logic;
SIGNAL \rand|S_3~7_combout\ : std_logic;
SIGNAL \rand|Mux8~7_combout\ : std_logic;
SIGNAL \SW[1]~input_o\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~1_combout\ : std_logic;
SIGNAL \rand|Mux6~0_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~7_combout\ : std_logic;
SIGNAL \rand|Mux6~1_combout\ : std_logic;
SIGNAL \rand|S_2~0_combout\ : std_logic;
SIGNAL \rand|S_3~0_combout\ : std_logic;
SIGNAL \rand|Mux6~2_combout\ : std_logic;
SIGNAL \rand|S_3~1_combout\ : std_logic;
SIGNAL \rand|Mux6~3_combout\ : std_logic;
SIGNAL \SW[2]~input_o\ : std_logic;
SIGNAL \rand|S_3~2_combout\ : std_logic;
SIGNAL \rand|S_3~3_combout\ : std_logic;
SIGNAL \rand|ShiftLeft0~8_combout\ : std_logic;
SIGNAL \rand|S_2~1_combout\ : std_logic;
SIGNAL \rand|Mux7~0_combout\ : std_logic;
SIGNAL \rand|Mux7~1_combout\ : std_logic;
SIGNAL \rand|Mux7~2_combout\ : std_logic;
SIGNAL \rand|Mux7~3_combout\ : std_logic;
SIGNAL \SW[3]~input_o\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~0_combout\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~2_combout\ : std_logic;
SIGNAL \SW[9]~input_o\ : std_logic;
SIGNAL \rand|Mux1~2_combout\ : std_logic;
SIGNAL \rand|Mux0~3_combout\ : std_logic;
SIGNAL \rand|S_3~13_combout\ : std_logic;
SIGNAL \rand|Mux0~4_combout\ : std_logic;
SIGNAL \comparator_rand|comp_rand|Equal0~6_combout\ : std_logic;
SIGNAL \ld_lev~input_o\ : std_logic;
SIGNAL \total_level|reg_lev|q[0]~0_combout\ : std_logic;
SIGNAL \clr_lev~input_o\ : std_logic;
SIGNAL \clr_lev~inputclkctrl_outclk\ : std_logic;
SIGNAL \total_level|reg_lev|q[1]~2_combout\ : std_logic;
SIGNAL \total_level|reg_lev|q[2]~1_combout\ : std_logic;
SIGNAL \comparator_level|comp_lev|Equal0~0_combout\ : std_logic;
SIGNAL \comparator_zero|comp_lev|Equal0~1_combout\ : std_logic;
SIGNAL \comparator_zero|comp_lev|Equal0~0_combout\ : std_logic;
SIGNAL \comparator_zero|comp_lev|Equal0~2_combout\ : std_logic;
SIGNAL \ld_tim~input_o\ : std_logic;
SIGNAL \total_timer|reg_tim|q[0]~7_combout\ : std_logic;
SIGNAL \clr_tim~input_o\ : std_logic;
SIGNAL \clr_tim~inputclkctrl_outclk\ : std_logic;
SIGNAL \total_timer|reg_tim|q[1]~8_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[1]~9\ : std_logic;
SIGNAL \total_timer|reg_tim|q[2]~10_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[2]~11\ : std_logic;
SIGNAL \total_timer|reg_tim|q[3]~12_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[3]~13\ : std_logic;
SIGNAL \total_timer|reg_tim|q[4]~14_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[4]~15\ : std_logic;
SIGNAL \total_timer|reg_tim|q[5]~16_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[5]~17\ : std_logic;
SIGNAL \total_timer|reg_tim|q[6]~18_combout\ : std_logic;
SIGNAL \total_timer|reg_tim|q[6]~19\ : std_logic;
SIGNAL \total_timer|reg_tim|q[7]~20_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ : std_logic;
SIGNAL \display|Mux6~0_combout\ : std_logic;
SIGNAL \d~input_o\ : std_logic;
SIGNAL \display|res:s_u[0]~0_combout\ : std_logic;
SIGNAL \display|res:s_u[1]~0_combout\ : std_logic;
SIGNAL \display|res:s_u[2]~0_combout\ : std_logic;
SIGNAL \display|Mux3~0_combout\ : std_logic;
SIGNAL \display|res:s_u[3]~0_combout\ : std_logic;
SIGNAL \display|res:s_u[4]~0_combout\ : std_logic;
SIGNAL \display|Mux1~0_combout\ : std_logic;
SIGNAL \display|res:s_u[5]~0_combout\ : std_logic;
SIGNAL \display|Mux0~0_combout\ : std_logic;
SIGNAL \display|res:s_u[6]~0_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ : std_logic;
SIGNAL \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\ : std_logic;
SIGNAL \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ : std_logic;
SIGNAL \display|Mux20~0_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\ : std_logic;
SIGNAL \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ : std_logic;
SIGNAL \display|s_dz~0_combout\ : std_logic;
SIGNAL \display|s_dz~1_combout\ : std_logic;
SIGNAL \display|Mux20~1_combout\ : std_logic;
SIGNAL \display|Mux19~0_combout\ : std_logic;
SIGNAL \display|Mux19~1_combout\ : std_logic;
SIGNAL \display|Mux18~0_combout\ : std_logic;
SIGNAL \display|res:s_dz[2]~0_combout\ : std_logic;
SIGNAL \display|Mux17~0_combout\ : std_logic;
SIGNAL \display|Mux17~1_combout\ : std_logic;
SIGNAL \display|Mux16~0_combout\ : std_logic;
SIGNAL \display|Mux16~1_combout\ : std_logic;
SIGNAL \display|Mux15~0_combout\ : std_logic;
SIGNAL \display|Mux15~1_combout\ : std_logic;
SIGNAL \display|Mux14~0_combout\ : std_logic;
SIGNAL \display|Mux14~1_combout\ : std_logic;
SIGNAL \display|res:s_c[0]~0_combout\ : std_logic;
SIGNAL \display|res:s_c[0]~1_combout\ : std_logic;
SIGNAL \display|res:s_c[2]~0_combout\ : std_logic;
SIGNAL \display|res:s_c[4]~0_combout\ : std_logic;
SIGNAL \total_Gtimer|reg_Gtim|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \total_timer|reg_tim|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \rand|reg_rand|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \total_level|reg_lev|q\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \ALT_INV_clr_rand~inputclkctrl_outclk\ : std_logic;
SIGNAL \ALT_INV_clr_lev~inputclkctrl_outclk\ : std_logic;
SIGNAL \ALT_INV_clr_tim~inputclkctrl_outclk\ : std_logic;
SIGNAL \display|ALT_INV_res:s_c[4]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_c[2]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_c[0]~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_c[0]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux14~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux15~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux16~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux17~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux19~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_Mux20~1_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[6]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[5]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[4]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[3]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[2]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[1]~0_combout\ : std_logic;
SIGNAL \display|ALT_INV_res:s_u[0]~0_combout\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_SW <= SW;
ww_STG <= STG;
ww_ld_lev <= ld_lev;
ww_ld_tim <= ld_tim;
ww_ld_rand <= ld_rand;
ww_d <= d;
ww_clr_lev <= clr_lev;
ww_clr_tim <= clr_tim;
ww_clr_rand <= clr_rand;
ww_clk <= clk;
eq <= ww_eq;
l <= ww_l;
sw_z <= ww_sw_z;
RS <= ww_RS;
u <= ww_u;
dz <= ww_dz;
c <= ww_c;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\clr_tim~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clr_tim~input_o\);

\clr_lev~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clr_lev~input_o\);

\clr_rand~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clr_rand~input_o\);

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\ALT_INV_clr_rand~inputclkctrl_outclk\ <= NOT \clr_rand~inputclkctrl_outclk\;
\ALT_INV_clr_lev~inputclkctrl_outclk\ <= NOT \clr_lev~inputclkctrl_outclk\;
\ALT_INV_clr_tim~inputclkctrl_outclk\ <= NOT \clr_tim~inputclkctrl_outclk\;
\display|ALT_INV_res:s_c[4]~0_combout\ <= NOT \display|res:s_c[4]~0_combout\;
\display|ALT_INV_res:s_c[2]~0_combout\ <= NOT \display|res:s_c[2]~0_combout\;
\display|ALT_INV_res:s_c[0]~1_combout\ <= NOT \display|res:s_c[0]~1_combout\;
\display|ALT_INV_res:s_c[0]~0_combout\ <= NOT \display|res:s_c[0]~0_combout\;
\display|ALT_INV_Mux14~1_combout\ <= NOT \display|Mux14~1_combout\;
\display|ALT_INV_Mux15~1_combout\ <= NOT \display|Mux15~1_combout\;
\display|ALT_INV_Mux16~1_combout\ <= NOT \display|Mux16~1_combout\;
\display|ALT_INV_Mux17~1_combout\ <= NOT \display|Mux17~1_combout\;
\display|ALT_INV_Mux19~1_combout\ <= NOT \display|Mux19~1_combout\;
\display|ALT_INV_Mux20~1_combout\ <= NOT \display|Mux20~1_combout\;
\display|ALT_INV_res:s_u[6]~0_combout\ <= NOT \display|res:s_u[6]~0_combout\;
\display|ALT_INV_res:s_u[5]~0_combout\ <= NOT \display|res:s_u[5]~0_combout\;
\display|ALT_INV_res:s_u[4]~0_combout\ <= NOT \display|res:s_u[4]~0_combout\;
\display|ALT_INV_res:s_u[3]~0_combout\ <= NOT \display|res:s_u[3]~0_combout\;
\display|ALT_INV_res:s_u[2]~0_combout\ <= NOT \display|res:s_u[2]~0_combout\;
\display|ALT_INV_res:s_u[1]~0_combout\ <= NOT \display|res:s_u[1]~0_combout\;
\display|ALT_INV_res:s_u[0]~0_combout\ <= NOT \display|res:s_u[0]~0_combout\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y42_N12
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X36_Y39_N30
\eq~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \comparator_rand|comp_rand|Equal0~6_combout\,
	devoe => ww_devoe,
	o => \eq~output_o\);

-- Location: IOOBUF_X58_Y54_N23
\l~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \comparator_level|comp_lev|Equal0~0_combout\,
	devoe => ww_devoe,
	o => \l~output_o\);

-- Location: IOOBUF_X36_Y39_N23
\sw_z~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \comparator_zero|comp_lev|Equal0~2_combout\,
	devoe => ww_devoe,
	o => \sw_z~output_o\);

-- Location: IOOBUF_X24_Y39_N16
\RS[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux9~4_combout\,
	devoe => ww_devoe,
	o => \RS[0]~output_o\);

-- Location: IOOBUF_X24_Y39_N2
\RS[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux8~7_combout\,
	devoe => ww_devoe,
	o => \RS[1]~output_o\);

-- Location: IOOBUF_X24_Y39_N9
\RS[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux7~3_combout\,
	devoe => ww_devoe,
	o => \RS[2]~output_o\);

-- Location: IOOBUF_X26_Y39_N16
\RS[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux6~3_combout\,
	devoe => ww_devoe,
	o => \RS[3]~output_o\);

-- Location: IOOBUF_X34_Y39_N23
\RS[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux5~10_combout\,
	devoe => ww_devoe,
	o => \RS[4]~output_o\);

-- Location: IOOBUF_X26_Y39_N2
\RS[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux4~3_combout\,
	devoe => ww_devoe,
	o => \RS[5]~output_o\);

-- Location: IOOBUF_X26_Y39_N9
\RS[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux3~3_combout\,
	devoe => ww_devoe,
	o => \RS[6]~output_o\);

-- Location: IOOBUF_X24_Y39_N23
\RS[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux2~3_combout\,
	devoe => ww_devoe,
	o => \RS[7]~output_o\);

-- Location: IOOBUF_X34_Y39_N9
\RS[8]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux1~1_combout\,
	devoe => ww_devoe,
	o => \RS[8]~output_o\);

-- Location: IOOBUF_X34_Y39_N16
\RS[9]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \rand|Mux0~4_combout\,
	devoe => ww_devoe,
	o => \RS[9]~output_o\);

-- Location: IOOBUF_X49_Y54_N16
\u[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[0]~0_combout\,
	devoe => ww_devoe,
	o => \u[0]~output_o\);

-- Location: IOOBUF_X54_Y54_N23
\u[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[1]~0_combout\,
	devoe => ww_devoe,
	o => \u[1]~output_o\);

-- Location: IOOBUF_X46_Y54_N16
\u[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[2]~0_combout\,
	devoe => ww_devoe,
	o => \u[2]~output_o\);

-- Location: IOOBUF_X49_Y54_N23
\u[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[3]~0_combout\,
	devoe => ww_devoe,
	o => \u[3]~output_o\);

-- Location: IOOBUF_X49_Y54_N9
\u[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[4]~0_combout\,
	devoe => ww_devoe,
	o => \u[4]~output_o\);

-- Location: IOOBUF_X46_Y54_N2
\u[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[5]~0_combout\,
	devoe => ww_devoe,
	o => \u[5]~output_o\);

-- Location: IOOBUF_X46_Y54_N30
\u[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_u[6]~0_combout\,
	devoe => ww_devoe,
	o => \u[6]~output_o\);

-- Location: IOOBUF_X51_Y54_N2
\dz[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux20~1_combout\,
	devoe => ww_devoe,
	o => \dz[0]~output_o\);

-- Location: IOOBUF_X54_Y54_N30
\dz[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux19~1_combout\,
	devoe => ww_devoe,
	o => \dz[1]~output_o\);

-- Location: IOOBUF_X56_Y54_N2
\dz[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|res:s_dz[2]~0_combout\,
	devoe => ww_devoe,
	o => \dz[2]~output_o\);

-- Location: IOOBUF_X51_Y54_N9
\dz[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux17~1_combout\,
	devoe => ww_devoe,
	o => \dz[3]~output_o\);

-- Location: IOOBUF_X54_Y54_N2
\dz[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux16~1_combout\,
	devoe => ww_devoe,
	o => \dz[4]~output_o\);

-- Location: IOOBUF_X51_Y54_N30
\dz[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux15~1_combout\,
	devoe => ww_devoe,
	o => \dz[5]~output_o\);

-- Location: IOOBUF_X51_Y54_N23
\dz[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_Mux14~1_combout\,
	devoe => ww_devoe,
	o => \dz[6]~output_o\);

-- Location: IOOBUF_X56_Y54_N30
\c[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[0]~output_o\);

-- Location: IOOBUF_X49_Y54_N2
\c[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[0]~1_combout\,
	devoe => ww_devoe,
	o => \c[1]~output_o\);

-- Location: IOOBUF_X46_Y54_N23
\c[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[2]~0_combout\,
	devoe => ww_devoe,
	o => \c[2]~output_o\);

-- Location: IOOBUF_X54_Y54_N9
\c[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[3]~output_o\);

-- Location: IOOBUF_X46_Y54_N9
\c[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[4]~0_combout\,
	devoe => ww_devoe,
	o => \c[4]~output_o\);

-- Location: IOOBUF_X36_Y0_N2
\c[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \c[5]~output_o\);

-- Location: IOOBUF_X54_Y54_N16
\c[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[6]~output_o\);

-- Location: IOIBUF_X29_Y39_N1
\SW[7]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(7),
	o => \SW[7]~input_o\);

-- Location: IOIBUF_X0_Y18_N15
\clk~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G3
\clk~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X34_Y36_N22
\total_Gtimer|reg_Gtim|q[0]~21\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[0]~21_combout\ = !\total_Gtimer|reg_Gtim|q\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_Gtimer|reg_Gtim|q\(0),
	combout => \total_Gtimer|reg_Gtim|q[0]~21_combout\);

-- Location: FF_X34_Y36_N23
\total_Gtimer|reg_Gtim|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[0]~21_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(0));

-- Location: LCCOMB_X34_Y36_N4
\total_Gtimer|reg_Gtim|q[1]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[1]~7_combout\ = (\total_Gtimer|reg_Gtim|q\(0) & (\total_Gtimer|reg_Gtim|q\(1) $ (VCC))) # (!\total_Gtimer|reg_Gtim|q\(0) & (\total_Gtimer|reg_Gtim|q\(1) & VCC))
-- \total_Gtimer|reg_Gtim|q[1]~8\ = CARRY((\total_Gtimer|reg_Gtim|q\(0) & \total_Gtimer|reg_Gtim|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_Gtimer|reg_Gtim|q\(0),
	datab => \total_Gtimer|reg_Gtim|q\(1),
	datad => VCC,
	combout => \total_Gtimer|reg_Gtim|q[1]~7_combout\,
	cout => \total_Gtimer|reg_Gtim|q[1]~8\);

-- Location: FF_X34_Y36_N5
\total_Gtimer|reg_Gtim|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[1]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(1));

-- Location: LCCOMB_X34_Y36_N24
\rand|reg_rand|q[1]~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|reg_rand|q[1]~feeder_combout\ = \total_Gtimer|reg_Gtim|q\(1)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \total_Gtimer|reg_Gtim|q\(1),
	combout => \rand|reg_rand|q[1]~feeder_combout\);

-- Location: IOIBUF_X0_Y18_N22
\clr_rand~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clr_rand,
	o => \clr_rand~input_o\);

-- Location: CLKCTRL_G4
\clr_rand~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clr_rand~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clr_rand~inputclkctrl_outclk\);

-- Location: IOIBUF_X36_Y39_N15
\ld_rand~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ld_rand,
	o => \ld_rand~input_o\);

-- Location: FF_X34_Y36_N25
\rand|reg_rand|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \rand|reg_rand|q[1]~feeder_combout\,
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(1));

-- Location: LCCOMB_X34_Y36_N6
\total_Gtimer|reg_Gtim|q[2]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[2]~9_combout\ = (\total_Gtimer|reg_Gtim|q\(2) & (!\total_Gtimer|reg_Gtim|q[1]~8\)) # (!\total_Gtimer|reg_Gtim|q\(2) & ((\total_Gtimer|reg_Gtim|q[1]~8\) # (GND)))
-- \total_Gtimer|reg_Gtim|q[2]~10\ = CARRY((!\total_Gtimer|reg_Gtim|q[1]~8\) # (!\total_Gtimer|reg_Gtim|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_Gtimer|reg_Gtim|q\(2),
	datad => VCC,
	cin => \total_Gtimer|reg_Gtim|q[1]~8\,
	combout => \total_Gtimer|reg_Gtim|q[2]~9_combout\,
	cout => \total_Gtimer|reg_Gtim|q[2]~10\);

-- Location: FF_X34_Y36_N7
\total_Gtimer|reg_Gtim|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[2]~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(2));

-- Location: LCCOMB_X34_Y36_N8
\total_Gtimer|reg_Gtim|q[3]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[3]~11_combout\ = (\total_Gtimer|reg_Gtim|q\(3) & (\total_Gtimer|reg_Gtim|q[2]~10\ $ (GND))) # (!\total_Gtimer|reg_Gtim|q\(3) & (!\total_Gtimer|reg_Gtim|q[2]~10\ & VCC))
-- \total_Gtimer|reg_Gtim|q[3]~12\ = CARRY((\total_Gtimer|reg_Gtim|q\(3) & !\total_Gtimer|reg_Gtim|q[2]~10\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_Gtimer|reg_Gtim|q\(3),
	datad => VCC,
	cin => \total_Gtimer|reg_Gtim|q[2]~10\,
	combout => \total_Gtimer|reg_Gtim|q[3]~11_combout\,
	cout => \total_Gtimer|reg_Gtim|q[3]~12\);

-- Location: FF_X34_Y36_N9
\total_Gtimer|reg_Gtim|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[3]~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(3));

-- Location: LCCOMB_X34_Y36_N10
\total_Gtimer|reg_Gtim|q[4]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[4]~13_combout\ = (\total_Gtimer|reg_Gtim|q\(4) & (!\total_Gtimer|reg_Gtim|q[3]~12\)) # (!\total_Gtimer|reg_Gtim|q\(4) & ((\total_Gtimer|reg_Gtim|q[3]~12\) # (GND)))
-- \total_Gtimer|reg_Gtim|q[4]~14\ = CARRY((!\total_Gtimer|reg_Gtim|q[3]~12\) # (!\total_Gtimer|reg_Gtim|q\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_Gtimer|reg_Gtim|q\(4),
	datad => VCC,
	cin => \total_Gtimer|reg_Gtim|q[3]~12\,
	combout => \total_Gtimer|reg_Gtim|q[4]~13_combout\,
	cout => \total_Gtimer|reg_Gtim|q[4]~14\);

-- Location: FF_X34_Y36_N11
\total_Gtimer|reg_Gtim|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[4]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(4));

-- Location: LCCOMB_X34_Y36_N12
\total_Gtimer|reg_Gtim|q[5]~15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[5]~15_combout\ = (\total_Gtimer|reg_Gtim|q\(5) & (\total_Gtimer|reg_Gtim|q[4]~14\ $ (GND))) # (!\total_Gtimer|reg_Gtim|q\(5) & (!\total_Gtimer|reg_Gtim|q[4]~14\ & VCC))
-- \total_Gtimer|reg_Gtim|q[5]~16\ = CARRY((\total_Gtimer|reg_Gtim|q\(5) & !\total_Gtimer|reg_Gtim|q[4]~14\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_Gtimer|reg_Gtim|q\(5),
	datad => VCC,
	cin => \total_Gtimer|reg_Gtim|q[4]~14\,
	combout => \total_Gtimer|reg_Gtim|q[5]~15_combout\,
	cout => \total_Gtimer|reg_Gtim|q[5]~16\);

-- Location: FF_X34_Y36_N13
\total_Gtimer|reg_Gtim|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[5]~15_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(5));

-- Location: LCCOMB_X34_Y36_N14
\total_Gtimer|reg_Gtim|q[6]~17\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[6]~17_combout\ = (\total_Gtimer|reg_Gtim|q\(6) & (!\total_Gtimer|reg_Gtim|q[5]~16\)) # (!\total_Gtimer|reg_Gtim|q\(6) & ((\total_Gtimer|reg_Gtim|q[5]~16\) # (GND)))
-- \total_Gtimer|reg_Gtim|q[6]~18\ = CARRY((!\total_Gtimer|reg_Gtim|q[5]~16\) # (!\total_Gtimer|reg_Gtim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_Gtimer|reg_Gtim|q\(6),
	datad => VCC,
	cin => \total_Gtimer|reg_Gtim|q[5]~16\,
	combout => \total_Gtimer|reg_Gtim|q[6]~17_combout\,
	cout => \total_Gtimer|reg_Gtim|q[6]~18\);

-- Location: FF_X34_Y36_N15
\total_Gtimer|reg_Gtim|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[6]~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(6));

-- Location: LCCOMB_X34_Y36_N16
\total_Gtimer|reg_Gtim|q[7]~19\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_Gtimer|reg_Gtim|q[7]~19_combout\ = \total_Gtimer|reg_Gtim|q[6]~18\ $ (!\total_Gtimer|reg_Gtim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \total_Gtimer|reg_Gtim|q\(7),
	cin => \total_Gtimer|reg_Gtim|q[6]~18\,
	combout => \total_Gtimer|reg_Gtim|q[7]~19_combout\);

-- Location: FF_X34_Y36_N17
\total_Gtimer|reg_Gtim|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_Gtimer|reg_Gtim|q[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_Gtimer|reg_Gtim|q\(7));

-- Location: FF_X35_Y36_N17
\rand|reg_rand|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \total_Gtimer|reg_Gtim|q\(7),
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	sload => VCC,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(7));

-- Location: FF_X36_Y36_N1
\rand|reg_rand|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \total_Gtimer|reg_Gtim|q\(6),
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	sload => VCC,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(6));

-- Location: FF_X35_Y36_N23
\rand|reg_rand|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \total_Gtimer|reg_Gtim|q\(5),
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	sload => VCC,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(5));

-- Location: LCCOMB_X40_Y35_N14
\rand|Mod2|auto_generated|divider|divider|op_1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ = \rand|reg_rand|q\(5) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_1~1\ = CARRY(\rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(5),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_1~1\);

-- Location: LCCOMB_X40_Y35_N16
\rand|Mod2|auto_generated|divider|divider|op_1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\ = (\rand|reg_rand|q\(6) & (!\rand|Mod2|auto_generated|divider|divider|op_1~1\)) # (!\rand|reg_rand|q\(6) & ((\rand|Mod2|auto_generated|divider|divider|op_1~1\) # (GND)))
-- \rand|Mod2|auto_generated|divider|divider|op_1~3\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_1~1\) # (!\rand|reg_rand|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(6),
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_1~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_1~3\);

-- Location: LCCOMB_X40_Y35_N18
\rand|Mod2|auto_generated|divider|divider|op_1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\ = (\rand|reg_rand|q\(7) & (\rand|Mod2|auto_generated|divider|divider|op_1~3\ $ (GND))) # (!\rand|reg_rand|q\(7) & (!\rand|Mod2|auto_generated|divider|divider|op_1~3\ & VCC))
-- \rand|Mod2|auto_generated|divider|divider|op_1~5\ = CARRY((\rand|reg_rand|q\(7) & !\rand|Mod2|auto_generated|divider|divider|op_1~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(7),
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_1~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_1~5\);

-- Location: LCCOMB_X40_Y35_N20
\rand|Mod2|auto_generated|divider|divider|op_1~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ = !\rand|Mod2|auto_generated|divider|divider|op_1~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_1~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\);

-- Location: LCCOMB_X39_Y35_N16
\rand|Mod2|auto_generated|divider|divider|StageOut[18]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & \rand|reg_rand|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datad => \rand|reg_rand|q\(7),
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\);

-- Location: LCCOMB_X40_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[18]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\);

-- Location: LCCOMB_X40_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[17]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\);

-- Location: LCCOMB_X40_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[17]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\ = (\rand|reg_rand|q\(6) & \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(6),
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\);

-- Location: LCCOMB_X40_Y35_N22
\rand|Mod2|auto_generated|divider|divider|StageOut[16]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\);

-- Location: LCCOMB_X40_Y35_N0
\rand|Mod2|auto_generated|divider|divider|StageOut[16]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ = (\rand|reg_rand|q\(5) & \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(5),
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\);

-- Location: FF_X35_Y36_N27
\rand|reg_rand|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \total_Gtimer|reg_Gtim|q\(4),
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	sload => VCC,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(4));

-- Location: LCCOMB_X40_Y35_N2
\rand|Mod2|auto_generated|divider|divider|op_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\ = \rand|reg_rand|q\(4) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_2~1\ = CARRY(\rand|reg_rand|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(4),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_2~1\);

-- Location: LCCOMB_X40_Y35_N4
\rand|Mod2|auto_generated|divider|divider|op_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|op_2~1\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ & (!\rand|Mod2|auto_generated|divider|divider|op_2~1\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_2~1\) # (GND)))))
-- \rand|Mod2|auto_generated|divider|divider|op_2~3\ = CARRY(((!\rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\)) # (!\rand|Mod2|auto_generated|divider|divider|op_2~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_2~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_2~3\);

-- Location: LCCOMB_X40_Y35_N6
\rand|Mod2|auto_generated|divider|divider|op_2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~3\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_2~3\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\)))))
-- \rand|Mod2|auto_generated|divider|divider|op_2~5\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_2~3\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # (\rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_2~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_2~5\);

-- Location: LCCOMB_X40_Y35_N8
\rand|Mod2|auto_generated|divider|divider|op_2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~5\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_2~5\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_2~7\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_2~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_2~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_2~7\);

-- Location: LCCOMB_X40_Y35_N10
\rand|Mod2|auto_generated|divider|divider|op_2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ = \rand|Mod2|auto_generated|divider|divider|op_2~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_2~7\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\);

-- Location: LCCOMB_X39_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[27]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\);

-- Location: LCCOMB_X39_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[27]~124\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\rand|reg_rand|q\(7))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(7),
	datab => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\);

-- Location: LCCOMB_X39_Y35_N22
\rand|Mod2|auto_generated|divider|divider|StageOut[26]~125\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\rand|reg_rand|q\(6))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datab => \rand|reg_rand|q\(6),
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\);

-- Location: LCCOMB_X39_Y35_N0
\rand|Mod2|auto_generated|divider|divider|StageOut[26]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\);

-- Location: LCCOMB_X39_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[25]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\);

-- Location: LCCOMB_X40_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[25]~126\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\rand|reg_rand|q\(5))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_1~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(5),
	datab => \rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\);

-- Location: LCCOMB_X41_Y35_N8
\rand|Mod2|auto_generated|divider|divider|StageOut[24]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ = (\rand|reg_rand|q\(4) & \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(4),
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\);

-- Location: LCCOMB_X40_Y35_N12
\rand|Mod2|auto_generated|divider|divider|StageOut[24]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\);

-- Location: FF_X35_Y36_N19
\rand|reg_rand|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \total_Gtimer|reg_Gtim|q\(3),
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	sload => VCC,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(3));

-- Location: LCCOMB_X39_Y35_N2
\rand|Mod2|auto_generated|divider|divider|op_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ = \rand|reg_rand|q\(3) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_3~1\ = CARRY(\rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(3),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_3~1\);

-- Location: LCCOMB_X39_Y35_N4
\rand|Mod2|auto_generated|divider|divider|op_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|op_3~1\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ & (!\rand|Mod2|auto_generated|divider|divider|op_3~1\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_3~1\) # (GND)))))
-- \rand|Mod2|auto_generated|divider|divider|op_3~3\ = CARRY(((!\rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\)) # (!\rand|Mod2|auto_generated|divider|divider|op_3~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_3~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_3~3\);

-- Location: LCCOMB_X39_Y35_N6
\rand|Mod2|auto_generated|divider|divider|op_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~3\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_3~3\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\)))))
-- \rand|Mod2|auto_generated|divider|divider|op_3~5\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_3~3\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_3~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_3~5\);

-- Location: LCCOMB_X39_Y35_N8
\rand|Mod2|auto_generated|divider|divider|op_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~5\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_3~5\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_3~7\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_3~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_3~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_3~7\);

-- Location: LCCOMB_X39_Y35_N10
\rand|Mod2|auto_generated|divider|divider|op_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~7\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_3~7\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_3~9\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_3~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_3~7\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_3~9\);

-- Location: LCCOMB_X39_Y35_N12
\rand|Mod2|auto_generated|divider|divider|op_3~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ = !\rand|Mod2|auto_generated|divider|divider|op_3~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_3~9\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\);

-- Location: LCCOMB_X38_Y35_N0
\rand|Mod2|auto_generated|divider|divider|StageOut[36]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~8_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\);

-- Location: LCCOMB_X39_Y35_N18
\rand|Mod2|auto_generated|divider|divider|StageOut[36]~112\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[27]~124_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\);

-- Location: LCCOMB_X38_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[35]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\);

-- Location: LCCOMB_X39_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[35]~113\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[26]~125_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\);

-- Location: LCCOMB_X39_Y35_N20
\rand|Mod2|auto_generated|divider|divider|StageOut[34]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\);

-- Location: LCCOMB_X39_Y35_N14
\rand|Mod2|auto_generated|divider|divider|StageOut[34]~114\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[25]~126_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\);

-- Location: LCCOMB_X41_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[33]~127\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & (\rand|reg_rand|q\(4))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|reg_rand|q\(4),
	datad => \rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\);

-- Location: LCCOMB_X38_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[33]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\);

-- Location: LCCOMB_X38_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[32]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|reg_rand|q\(3),
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\);

-- Location: LCCOMB_X38_Y35_N2
\rand|Mod2|auto_generated|divider|divider|StageOut[32]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\);

-- Location: LCCOMB_X34_Y36_N18
\rand|reg_rand|q[2]~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|reg_rand|q[2]~feeder_combout\ = \total_Gtimer|reg_Gtim|q\(2)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_Gtimer|reg_Gtim|q\(2),
	combout => \rand|reg_rand|q[2]~feeder_combout\);

-- Location: FF_X34_Y36_N19
\rand|reg_rand|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \rand|reg_rand|q[2]~feeder_combout\,
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(2));

-- Location: LCCOMB_X38_Y35_N8
\rand|Mod2|auto_generated|divider|divider|op_4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\ = \rand|reg_rand|q\(2) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_4~1\ = CARRY(\rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(2),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~1\);

-- Location: LCCOMB_X38_Y35_N10
\rand|Mod2|auto_generated|divider|divider|op_4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|op_4~1\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ & (!\rand|Mod2|auto_generated|divider|divider|op_4~1\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_4~1\) # (GND)))))
-- \rand|Mod2|auto_generated|divider|divider|op_4~3\ = CARRY(((!\rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\)) # (!\rand|Mod2|auto_generated|divider|divider|op_4~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~3\);

-- Location: LCCOMB_X38_Y35_N12
\rand|Mod2|auto_generated|divider|divider|op_4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~3\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_4~3\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\)))))
-- \rand|Mod2|auto_generated|divider|divider|op_4~5\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_4~3\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~5\);

-- Location: LCCOMB_X38_Y35_N14
\rand|Mod2|auto_generated|divider|divider|op_4~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~5\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_4~5\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_4~7\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~7\);

-- Location: LCCOMB_X38_Y35_N16
\rand|Mod2|auto_generated|divider|divider|op_4~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~7\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_4~7\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_4~9\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_4~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~7\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~9\);

-- Location: LCCOMB_X38_Y35_N18
\rand|Mod2|auto_generated|divider|divider|op_4~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~9\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_4~9\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_4~11\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~9\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_4~11\);

-- Location: LCCOMB_X38_Y35_N20
\rand|Mod2|auto_generated|divider|divider|op_4~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ = \rand|Mod2|auto_generated|divider|divider|op_4~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_4~11\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\);

-- Location: LCCOMB_X38_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[45]~115\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[36]~112_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\);

-- Location: LCCOMB_X37_Y35_N12
\rand|Mod2|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X37_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X38_Y35_N6
\rand|Mod2|auto_generated|divider|divider|StageOut[44]~116\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[35]~113_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\);

-- Location: LCCOMB_X38_Y35_N4
\rand|Mod2|auto_generated|divider|divider|StageOut[43]~117\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[34]~114_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\);

-- Location: LCCOMB_X37_Y35_N8
\rand|Mod2|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X38_Y35_N22
\rand|Mod2|auto_generated|divider|divider|StageOut[42]~118\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[33]~127_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\);

-- Location: LCCOMB_X37_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[42]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\);

-- Location: LCCOMB_X37_Y35_N4
\rand|Mod2|auto_generated|divider|divider|StageOut[41]~128\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & (\rand|reg_rand|q\(3))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_3~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|reg_rand|q\(3),
	datac => \rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\);

-- Location: LCCOMB_X37_Y35_N16
\rand|Mod2|auto_generated|divider|divider|StageOut[41]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\);

-- Location: LCCOMB_X37_Y35_N2
\rand|Mod2|auto_generated|divider|divider|StageOut[40]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\);

-- Location: LCCOMB_X37_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[40]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ = (!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\);

-- Location: LCCOMB_X36_Y35_N6
\rand|Mod2|auto_generated|divider|divider|op_5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ = \rand|reg_rand|q\(1) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_5~1\ = CARRY(\rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(1),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~1\);

-- Location: LCCOMB_X36_Y35_N8
\rand|Mod2|auto_generated|divider|divider|op_5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|op_5~1\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ & (!\rand|Mod2|auto_generated|divider|divider|op_5~1\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_5~1\) # (GND)))))
-- \rand|Mod2|auto_generated|divider|divider|op_5~3\ = CARRY(((!\rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\)) # (!\rand|Mod2|auto_generated|divider|divider|op_5~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~3\);

-- Location: LCCOMB_X36_Y35_N10
\rand|Mod2|auto_generated|divider|divider|op_5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~3\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_5~3\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\)))))
-- \rand|Mod2|auto_generated|divider|divider|op_5~5\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_5~3\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~5\);

-- Location: LCCOMB_X36_Y35_N12
\rand|Mod2|auto_generated|divider|divider|op_5~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~5\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_5~5\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_5~7\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~6_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~7\);

-- Location: LCCOMB_X36_Y35_N14
\rand|Mod2|auto_generated|divider|divider|op_5~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~7\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_5~7\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_5~9\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_5~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~7\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~8_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~9\);

-- Location: LCCOMB_X36_Y35_N16
\rand|Mod2|auto_generated|divider|divider|op_5~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~10_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~9\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_5~9\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_5~11\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~9\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~10_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~11\);

-- Location: LCCOMB_X36_Y35_N18
\rand|Mod2|auto_generated|divider|divider|op_5~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~11\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_5~11\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_5~13\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_5~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~11\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~12_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_5~13\);

-- Location: LCCOMB_X36_Y35_N20
\rand|Mod2|auto_generated|divider|divider|op_5~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ = !\rand|Mod2|auto_generated|divider|divider|op_5~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_5~13\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\);

-- Location: LCCOMB_X36_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[48]~102\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ = (\rand|reg_rand|q\(1) & \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(1),
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\);

-- Location: LCCOMB_X36_Y35_N26
\rand|Mod2|auto_generated|divider|divider|StageOut[48]~103\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_5~0_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\);

-- Location: LCCOMB_X34_Y36_N20
\rand|reg_rand|q[0]~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|reg_rand|q[0]~feeder_combout\ = \total_Gtimer|reg_Gtim|q\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \total_Gtimer|reg_Gtim|q\(0),
	combout => \rand|reg_rand|q[0]~feeder_combout\);

-- Location: FF_X34_Y36_N21
\rand|reg_rand|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \rand|reg_rand|q[0]~feeder_combout\,
	clrn => \ALT_INV_clr_rand~inputclkctrl_outclk\,
	ena => \ld_rand~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \rand|reg_rand|q\(0));

-- Location: LCCOMB_X35_Y35_N10
\rand|Mod2|auto_generated|divider|divider|op_6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ = \rand|reg_rand|q\(0) $ (VCC)
-- \rand|Mod2|auto_generated|divider|divider|op_6~1\ = CARRY(\rand|reg_rand|q\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datad => VCC,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~1\);

-- Location: LCCOMB_X35_Y35_N12
\rand|Mod2|auto_generated|divider|divider|op_6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|op_6~1\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ & (!\rand|Mod2|auto_generated|divider|divider|op_6~1\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_6~1\) # (GND)))))
-- \rand|Mod2|auto_generated|divider|divider|op_6~3\ = CARRY(((!\rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\)) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_6~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~1\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~3\);

-- Location: LCCOMB_X37_Y35_N10
\rand|Mod2|auto_generated|divider|divider|StageOut[54]~119\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[45]~115_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\);

-- Location: LCCOMB_X36_Y35_N0
\rand|Mod2|auto_generated|divider|divider|StageOut[54]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_5~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\);

-- Location: LCCOMB_X37_Y35_N20
\rand|Mod2|auto_generated|divider|divider|StageOut[53]~120\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[44]~116_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\);

-- Location: LCCOMB_X36_Y35_N22
\rand|Mod2|auto_generated|divider|divider|StageOut[53]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~10_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod2|auto_generated|divider|divider|op_5~10_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\);

-- Location: LCCOMB_X37_Y35_N18
\rand|Mod2|auto_generated|divider|divider|StageOut[52]~121\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[43]~117_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\);

-- Location: LCCOMB_X36_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[52]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_5~8_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\);

-- Location: LCCOMB_X36_Y35_N2
\rand|Mod2|auto_generated|divider|divider|StageOut[51]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_5~6_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\);

-- Location: LCCOMB_X37_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[51]~122\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[42]~118_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\);

-- Location: LCCOMB_X36_Y35_N4
\rand|Mod2|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~4_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_5~4_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X37_Y35_N22
\rand|Mod2|auto_generated|divider|divider|StageOut[50]~123\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\) # 
-- ((!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[41]~128_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\);

-- Location: LCCOMB_X37_Y35_N14
\rand|Mod2|auto_generated|divider|divider|StageOut[49]~129\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & (\rand|reg_rand|q\(2))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod2|auto_generated|divider|divider|op_4~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(2),
	datab => \rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\);

-- Location: LCCOMB_X36_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[49]~101\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_5~2_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod2|auto_generated|divider|divider|op_5~2_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\);

-- Location: LCCOMB_X35_Y35_N14
\rand|Mod2|auto_generated|divider|divider|op_6~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~3\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~3\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\)))))
-- \rand|Mod2|auto_generated|divider|divider|op_6~5\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|op_6~3\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~3\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~4_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~5\);

-- Location: LCCOMB_X35_Y35_N16
\rand|Mod2|auto_generated|divider|divider|op_6~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~6_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~5\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~5\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_6~7\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_6~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~5\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~6_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~7\);

-- Location: LCCOMB_X35_Y35_N18
\rand|Mod2|auto_generated|divider|divider|op_6~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~8_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~7\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~7\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_6~9\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_6~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~7\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~8_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~9\);

-- Location: LCCOMB_X35_Y35_N20
\rand|Mod2|auto_generated|divider|divider|op_6~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~10_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~9\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~9\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_6~11\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ & !\rand|Mod2|auto_generated|divider|divider|op_6~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~9\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~10_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~11\);

-- Location: LCCOMB_X35_Y35_N22
\rand|Mod2|auto_generated|divider|divider|op_6~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~12_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~11\ & ((((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\))))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~11\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\) # (GND))))
-- \rand|Mod2|auto_generated|divider|divider|op_6~13\ = CARRY((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\) # ((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\) # 
-- (!\rand|Mod2|auto_generated|divider|divider|op_6~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~11\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~12_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~13\);

-- Location: LCCOMB_X35_Y35_N24
\rand|Mod2|auto_generated|divider|divider|op_6~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~14_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~13\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~13\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\ & 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\)))
-- \rand|Mod2|auto_generated|divider|divider|op_6~15\ = CARRY((!\rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ & 
-- !\rand|Mod2|auto_generated|divider|divider|op_6~13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\,
	datad => VCC,
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~13\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~14_combout\,
	cout => \rand|Mod2|auto_generated|divider|divider|op_6~15\);

-- Location: LCCOMB_X35_Y35_N26
\rand|Mod2|auto_generated|divider|divider|op_6~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ = \rand|Mod2|auto_generated|divider|divider|op_6~15\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod2|auto_generated|divider|divider|op_6~15\,
	combout => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\);

-- Location: LCCOMB_X35_Y35_N4
\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\rand|Mod2|auto_generated|divider|divider|op_6~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\);

-- Location: LCCOMB_X34_Y35_N24
\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\rand|reg_rand|q\(0))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- ((\rand|Mod2|auto_generated|divider|divider|op_6~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(0),
	datac => \rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\);

-- Location: LCCOMB_X35_Y35_N28
\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|op_6~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_6~6_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[50]~123_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\);

-- Location: LCCOMB_X35_Y35_N0
\rand|Mod2|auto_generated|divider|divider|StageOut[62]~107\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|op_6~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[53]~120_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|op_6~12_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\);

-- Location: LCCOMB_X35_Y35_N6
\rand|Mod2|auto_generated|divider|divider|StageOut[61]~108\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\rand|Mod2|auto_generated|divider|divider|op_6~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_6~10_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~121_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\);

-- Location: LCCOMB_X35_Y35_N8
\rand|Mod2|auto_generated|divider|divider|StageOut[60]~109\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|op_6~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_6~8_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[51]~122_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\);

-- Location: LCCOMB_X35_Y35_N30
\rand|Mod2|auto_generated|divider|divider|StageOut[63]~106\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\rand|Mod2|auto_generated|divider|divider|op_6~14_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_6~14_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[54]~119_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\);

-- Location: LCCOMB_X30_Y35_N22
\rand|Equal2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal2~0_combout\ = (!\rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\ & 
-- !\rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\,
	combout => \rand|Equal2~0_combout\);

-- Location: LCCOMB_X31_Y35_N22
\rand|ShiftLeft2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft2~0_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & 
-- \rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datad => \rand|Equal2~0_combout\,
	combout => \rand|ShiftLeft2~0_combout\);

-- Location: LCCOMB_X37_Y36_N12
\rand|Mod1|auto_generated|divider|divider|op_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_2~0_combout\ = \rand|reg_rand|q\(4) $ (VCC)
-- \rand|Mod1|auto_generated|divider|divider|op_2~1\ = CARRY(\rand|reg_rand|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(4),
	datad => VCC,
	combout => \rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_2~1\);

-- Location: LCCOMB_X37_Y36_N14
\rand|Mod1|auto_generated|divider|divider|op_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_2~2_combout\ = (\rand|reg_rand|q\(5) & (\rand|Mod1|auto_generated|divider|divider|op_2~1\ & VCC)) # (!\rand|reg_rand|q\(5) & (!\rand|Mod1|auto_generated|divider|divider|op_2~1\))
-- \rand|Mod1|auto_generated|divider|divider|op_2~3\ = CARRY((!\rand|reg_rand|q\(5) & !\rand|Mod1|auto_generated|divider|divider|op_2~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(5),
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_2~1\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_2~3\);

-- Location: LCCOMB_X37_Y36_N16
\rand|Mod1|auto_generated|divider|divider|op_2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\ = (\rand|reg_rand|q\(6) & ((GND) # (!\rand|Mod1|auto_generated|divider|divider|op_2~3\))) # (!\rand|reg_rand|q\(6) & (\rand|Mod1|auto_generated|divider|divider|op_2~3\ $ (GND)))
-- \rand|Mod1|auto_generated|divider|divider|op_2~5\ = CARRY((\rand|reg_rand|q\(6)) # (!\rand|Mod1|auto_generated|divider|divider|op_2~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(6),
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_2~3\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_2~5\);

-- Location: LCCOMB_X37_Y36_N18
\rand|Mod1|auto_generated|divider|divider|op_2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\ = (\rand|reg_rand|q\(7) & (!\rand|Mod1|auto_generated|divider|divider|op_2~5\)) # (!\rand|reg_rand|q\(7) & ((\rand|Mod1|auto_generated|divider|divider|op_2~5\) # (GND)))
-- \rand|Mod1|auto_generated|divider|divider|op_2~7\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|op_2~5\) # (!\rand|reg_rand|q\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(7),
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_2~5\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_2~7\);

-- Location: LCCOMB_X37_Y36_N20
\rand|Mod1|auto_generated|divider|divider|op_2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ = \rand|Mod1|auto_generated|divider|divider|op_2~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod1|auto_generated|divider|divider|op_2~7\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\);

-- Location: LCCOMB_X36_Y36_N10
\rand|Mod1|auto_generated|divider|divider|StageOut[27]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\);

-- Location: LCCOMB_X36_Y36_N0
\rand|Mod1|auto_generated|divider|divider|StageOut[27]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \rand|reg_rand|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|reg_rand|q\(7),
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\);

-- Location: LCCOMB_X36_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[26]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\);

-- Location: LCCOMB_X36_Y36_N8
\rand|Mod1|auto_generated|divider|divider|StageOut[26]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ = (\rand|reg_rand|q\(6) & \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(6),
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\);

-- Location: LCCOMB_X37_Y36_N4
\rand|Mod1|auto_generated|divider|divider|StageOut[25]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_2~2_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\);

-- Location: LCCOMB_X36_Y36_N4
\rand|Mod1|auto_generated|divider|divider|StageOut[25]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|reg_rand|q\(5),
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\);

-- Location: LCCOMB_X37_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[24]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ = (\rand|reg_rand|q\(4) & \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(4),
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\);

-- Location: LCCOMB_X36_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[24]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_2~0_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\);

-- Location: LCCOMB_X36_Y36_N18
\rand|Mod1|auto_generated|divider|divider|op_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\ = \rand|reg_rand|q\(3) $ (VCC)
-- \rand|Mod1|auto_generated|divider|divider|op_3~1\ = CARRY(\rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(3),
	datad => VCC,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_3~1\);

-- Location: LCCOMB_X36_Y36_N20
\rand|Mod1|auto_generated|divider|divider|op_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~1\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_3~1\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_3~3\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_3~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_3~1\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_3~3\);

-- Location: LCCOMB_X36_Y36_N22
\rand|Mod1|auto_generated|divider|divider|op_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~3\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_3~3\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_3~5\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\) # (!\rand|Mod1|auto_generated|divider|divider|op_3~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_3~3\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_3~5\);

-- Location: LCCOMB_X36_Y36_N24
\rand|Mod1|auto_generated|divider|divider|op_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & (((!\rand|Mod1|auto_generated|divider|divider|op_3~5\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ & (!\rand|Mod1|auto_generated|divider|divider|op_3~5\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_3~5\) # (GND)))))
-- \rand|Mod1|auto_generated|divider|divider|op_3~7\ = CARRY(((!\rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & !\rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\)) # (!\rand|Mod1|auto_generated|divider|divider|op_3~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_3~5\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_3~7\);

-- Location: LCCOMB_X36_Y36_N26
\rand|Mod1|auto_generated|divider|divider|op_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~7\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_3~7\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_3~9\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\) # (!\rand|Mod1|auto_generated|divider|divider|op_3~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_3~7\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_3~9\);

-- Location: LCCOMB_X36_Y36_N28
\rand|Mod1|auto_generated|divider|divider|op_3~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ = !\rand|Mod1|auto_generated|divider|divider|op_3~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod1|auto_generated|divider|divider|op_3~9\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\);

-- Location: LCCOMB_X36_Y36_N16
\rand|Mod1|auto_generated|divider|divider|StageOut[36]~112\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\rand|reg_rand|q\(7))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(7),
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\);

-- Location: LCCOMB_X35_Y36_N28
\rand|Mod1|auto_generated|divider|divider|StageOut[36]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\);

-- Location: LCCOMB_X35_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[35]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\);

-- Location: LCCOMB_X36_Y36_N14
\rand|Mod1|auto_generated|divider|divider|StageOut[35]~113\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\rand|reg_rand|q\(6))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(6),
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\);

-- Location: LCCOMB_X35_Y36_N12
\rand|Mod1|auto_generated|divider|divider|StageOut[34]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\);

-- Location: LCCOMB_X36_Y36_N12
\rand|Mod1|auto_generated|divider|divider|StageOut[34]~114\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\rand|reg_rand|q\(5))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datab => \rand|reg_rand|q\(5),
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\);

-- Location: LCCOMB_X36_Y36_N6
\rand|Mod1|auto_generated|divider|divider|StageOut[33]~115\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\rand|reg_rand|q\(4))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(4),
	datab => \rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\);

-- Location: LCCOMB_X35_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[33]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\);

-- Location: LCCOMB_X35_Y36_N10
\rand|Mod1|auto_generated|divider|divider|StageOut[32]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\);

-- Location: LCCOMB_X35_Y36_N0
\rand|Mod1|auto_generated|divider|divider|StageOut[32]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ = (\rand|reg_rand|q\(3) & \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(3),
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\);

-- Location: LCCOMB_X35_Y36_N14
\rand|Mod1|auto_generated|divider|divider|op_4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\ = \rand|reg_rand|q\(2) $ (VCC)
-- \rand|Mod1|auto_generated|divider|divider|op_4~1\ = CARRY(\rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(2),
	datad => VCC,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~1\);

-- Location: LCCOMB_X35_Y36_N16
\rand|Mod1|auto_generated|divider|divider|op_4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~1\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_4~1\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_4~3\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~1\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~3\);

-- Location: LCCOMB_X35_Y36_N18
\rand|Mod1|auto_generated|divider|divider|op_4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~3\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_4~3\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_4~5\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_4~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~3\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~5\);

-- Location: LCCOMB_X35_Y36_N20
\rand|Mod1|auto_generated|divider|divider|op_4~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ & (((!\rand|Mod1|auto_generated|divider|divider|op_4~5\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ & (!\rand|Mod1|auto_generated|divider|divider|op_4~5\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_4~5\) # (GND)))))
-- \rand|Mod1|auto_generated|divider|divider|op_4~7\ = CARRY(((!\rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ & !\rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_4~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~5\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~7\);

-- Location: LCCOMB_X35_Y36_N22
\rand|Mod1|auto_generated|divider|divider|op_4~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~7\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_4~7\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_4~9\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_4~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~7\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~9\);

-- Location: LCCOMB_X35_Y36_N24
\rand|Mod1|auto_generated|divider|divider|op_4~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~9\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_4~9\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_4~11\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~9\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_4~11\);

-- Location: LCCOMB_X35_Y36_N26
\rand|Mod1|auto_generated|divider|divider|op_4~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ = \rand|Mod1|auto_generated|divider|divider|op_4~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod1|auto_generated|divider|divider|op_4~11\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\);

-- Location: LCCOMB_X32_Y36_N0
\rand|Mod1|auto_generated|divider|divider|StageOut[45]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\);

-- Location: LCCOMB_X32_Y36_N24
\rand|Mod1|auto_generated|divider|divider|StageOut[45]~103\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\) # 
-- ((!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\);

-- Location: LCCOMB_X32_Y36_N22
\rand|Mod1|auto_generated|divider|divider|StageOut[44]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\);

-- Location: LCCOMB_X35_Y36_N4
\rand|Mod1|auto_generated|divider|divider|StageOut[44]~104\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|op_3~6_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\);

-- Location: LCCOMB_X32_Y36_N4
\rand|Mod1|auto_generated|divider|divider|StageOut[43]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\);

-- Location: LCCOMB_X37_Y36_N10
\rand|Mod1|auto_generated|divider|divider|StageOut[43]~105\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\) # 
-- ((!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\);

-- Location: LCCOMB_X35_Y36_N8
\rand|Mod1|auto_generated|divider|divider|StageOut[42]~106\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\);

-- Location: LCCOMB_X32_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[42]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\);

-- Location: LCCOMB_X35_Y36_N6
\rand|Mod1|auto_generated|divider|divider|StageOut[41]~116\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & (\rand|reg_rand|q\(3))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_3~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(3),
	datab => \rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\);

-- Location: LCCOMB_X32_Y36_N28
\rand|Mod1|auto_generated|divider|divider|StageOut[41]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_4~2_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\);

-- Location: LCCOMB_X32_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[40]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\);

-- Location: LCCOMB_X34_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[40]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ = (\rand|reg_rand|q\(2) & \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(2),
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\);

-- Location: LCCOMB_X32_Y36_N6
\rand|Mod1|auto_generated|divider|divider|op_5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~0_combout\ = \rand|reg_rand|q\(1) $ (VCC)
-- \rand|Mod1|auto_generated|divider|divider|op_5~1\ = CARRY(\rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datad => VCC,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~0_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~1\);

-- Location: LCCOMB_X32_Y36_N8
\rand|Mod1|auto_generated|divider|divider|op_5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~2_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~1\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_5~1\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_5~3\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_5~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~1\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~2_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~3\);

-- Location: LCCOMB_X32_Y36_N10
\rand|Mod1|auto_generated|divider|divider|op_5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~3\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_5~3\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_5~5\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_5~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~3\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~4_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~5\);

-- Location: LCCOMB_X32_Y36_N12
\rand|Mod1|auto_generated|divider|divider|op_5~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~6_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & (((!\rand|Mod1|auto_generated|divider|divider|op_5~5\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ & (!\rand|Mod1|auto_generated|divider|divider|op_5~5\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_5~5\) # (GND)))))
-- \rand|Mod1|auto_generated|divider|divider|op_5~7\ = CARRY(((!\rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & !\rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_5~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~5\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~6_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~7\);

-- Location: LCCOMB_X32_Y36_N14
\rand|Mod1|auto_generated|divider|divider|op_5~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~7\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_5~7\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_5~9\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_5~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~7\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~8_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~9\);

-- Location: LCCOMB_X32_Y36_N16
\rand|Mod1|auto_generated|divider|divider|op_5~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~10_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~9\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_5~9\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_5~11\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_5~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~9\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~10_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~11\);

-- Location: LCCOMB_X32_Y36_N18
\rand|Mod1|auto_generated|divider|divider|op_5~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~12_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~11\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_5~11\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_5~13\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_5~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~11\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~12_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_5~13\);

-- Location: LCCOMB_X32_Y36_N20
\rand|Mod1|auto_generated|divider|divider|op_5~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ = !\rand|Mod1|auto_generated|divider|divider|op_5~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod1|auto_generated|divider|divider|op_5~13\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\);

-- Location: LCCOMB_X31_Y36_N20
\rand|Mod1|auto_generated|divider|divider|StageOut[54]~107\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # 
-- ((!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\);

-- Location: LCCOMB_X31_Y36_N8
\rand|Mod1|auto_generated|divider|divider|StageOut[54]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|Mod1|auto_generated|divider|divider|op_5~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_5~12_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\);

-- Location: LCCOMB_X31_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[53]~108\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\);

-- Location: LCCOMB_X31_Y36_N18
\rand|Mod1|auto_generated|divider|divider|StageOut[53]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|Mod1|auto_generated|divider|divider|op_5~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_5~10_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\);

-- Location: LCCOMB_X31_Y36_N16
\rand|Mod1|auto_generated|divider|divider|StageOut[52]~109\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # 
-- ((!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\);

-- Location: LCCOMB_X31_Y36_N12
\rand|Mod1|auto_generated|divider|divider|StageOut[52]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_5~8_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\);

-- Location: LCCOMB_X32_Y36_N26
\rand|Mod1|auto_generated|divider|divider|StageOut[51]~110\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\);

-- Location: LCCOMB_X31_Y36_N10
\rand|Mod1|auto_generated|divider|divider|StageOut[51]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|Mod1|auto_generated|divider|divider|op_5~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_5~6_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\);

-- Location: LCCOMB_X31_Y36_N22
\rand|Mod1|auto_generated|divider|divider|StageOut[50]~111\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- ((!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\);

-- Location: LCCOMB_X31_Y36_N24
\rand|Mod1|auto_generated|divider|divider|StageOut[50]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_5~4_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\);

-- Location: LCCOMB_X31_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[49]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|Mod1|auto_generated|divider|divider|op_5~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~2_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\);

-- Location: LCCOMB_X31_Y36_N0
\rand|Mod1|auto_generated|divider|divider|StageOut[49]~117\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & (\rand|reg_rand|q\(2))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_4~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datab => \rand|reg_rand|q\(2),
	datac => \rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\);

-- Location: LCCOMB_X31_Y36_N28
\rand|Mod1|auto_generated|divider|divider|StageOut[48]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|reg_rand|q\(1),
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\);

-- Location: LCCOMB_X31_Y36_N14
\rand|Mod1|auto_generated|divider|divider|StageOut[48]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ = (!\rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \rand|Mod1|auto_generated|divider|divider|op_5~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_5~0_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\);

-- Location: LCCOMB_X30_Y36_N4
\rand|Mod1|auto_generated|divider|divider|op_6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~0_combout\ = \rand|reg_rand|q\(0) $ (VCC)
-- \rand|Mod1|auto_generated|divider|divider|op_6~1\ = CARRY(\rand|reg_rand|q\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(0),
	datad => VCC,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~0_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~1\);

-- Location: LCCOMB_X30_Y36_N6
\rand|Mod1|auto_generated|divider|divider|op_6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~2_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~1\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~1\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_6~3\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_6~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~1\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~2_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~3\);

-- Location: LCCOMB_X30_Y36_N8
\rand|Mod1|auto_generated|divider|divider|op_6~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~4_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~3\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~3\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_6~5\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_6~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~3\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~4_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~5\);

-- Location: LCCOMB_X30_Y36_N10
\rand|Mod1|auto_generated|divider|divider|op_6~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~6_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ & (((!\rand|Mod1|auto_generated|divider|divider|op_6~5\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ & (!\rand|Mod1|auto_generated|divider|divider|op_6~5\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ & ((\rand|Mod1|auto_generated|divider|divider|op_6~5\) # (GND)))))
-- \rand|Mod1|auto_generated|divider|divider|op_6~7\ = CARRY(((!\rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ & !\rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_6~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~5\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~6_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~7\);

-- Location: LCCOMB_X30_Y36_N12
\rand|Mod1|auto_generated|divider|divider|op_6~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~8_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~7\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~7\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_6~9\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_6~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~7\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~8_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~9\);

-- Location: LCCOMB_X30_Y36_N14
\rand|Mod1|auto_generated|divider|divider|op_6~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~10_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~9\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~9\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_6~11\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ & !\rand|Mod1|auto_generated|divider|divider|op_6~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~9\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~10_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~11\);

-- Location: LCCOMB_X30_Y36_N16
\rand|Mod1|auto_generated|divider|divider|op_6~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~12_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~11\ & ((((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\))))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~11\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # (GND))))
-- \rand|Mod1|auto_generated|divider|divider|op_6~13\ = CARRY((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # ((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # 
-- (!\rand|Mod1|auto_generated|divider|divider|op_6~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~11\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~12_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~13\);

-- Location: LCCOMB_X30_Y36_N18
\rand|Mod1|auto_generated|divider|divider|op_6~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~14_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~13\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~13\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ & 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))
-- \rand|Mod1|auto_generated|divider|divider|op_6~15\ = CARRY((!\rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|op_6~13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\,
	datad => VCC,
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~13\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~14_combout\,
	cout => \rand|Mod1|auto_generated|divider|divider|op_6~15\);

-- Location: LCCOMB_X30_Y36_N20
\rand|Mod1|auto_generated|divider|divider|op_6~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ = \rand|Mod1|auto_generated|divider|divider|op_6~15\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod1|auto_generated|divider|divider|op_6~15\,
	combout => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\);

-- Location: LCCOMB_X30_Y36_N2
\rand|Mod1|auto_generated|divider|divider|StageOut[63]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|op_6~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_6~14_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\);

-- Location: LCCOMB_X30_Y36_N24
\rand|Mod1|auto_generated|divider|divider|StageOut[61]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|op_6~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_6~10_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\);

-- Location: LCCOMB_X30_Y36_N30
\rand|Mod1|auto_generated|divider|divider|StageOut[60]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (\rand|Mod1|auto_generated|divider|divider|op_6~8_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_6~8_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\);

-- Location: LCCOMB_X30_Y36_N22
\rand|Mod1|auto_generated|divider|divider|StageOut[62]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|op_6~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|op_6~12_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\);

-- Location: LCCOMB_X30_Y35_N16
\rand|Equal1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal1~0_combout\ = (!\rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\,
	combout => \rand|Equal1~0_combout\);

-- Location: LCCOMB_X29_Y35_N20
\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|reg_rand|q\(0)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\rand|Mod1|auto_generated|divider|divider|op_6~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod1|auto_generated|divider|divider|op_6~0_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\);

-- Location: LCCOMB_X30_Y36_N0
\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|op_6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_6~2_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\);

-- Location: LCCOMB_X30_Y36_N28
\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\) # 
-- (\rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (\rand|Mod1|auto_generated|divider|divider|op_6~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_6~6_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\);

-- Location: LCCOMB_X31_Y35_N16
\rand|ShiftLeft1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft1~0_combout\ = (\rand|Equal1~0_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Equal1~0_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	combout => \rand|ShiftLeft1~0_combout\);

-- Location: LCCOMB_X35_Y35_N2
\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ = (\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\) # 
-- ((\rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\)))) # (!\rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod2|auto_generated|divider|divider|op_6~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|op_6~4_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[49]~129_combout\,
	combout => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\);

-- Location: LCCOMB_X30_Y36_N26
\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\ = (\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # 
-- ((\rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\rand|Mod1|auto_generated|divider|divider|op_6~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110110101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|op_6~4_combout\,
	combout => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\);

-- Location: LCCOMB_X31_Y35_N2
\rand|S_3~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~10_combout\ = (\rand|ShiftLeft2~0_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ $ (((\rand|ShiftLeft1~0_combout\ & \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\))))) # 
-- (!\rand|ShiftLeft2~0_combout\ & (\rand|ShiftLeft1~0_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft2~0_combout\,
	datab => \rand|ShiftLeft1~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|S_3~10_combout\);

-- Location: IOIBUF_X29_Y39_N8
\STG[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_STG(2),
	o => \STG[2]~input_o\);

-- Location: IOIBUF_X26_Y39_N22
\STG[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_STG(0),
	o => \STG[0]~input_o\);

-- Location: LCCOMB_X30_Y35_N2
\rand|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~2_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\ $ 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\ & 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\ $ (!\rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[62]~98_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[61]~108_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[61]~99_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[62]~107_combout\,
	combout => \rand|Equal0~2_combout\);

-- Location: LCCOMB_X30_Y35_N14
\rand|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~6_combout\ = \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\ $ (\rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\,
	combout => \rand|Equal0~6_combout\);

-- Location: LCCOMB_X31_Y35_N18
\rand|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~3_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ $ 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\)))) # (!\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ & 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ $ (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	combout => \rand|Equal0~3_combout\);

-- Location: LCCOMB_X31_Y35_N4
\rand|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & ((\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ $ (\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\)) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\))) # (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & ((\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\) # 
-- (\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ $ (\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110111111110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|Equal0~4_combout\);

-- Location: LCCOMB_X30_Y35_N24
\rand|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~5_combout\ = (\rand|Equal0~3_combout\ & (!\rand|Equal0~4_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\ $ (!\rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[60]~100_combout\,
	datab => \rand|Equal0~3_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[60]~109_combout\,
	datad => \rand|Equal0~4_combout\,
	combout => \rand|Equal0~5_combout\);

-- Location: LCCOMB_X30_Y35_N0
\rand|Mux5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~4_combout\ = (!\STG[0]~input_o\ & (((\rand|Equal0~6_combout\) # (!\rand|Equal0~5_combout\)) # (!\rand|Equal0~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000101010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[0]~input_o\,
	datab => \rand|Equal0~2_combout\,
	datac => \rand|Equal0~6_combout\,
	datad => \rand|Equal0~5_combout\,
	combout => \rand|Mux5~4_combout\);

-- Location: IOIBUF_X26_Y39_N29
\STG[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_STG(1),
	o => \STG[1]~input_o\);

-- Location: LCCOMB_X32_Y34_N12
\rand|Equal2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal2~2_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ & (\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) $ (!\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\)))) # 
-- (!\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ & (!\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) $ (!\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datab => \rand|reg_rand|q\(1),
	datac => \rand|reg_rand|q\(0),
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	combout => \rand|Equal2~2_combout\);

-- Location: LCCOMB_X32_Y34_N18
\rand|Equal2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal2~1_combout\ = (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & \rand|Equal2~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datad => \rand|Equal2~0_combout\,
	combout => \rand|Equal2~1_combout\);

-- Location: LCCOMB_X31_Y35_N10
\rand|Equal1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal1~1_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (\rand|reg_rand|q\(1) & (\rand|reg_rand|q\(0) $ (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (!\rand|reg_rand|q\(1) & (\rand|reg_rand|q\(0) $ (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datab => \rand|reg_rand|q\(0),
	datac => \rand|reg_rand|q\(1),
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	combout => \rand|Equal1~1_combout\);

-- Location: LCCOMB_X31_Y35_N20
\rand|Equal1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal1~2_combout\ = (!\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & (\rand|Equal1~0_combout\ & \rand|Equal1~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \rand|Equal1~0_combout\,
	datad => \rand|Equal1~1_combout\,
	combout => \rand|Equal1~2_combout\);

-- Location: LCCOMB_X32_Y34_N26
\rand|Mux5~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~3_combout\ = (!\rand|Equal1~2_combout\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\) # (!\rand|Equal2~1_combout\)) # (!\rand|Equal2~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Equal2~2_combout\,
	datab => \rand|Equal2~1_combout\,
	datac => \rand|Equal1~2_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	combout => \rand|Mux5~3_combout\);

-- Location: LCCOMB_X30_Y35_N4
\rand|Mux5~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~6_combout\ = (\STG[2]~input_o\ & (\rand|Mux5~4_combout\ & (!\STG[1]~input_o\ & \rand|Mux5~3_combout\))) # (!\STG[2]~input_o\ & (((\STG[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101100001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[2]~input_o\,
	datab => \rand|Mux5~4_combout\,
	datac => \STG[1]~input_o\,
	datad => \rand|Mux5~3_combout\,
	combout => \rand|Mux5~6_combout\);

-- Location: LCCOMB_X30_Y35_N26
\rand|Mux5~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~5_combout\ = (\STG[2]~input_o\) # ((\STG[1]~input_o\ & \rand|Mux5~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[2]~input_o\,
	datac => \STG[1]~input_o\,
	datad => \rand|Mux5~4_combout\,
	combout => \rand|Mux5~5_combout\);

-- Location: LCCOMB_X31_Y37_N22
\rand|Mux5~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~11_combout\ = (\rand|Mux5~5_combout\ & ((\rand|Mux5~6_combout\) # ((!\STG[1]~input_o\ & !\STG[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[1]~input_o\,
	datab => \rand|Mux5~5_combout\,
	datac => \rand|Mux5~6_combout\,
	datad => \STG[0]~input_o\,
	combout => \rand|Mux5~11_combout\);

-- Location: LCCOMB_X31_Y34_N26
\rand|Mux2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux2~0_combout\ = (\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) & \rand|reg_rand|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux2~0_combout\);

-- Location: LCCOMB_X31_Y37_N26
\rand|Mux2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux2~1_combout\ = (\rand|Mux5~6_combout\ & (((!\rand|Mux5~11_combout\)) # (!\rand|S_3~10_combout\))) # (!\rand|Mux5~6_combout\ & (((\rand|Mux5~11_combout\ & !\rand|Mux2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100110001111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|S_3~10_combout\,
	datab => \rand|Mux5~6_combout\,
	datac => \rand|Mux5~11_combout\,
	datad => \rand|Mux2~0_combout\,
	combout => \rand|Mux2~1_combout\);

-- Location: LCCOMB_X37_Y36_N22
\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \rand|reg_rand|q\(5) $ (VCC)
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(5),
	datad => VCC,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X37_Y36_N24
\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\rand|reg_rand|q\(6) & (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\rand|reg_rand|q\(6) & 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\rand|reg_rand|q\(6) & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(6),
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X37_Y36_N26
\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\rand|reg_rand|q\(7) & (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # (!\rand|reg_rand|q\(7) & 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\rand|reg_rand|q\(7) & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(7),
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X37_Y36_N28
\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X37_Y36_N0
\rand|Mod0|auto_generated|divider|divider|StageOut[27]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ = (\rand|reg_rand|q\(7) & \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(7),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\);

-- Location: LCCOMB_X38_Y36_N8
\rand|Mod0|auto_generated|divider|divider|StageOut[27]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\);

-- Location: LCCOMB_X38_Y36_N26
\rand|Mod0|auto_generated|divider|divider|StageOut[26]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\);

-- Location: LCCOMB_X37_Y36_N6
\rand|Mod0|auto_generated|divider|divider|StageOut[26]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\ = (\rand|reg_rand|q\(6) & \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(6),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\);

-- Location: LCCOMB_X37_Y36_N8
\rand|Mod0|auto_generated|divider|divider|StageOut[25]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ = (\rand|reg_rand|q\(5) & \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(5),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\);

-- Location: LCCOMB_X38_Y36_N0
\rand|Mod0|auto_generated|divider|divider|StageOut[25]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\);

-- Location: LCCOMB_X38_Y36_N10
\rand|Mod0|auto_generated|divider|divider|StageOut[24]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\ = (\rand|reg_rand|q\(4) & \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(4),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\);

-- Location: LCCOMB_X38_Y36_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[24]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\ = (\rand|reg_rand|q\(4) & !\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(4),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\);

-- Location: LCCOMB_X38_Y36_N16
\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\,
	datad => VCC,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X38_Y36_N18
\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X38_Y36_N20
\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\)))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X38_Y36_N22
\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\);

-- Location: LCCOMB_X38_Y36_N24
\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X38_Y34_N12
\rand|Mod0|auto_generated|divider|divider|StageOut[36]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\);

-- Location: LCCOMB_X38_Y36_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[36]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\rand|reg_rand|q\(7))) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \rand|reg_rand|q\(7),
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\);

-- Location: LCCOMB_X38_Y34_N30
\rand|Mod0|auto_generated|divider|divider|StageOut[35]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\);

-- Location: LCCOMB_X38_Y36_N30
\rand|Mod0|auto_generated|divider|divider|StageOut[35]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\rand|reg_rand|q\(6)))) 
-- # (!\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datac => \rand|reg_rand|q\(6),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\);

-- Location: LCCOMB_X38_Y36_N28
\rand|Mod0|auto_generated|divider|divider|StageOut[34]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\rand|reg_rand|q\(5)))) 
-- # (!\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datac => \rand|reg_rand|q\(5),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\);

-- Location: LCCOMB_X38_Y34_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[34]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\);

-- Location: LCCOMB_X38_Y36_N14
\rand|Mod0|auto_generated|divider|divider|StageOut[33]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|reg_rand|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|reg_rand|q\(4),
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\);

-- Location: LCCOMB_X38_Y34_N14
\rand|Mod0|auto_generated|divider|divider|StageOut[33]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\);

-- Location: LCCOMB_X38_Y34_N10
\rand|Mod0|auto_generated|divider|divider|StageOut[32]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|reg_rand|q\(3),
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\);

-- Location: LCCOMB_X38_Y34_N28
\rand|Mod0|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|reg_rand|q\(3),
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X38_Y34_N16
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datad => VCC,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X38_Y34_N18
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X38_Y34_N20
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\)))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X38_Y34_N22
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\);

-- Location: LCCOMB_X38_Y34_N24
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\))))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # (GND))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\);

-- Location: LCCOMB_X38_Y34_N26
\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ = !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\);

-- Location: LCCOMB_X37_Y34_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[45]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\);

-- Location: LCCOMB_X38_Y34_N8
\rand|Mod0|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X37_Y34_N6
\rand|Mod0|auto_generated|divider|divider|StageOut[44]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\);

-- Location: LCCOMB_X38_Y36_N12
\rand|Mod0|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\) # 
-- ((!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X38_Y34_N6
\rand|Mod0|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- ((!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X37_Y34_N12
\rand|Mod0|auto_generated|divider|divider|StageOut[43]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\);

-- Location: LCCOMB_X36_Y34_N24
\rand|Mod0|auto_generated|divider|divider|StageOut[42]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\);

-- Location: LCCOMB_X38_Y36_N6
\rand|Mod0|auto_generated|divider|divider|StageOut[42]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (\rand|reg_rand|q\(4))) 
-- # (!\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(4),
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\);

-- Location: LCCOMB_X37_Y34_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[41]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ = (\rand|reg_rand|q\(3) & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(3),
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\);

-- Location: LCCOMB_X37_Y34_N24
\rand|Mod0|auto_generated|divider|divider|StageOut[41]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\);

-- Location: LCCOMB_X36_Y34_N26
\rand|Mod0|auto_generated|divider|divider|StageOut[40]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|reg_rand|q\(2),
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\);

-- Location: LCCOMB_X36_Y34_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[40]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \rand|reg_rand|q\(2),
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\);

-- Location: LCCOMB_X36_Y34_N6
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\,
	datad => VCC,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X36_Y34_N8
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X36_Y34_N10
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\)))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X36_Y34_N12
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X36_Y34_N14
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\))))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # (GND))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X36_Y34_N16
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X36_Y34_N18
\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X35_Y34_N30
\rand|Mod0|auto_generated|divider|divider|StageOut[49]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\);

-- Location: LCCOMB_X32_Y34_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[49]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\ = (\rand|reg_rand|q\(2) & \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|reg_rand|q\(2),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\);

-- Location: LCCOMB_X32_Y34_N28
\rand|Mod0|auto_generated|divider|divider|StageOut[48]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\ = (\rand|reg_rand|q\(1) & !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(1),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\);

-- Location: LCCOMB_X32_Y34_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[48]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\ = (\rand|reg_rand|q\(1) & \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|reg_rand|q\(1),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\);

-- Location: LCCOMB_X35_Y34_N4
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ = (((\rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[48]~81_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[48]~80_combout\,
	datad => VCC,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\);

-- Location: LCCOMB_X35_Y34_N6
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\);

-- Location: LCCOMB_X38_Y34_N0
\rand|Mod0|auto_generated|divider|divider|StageOut[54]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- ((!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\);

-- Location: LCCOMB_X36_Y34_N0
\rand|Mod0|auto_generated|divider|divider|StageOut[54]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\);

-- Location: LCCOMB_X36_Y34_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[53]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\);

-- Location: LCCOMB_X36_Y34_N28
\rand|Mod0|auto_generated|divider|divider|StageOut[53]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\);

-- Location: LCCOMB_X38_Y34_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[52]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\);

-- Location: LCCOMB_X36_Y34_N20
\rand|Mod0|auto_generated|divider|divider|StageOut[52]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ & !\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\);

-- Location: LCCOMB_X36_Y34_N30
\rand|Mod0|auto_generated|divider|divider|StageOut[51]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- ((!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\);

-- Location: LCCOMB_X35_Y34_N24
\rand|Mod0|auto_generated|divider|divider|StageOut[51]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\);

-- Location: LCCOMB_X35_Y34_N22
\rand|Mod0|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & 
-- (\rand|reg_rand|q\(3))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(3),
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X35_Y34_N28
\rand|Mod0|auto_generated|divider|divider|StageOut[50]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\);

-- Location: LCCOMB_X35_Y34_N8
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\)))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\);

-- Location: LCCOMB_X35_Y34_N10
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[51]~85_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\);

-- Location: LCCOMB_X35_Y34_N12
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\))))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\) # (GND))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[52]~84_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\);

-- Location: LCCOMB_X35_Y34_N14
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\ & 
-- (!\rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\)))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ = CARRY((!\rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[53]~83_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\);

-- Location: LCCOMB_X35_Y34_N16
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ & ((((\rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\))))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\) # (GND))))
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ = CARRY((\rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[54]~82_combout\,
	datad => VCC,
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\,
	cout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\);

-- Location: LCCOMB_X35_Y34_N18
\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ = !\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\,
	combout => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\);

-- Location: LCCOMB_X34_Y34_N30
\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\) # 
-- (\rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~78_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[49]~79_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\);

-- Location: LCCOMB_X34_Y34_N4
\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\rand|reg_rand|q\(1)))) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	datab => \rand|reg_rand|q\(1),
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\);

-- Location: LCCOMB_X36_Y34_N22
\rand|ShiftLeft0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~4_combout\ = (!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\) # (\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \rand|ShiftLeft0~4_combout\);

-- Location: LCCOMB_X35_Y34_N20
\rand|ShiftLeft0~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~14_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\) # ((\rand|ShiftLeft0~4_combout\) # ((!\rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datad => \rand|ShiftLeft0~4_combout\,
	combout => \rand|ShiftLeft0~14_combout\);

-- Location: LCCOMB_X35_Y34_N0
\rand|ShiftLeft0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~2_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\) # ((\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\) # (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\,
	combout => \rand|ShiftLeft0~2_combout\);

-- Location: LCCOMB_X35_Y34_N26
\rand|ShiftLeft0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~3_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # (\rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\,
	combout => \rand|ShiftLeft0~3_combout\);

-- Location: LCCOMB_X34_Y34_N0
\rand|ShiftLeft0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~5_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\rand|ShiftLeft0~14_combout\) # ((\rand|ShiftLeft0~3_combout\)))) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\rand|ShiftLeft0~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft0~14_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datac => \rand|ShiftLeft0~2_combout\,
	datad => \rand|ShiftLeft0~3_combout\,
	combout => \rand|ShiftLeft0~5_combout\);

-- Location: LCCOMB_X35_Y34_N2
\rand|Mod0|auto_generated|divider|divider|StageOut[59]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\ = (\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- ((\rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\)))) # (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[50]~77_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\);

-- Location: LCCOMB_X34_Y34_N22
\rand|ShiftLeft0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~6_combout\ = (!\rand|ShiftLeft0~5_combout\ & !\rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|ShiftLeft0~5_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\,
	combout => \rand|ShiftLeft0~6_combout\);

-- Location: LCCOMB_X34_Y34_N24
\rand|ShiftLeft0~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~13_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & (\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ & (\rand|ShiftLeft0~6_combout\ & \rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~13_combout\);

-- Location: LCCOMB_X31_Y37_N16
\rand|Mux2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux2~2_combout\ = \rand|ShiftLeft0~13_combout\ $ (((!\STG[0]~input_o\ & \rand|Mux2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \STG[0]~input_o\,
	datac => \rand|ShiftLeft0~13_combout\,
	datad => \rand|Mux2~0_combout\,
	combout => \rand|Mux2~2_combout\);

-- Location: LCCOMB_X31_Y37_N14
\rand|Mux2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux2~3_combout\ = (\rand|Mux5~5_combout\ & (!\rand|Mux2~1_combout\)) # (!\rand|Mux5~5_combout\ & ((\rand|Mux2~2_combout\) # (\rand|Mux2~1_combout\ $ (!\STG[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111101011001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux2~1_combout\,
	datab => \STG[0]~input_o\,
	datac => \rand|Mux5~5_combout\,
	datad => \rand|Mux2~2_combout\,
	combout => \rand|Mux2~3_combout\);

-- Location: IOIBUF_X24_Y39_N29
\SW[6]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(6),
	o => \SW[6]~input_o\);

-- Location: LCCOMB_X34_Y34_N2
\rand|ShiftLeft0~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~12_combout\ = (!\rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\ & (!\rand|reg_rand|q\(0) & (\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & !\rand|ShiftLeft0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\,
	datab => \rand|reg_rand|q\(0),
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datad => \rand|ShiftLeft0~5_combout\,
	combout => \rand|ShiftLeft0~12_combout\);

-- Location: LCCOMB_X31_Y34_N10
\rand|Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux3~0_combout\ = (!\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) & \rand|reg_rand|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux3~0_combout\);

-- Location: LCCOMB_X31_Y37_N30
\rand|Mux3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux3~2_combout\ = (\rand|ShiftLeft0~12_combout\ & (\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ $ (((!\STG[0]~input_o\ & \rand|Mux3~0_combout\))))) # (!\rand|ShiftLeft0~12_combout\ & (!\STG[0]~input_o\ & 
-- (\rand|Mux3~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001101000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft0~12_combout\,
	datab => \STG[0]~input_o\,
	datac => \rand|Mux3~0_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	combout => \rand|Mux3~2_combout\);

-- Location: LCCOMB_X31_Y35_N30
\rand|ShiftLeft1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft1~1_combout\ = (\rand|Equal1~0_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Equal1~0_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	combout => \rand|ShiftLeft1~1_combout\);

-- Location: LCCOMB_X31_Y35_N12
\rand|ShiftLeft2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft2~1_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & 
-- \rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datad => \rand|Equal2~0_combout\,
	combout => \rand|ShiftLeft2~1_combout\);

-- Location: LCCOMB_X31_Y34_N16
\rand|S_3~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~11_combout\ = (\rand|ShiftLeft1~1_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\ $ (((\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \rand|ShiftLeft2~1_combout\))))) # 
-- (!\rand|ShiftLeft1~1_combout\ & (((\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \rand|ShiftLeft2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft1~1_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|ShiftLeft2~1_combout\,
	combout => \rand|S_3~11_combout\);

-- Location: LCCOMB_X31_Y37_N8
\rand|Mux3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux3~1_combout\ = (\rand|Mux5~11_combout\ & ((\rand|Mux5~6_combout\ & ((\rand|S_3~11_combout\))) # (!\rand|Mux5~6_combout\ & (\rand|Mux3~0_combout\)))) # (!\rand|Mux5~11_combout\ & (((\rand|Mux5~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux5~11_combout\,
	datab => \rand|Mux3~0_combout\,
	datac => \rand|Mux5~6_combout\,
	datad => \rand|S_3~11_combout\,
	combout => \rand|Mux3~1_combout\);

-- Location: LCCOMB_X31_Y37_N4
\rand|Mux3~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux3~3_combout\ = (\rand|Mux5~5_combout\ & (((\rand|Mux3~1_combout\)))) # (!\rand|Mux5~5_combout\ & (\rand|Mux3~2_combout\ & (\rand|Mux3~1_combout\ $ (\STG[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux3~2_combout\,
	datab => \rand|Mux5~5_combout\,
	datac => \rand|Mux3~1_combout\,
	datad => \STG[0]~input_o\,
	combout => \rand|Mux3~3_combout\);

-- Location: LCCOMB_X32_Y35_N26
\comparator_rand|comp_rand|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~4_combout\ = (\SW[7]~input_o\ & (\rand|Mux2~3_combout\ & (\SW[6]~input_o\ $ (!\rand|Mux3~3_combout\)))) # (!\SW[7]~input_o\ & (!\rand|Mux2~3_combout\ & (\SW[6]~input_o\ $ (!\rand|Mux3~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[7]~input_o\,
	datab => \rand|Mux2~3_combout\,
	datac => \SW[6]~input_o\,
	datad => \rand|Mux3~3_combout\,
	combout => \comparator_rand|comp_rand|Equal0~4_combout\);

-- Location: LCCOMB_X30_Y35_N20
\rand|Mux0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux0~2_combout\ = (\rand|Mux5~4_combout\ & ((\STG[2]~input_o\ & (!\STG[1]~input_o\ & \rand|Mux5~3_combout\)) # (!\STG[2]~input_o\ & (\STG[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100100001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[2]~input_o\,
	datab => \rand|Mux5~4_combout\,
	datac => \STG[1]~input_o\,
	datad => \rand|Mux5~3_combout\,
	combout => \rand|Mux0~2_combout\);

-- Location: LCCOMB_X31_Y35_N14
\rand|ShiftLeft2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft2~4_combout\ = (\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & (\rand|Equal2~0_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & 
-- !\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datab => \rand|Equal2~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	combout => \rand|ShiftLeft2~4_combout\);

-- Location: LCCOMB_X31_Y35_N8
\rand|ShiftLeft1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft1~4_combout\ = (!\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & (\rand|Equal1~0_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \rand|Equal1~0_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|ShiftLeft1~4_combout\);

-- Location: LCCOMB_X32_Y35_N24
\rand|S_3~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~12_combout\ = (\rand|ShiftLeft2~4_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ $ (((\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\) # (!\rand|ShiftLeft1~4_combout\))))) # 
-- (!\rand|ShiftLeft2~4_combout\ & (((!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & \rand|ShiftLeft1~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft2~4_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datad => \rand|ShiftLeft1~4_combout\,
	combout => \rand|S_3~12_combout\);

-- Location: LCCOMB_X34_Y34_N20
\rand|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux1~0_combout\ = (!\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & !\rand|reg_rand|q\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|Mux1~0_combout\);

-- Location: LCCOMB_X30_Y35_N10
\rand|Equal0~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Equal0~7_combout\ = (\rand|Equal0~5_combout\ & (\rand|Equal0~2_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\ $ (!\rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Equal0~5_combout\,
	datab => \rand|Equal0~2_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[63]~97_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[63]~106_combout\,
	combout => \rand|Equal0~7_combout\);

-- Location: LCCOMB_X30_Y35_N30
\rand|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux0~0_combout\ = (!\STG[2]~input_o\ & ((\STG[1]~input_o\ & (!\STG[0]~input_o\ & \rand|Equal0~7_combout\)) # (!\STG[1]~input_o\ & (\STG[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000011000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[1]~input_o\,
	datab => \STG[0]~input_o\,
	datac => \STG[2]~input_o\,
	datad => \rand|Equal0~7_combout\,
	combout => \rand|Mux0~0_combout\);

-- Location: LCCOMB_X34_Y34_N10
\rand|Mux0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux0~1_combout\ = (!\rand|ShiftLeft0~5_combout\ & (\rand|Mux0~0_combout\ & \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \rand|ShiftLeft0~5_combout\,
	datac => \rand|Mux0~0_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[59]~86_combout\,
	combout => \rand|Mux0~1_combout\);

-- Location: LCCOMB_X32_Y35_N18
\rand|Mux1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux1~1_combout\ = (\rand|Mux0~2_combout\ & (\rand|S_3~12_combout\)) # (!\rand|Mux0~2_combout\ & (((\rand|Mux1~0_combout\ & \rand|Mux0~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux0~2_combout\,
	datab => \rand|S_3~12_combout\,
	datac => \rand|Mux1~0_combout\,
	datad => \rand|Mux0~1_combout\,
	combout => \rand|Mux1~1_combout\);

-- Location: IOIBUF_X29_Y39_N15
\SW[8]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(8),
	o => \SW[8]~input_o\);

-- Location: LCCOMB_X30_Y34_N20
\rand|Mux4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux4~0_combout\ = (!\rand|reg_rand|q\(1) & (\rand|reg_rand|q\(0) & \rand|reg_rand|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datac => \rand|reg_rand|q\(0),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux4~0_combout\);

-- Location: LCCOMB_X34_Y34_N8
\rand|ShiftLeft0~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~11_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ & (\rand|ShiftLeft0~6_combout\ & \rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~11_combout\);

-- Location: LCCOMB_X31_Y37_N12
\rand|Mux4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux4~2_combout\ = \rand|ShiftLeft0~11_combout\ $ (((!\STG[0]~input_o\ & \rand|Mux4~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \STG[0]~input_o\,
	datac => \rand|Mux4~0_combout\,
	datad => \rand|ShiftLeft0~11_combout\,
	combout => \rand|Mux4~2_combout\);

-- Location: LCCOMB_X31_Y35_N24
\rand|ShiftLeft2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft2~3_combout\ = (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & (\rand|Equal2~0_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & 
-- !\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datab => \rand|Equal2~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	combout => \rand|ShiftLeft2~3_combout\);

-- Location: LCCOMB_X31_Y35_N6
\rand|ShiftLeft1~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft1~3_combout\ = (!\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & (\rand|Equal1~0_combout\ & 
-- \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \rand|Equal1~0_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|ShiftLeft1~3_combout\);

-- Location: LCCOMB_X32_Y35_N6
\rand|S_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~8_combout\ = (\rand|ShiftLeft2~3_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ $ (((\rand|ShiftLeft1~3_combout\ & \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\))))) # 
-- (!\rand|ShiftLeft2~3_combout\ & (\rand|ShiftLeft1~3_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110101011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft2~3_combout\,
	datab => \rand|ShiftLeft1~3_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	combout => \rand|S_3~8_combout\);

-- Location: LCCOMB_X31_Y37_N18
\rand|Mux4~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux4~1_combout\ = (\rand|Mux5~6_combout\ & (((!\rand|S_3~8_combout\) # (!\rand|Mux5~11_combout\)))) # (!\rand|Mux5~6_combout\ & (!\rand|Mux4~0_combout\ & (\rand|Mux5~11_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001110011011100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux4~0_combout\,
	datab => \rand|Mux5~6_combout\,
	datac => \rand|Mux5~11_combout\,
	datad => \rand|S_3~8_combout\,
	combout => \rand|Mux4~1_combout\);

-- Location: LCCOMB_X31_Y37_N2
\rand|Mux4~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux4~3_combout\ = (\rand|Mux5~5_combout\ & (((!\rand|Mux4~1_combout\)))) # (!\rand|Mux5~5_combout\ & ((\rand|Mux4~2_combout\) # (\STG[0]~input_o\ $ (!\rand|Mux4~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111011111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux4~2_combout\,
	datab => \STG[0]~input_o\,
	datac => \rand|Mux5~5_combout\,
	datad => \rand|Mux4~1_combout\,
	combout => \rand|Mux4~3_combout\);

-- Location: IOIBUF_X31_Y39_N29
\SW[4]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(4),
	o => \SW[4]~input_o\);

-- Location: LCCOMB_X30_Y34_N14
\rand|Mux5~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~7_combout\ = (!\rand|reg_rand|q\(1) & (!\rand|reg_rand|q\(0) & \rand|reg_rand|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datac => \rand|reg_rand|q\(0),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux5~7_combout\);

-- Location: LCCOMB_X31_Y37_N10
\rand|Mux5~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~9_combout\ = (\rand|Mux5~7_combout\ & (\STG[0]~input_o\ $ (((\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\) # (!\rand|ShiftLeft0~12_combout\))))) # (!\rand|Mux5~7_combout\ & (((\rand|ShiftLeft0~12_combout\ & 
-- !\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011010010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux5~7_combout\,
	datab => \STG[0]~input_o\,
	datac => \rand|ShiftLeft0~12_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	combout => \rand|Mux5~9_combout\);

-- Location: LCCOMB_X31_Y35_N0
\rand|S_3~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~9_combout\ = (\rand|ShiftLeft1~3_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ $ (((\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\) # (!\rand|ShiftLeft2~3_combout\))))) # 
-- (!\rand|ShiftLeft1~3_combout\ & (\rand|ShiftLeft2~3_combout\ & ((!\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft1~3_combout\,
	datab => \rand|ShiftLeft2~3_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	combout => \rand|S_3~9_combout\);

-- Location: LCCOMB_X31_Y37_N24
\rand|Mux5~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~8_combout\ = (\rand|Mux5~6_combout\ & (((\rand|S_3~9_combout\) # (!\rand|Mux5~11_combout\)))) # (!\rand|Mux5~6_combout\ & (\rand|Mux5~7_combout\ & (\rand|Mux5~11_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110000101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux5~7_combout\,
	datab => \rand|Mux5~6_combout\,
	datac => \rand|Mux5~11_combout\,
	datad => \rand|S_3~9_combout\,
	combout => \rand|Mux5~8_combout\);

-- Location: LCCOMB_X31_Y37_N28
\rand|Mux5~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~10_combout\ = (\rand|Mux5~5_combout\ & (((\rand|Mux5~8_combout\)))) # (!\rand|Mux5~5_combout\ & (\rand|Mux5~9_combout\ & (\STG[0]~input_o\ $ (\rand|Mux5~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux5~9_combout\,
	datab => \STG[0]~input_o\,
	datac => \rand|Mux5~5_combout\,
	datad => \rand|Mux5~8_combout\,
	combout => \rand|Mux5~10_combout\);

-- Location: IOIBUF_X34_Y39_N1
\SW[5]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(5),
	o => \SW[5]~input_o\);

-- Location: LCCOMB_X32_Y35_N12
\comparator_rand|comp_rand|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~3_combout\ = (\rand|Mux4~3_combout\ & (\SW[5]~input_o\ & (\SW[4]~input_o\ $ (!\rand|Mux5~10_combout\)))) # (!\rand|Mux4~3_combout\ & (!\SW[5]~input_o\ & (\SW[4]~input_o\ $ (!\rand|Mux5~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux4~3_combout\,
	datab => \SW[4]~input_o\,
	datac => \rand|Mux5~10_combout\,
	datad => \SW[5]~input_o\,
	combout => \comparator_rand|comp_rand|Equal0~3_combout\);

-- Location: LCCOMB_X32_Y35_N8
\comparator_rand|comp_rand|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~5_combout\ = (\comparator_rand|comp_rand|Equal0~4_combout\ & (\comparator_rand|comp_rand|Equal0~3_combout\ & (\rand|Mux1~1_combout\ $ (!\SW[8]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comparator_rand|comp_rand|Equal0~4_combout\,
	datab => \rand|Mux1~1_combout\,
	datac => \SW[8]~input_o\,
	datad => \comparator_rand|comp_rand|Equal0~3_combout\,
	combout => \comparator_rand|comp_rand|Equal0~5_combout\);

-- Location: IOIBUF_X31_Y39_N22
\SW[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(0),
	o => \SW[0]~input_o\);

-- Location: LCCOMB_X30_Y35_N28
\rand|Mux8~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~0_combout\ = (\STG[1]~input_o\ & (!\STG[2]~input_o\ & \STG[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[1]~input_o\,
	datac => \STG[2]~input_o\,
	datad => \STG[0]~input_o\,
	combout => \rand|Mux8~0_combout\);

-- Location: LCCOMB_X31_Y35_N26
\rand|ShiftLeft1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft1~2_combout\ = (!\rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\ & (!\rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & (\rand|Equal1~0_combout\ & 
-- !\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[57]~96_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \rand|Equal1~0_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|ShiftLeft1~2_combout\);

-- Location: LCCOMB_X32_Y34_N8
\rand|ShiftLeft2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft2~2_combout\ = (!\rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & (!\rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\ & 
-- \rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod2|auto_generated|divider|divider|StageOut[57]~105_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[59]~110_combout\,
	datad => \rand|Equal2~0_combout\,
	combout => \rand|ShiftLeft2~2_combout\);

-- Location: LCCOMB_X30_Y34_N30
\rand|S_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~4_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (((\rand|ShiftLeft2~2_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\)))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (\rand|ShiftLeft1~2_combout\ $ (((\rand|ShiftLeft2~2_combout\ & !\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010010110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datab => \rand|ShiftLeft1~2_combout\,
	datac => \rand|ShiftLeft2~2_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	combout => \rand|S_3~4_combout\);

-- Location: LCCOMB_X34_Y34_N12
\rand|ShiftLeft0~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~9_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\) # ((\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\) # ((\rand|reg_rand|q\(0)) # (!\rand|ShiftLeft0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~9_combout\);

-- Location: LCCOMB_X30_Y34_N24
\rand|S_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_2~2_combout\ = \rand|ShiftLeft0~9_combout\ $ (((\rand|reg_rand|q\(1)) # ((\rand|reg_rand|q\(0)) # (\rand|reg_rand|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100110110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datab => \rand|ShiftLeft0~9_combout\,
	datac => \rand|reg_rand|q\(0),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|S_2~2_combout\);

-- Location: LCCOMB_X30_Y35_N18
\rand|Mux5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux5~2_combout\ = (!\STG[2]~input_o\ & \STG[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[2]~input_o\,
	datac => \STG[1]~input_o\,
	combout => \rand|Mux5~2_combout\);

-- Location: LCCOMB_X30_Y35_N12
\rand|Mux8~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~1_combout\ = (\STG[2]~input_o\) # ((!\STG[1]~input_o\ & \STG[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[1]~input_o\,
	datac => \STG[2]~input_o\,
	datad => \STG[0]~input_o\,
	combout => \rand|Mux8~1_combout\);

-- Location: LCCOMB_X30_Y35_N8
\rand|Mux8~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~2_combout\ = (\STG[2]~input_o\) # ((\STG[1]~input_o\ & !\rand|Equal0~7_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \STG[2]~input_o\,
	datac => \STG[1]~input_o\,
	datad => \rand|Equal0~7_combout\,
	combout => \rand|Mux8~2_combout\);

-- Location: LCCOMB_X31_Y37_N20
\rand|Mux9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux9~0_combout\ = (!\STG[1]~input_o\ & !\STG[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \STG[1]~input_o\,
	datad => \STG[0]~input_o\,
	combout => \rand|Mux9~0_combout\);

-- Location: LCCOMB_X30_Y34_N4
\rand|Mux9~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux9~1_combout\ = (\rand|Mux9~0_combout\ & ((\rand|reg_rand|q\(1)) # ((\rand|reg_rand|q\(0)) # (\rand|reg_rand|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datab => \rand|Mux9~0_combout\,
	datac => \rand|reg_rand|q\(0),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux9~1_combout\);

-- Location: LCCOMB_X30_Y34_N18
\rand|Mux9~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux9~2_combout\ = (\rand|Mux8~1_combout\ & ((\rand|Mux8~2_combout\ & (\rand|Mux9~1_combout\)) # (!\rand|Mux8~2_combout\ & ((!\rand|ShiftLeft0~9_combout\))))) # (!\rand|Mux8~1_combout\ & (\rand|Mux8~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010011100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~1_combout\,
	datab => \rand|Mux8~2_combout\,
	datac => \rand|Mux9~1_combout\,
	datad => \rand|ShiftLeft0~9_combout\,
	combout => \rand|Mux9~2_combout\);

-- Location: LCCOMB_X30_Y34_N28
\rand|Mux9~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux9~3_combout\ = (\rand|Mux5~2_combout\ & ((\rand|Mux9~2_combout\ & (\rand|S_3~4_combout\)) # (!\rand|Mux9~2_combout\ & ((!\rand|S_2~2_combout\))))) # (!\rand|Mux5~2_combout\ & (((\rand|Mux9~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|S_3~4_combout\,
	datab => \rand|S_2~2_combout\,
	datac => \rand|Mux5~2_combout\,
	datad => \rand|Mux9~2_combout\,
	combout => \rand|Mux9~3_combout\);

-- Location: LCCOMB_X30_Y35_N6
\rand|Mux8~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~3_combout\ = (!\rand|Equal0~7_combout\ & (\rand|Mux9~0_combout\ & (\STG[2]~input_o\ & \rand|Mux5~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Equal0~7_combout\,
	datab => \rand|Mux9~0_combout\,
	datac => \STG[2]~input_o\,
	datad => \rand|Mux5~3_combout\,
	combout => \rand|Mux8~3_combout\);

-- Location: LCCOMB_X30_Y34_N2
\rand|S_3~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~5_combout\ = \rand|S_3~4_combout\ $ (((\rand|reg_rand|q\(1)) # (\rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datab => \rand|reg_rand|q\(0),
	datac => \rand|S_3~4_combout\,
	combout => \rand|S_3~5_combout\);

-- Location: LCCOMB_X30_Y34_N0
\rand|Mux9~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux9~4_combout\ = (\rand|Mux8~3_combout\ & (((!\rand|S_3~5_combout\)))) # (!\rand|Mux8~3_combout\ & (!\rand|Mux8~0_combout\ & (\rand|Mux9~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010011110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~0_combout\,
	datab => \rand|Mux9~3_combout\,
	datac => \rand|Mux8~3_combout\,
	datad => \rand|S_3~5_combout\,
	combout => \rand|Mux9~4_combout\);

-- Location: LCCOMB_X30_Y34_N10
\rand|S_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~6_combout\ = (\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (\rand|ShiftLeft1~2_combout\ $ (((\rand|ShiftLeft2~2_combout\ & \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\))))) # 
-- (!\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & (((\rand|ShiftLeft2~2_combout\ & \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datab => \rand|ShiftLeft1~2_combout\,
	datac => \rand|ShiftLeft2~2_combout\,
	datad => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	combout => \rand|S_3~6_combout\);

-- Location: LCCOMB_X34_Y34_N18
\rand|ShiftLeft0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~10_combout\ = (!\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & (!\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ & (\rand|ShiftLeft0~6_combout\ & \rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~10_combout\);

-- Location: LCCOMB_X30_Y34_N26
\rand|S_2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_2~3_combout\ = \rand|ShiftLeft0~10_combout\ $ (((!\rand|reg_rand|q\(1) & (\rand|reg_rand|q\(0) & !\rand|reg_rand|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000010110100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datab => \rand|reg_rand|q\(0),
	datac => \rand|ShiftLeft0~10_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|S_2~3_combout\);

-- Location: LCCOMB_X30_Y34_N16
\rand|Mux8~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~4_combout\ = ((!\rand|reg_rand|q\(1) & (\rand|reg_rand|q\(0) & !\rand|reg_rand|q\(2)))) # (!\rand|Mux9~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001101110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(1),
	datab => \rand|Mux9~0_combout\,
	datac => \rand|reg_rand|q\(0),
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux8~4_combout\);

-- Location: LCCOMB_X30_Y34_N6
\rand|Mux8~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~5_combout\ = (\rand|Mux8~1_combout\ & ((\rand|Mux8~2_combout\ & ((\rand|Mux8~4_combout\))) # (!\rand|Mux8~2_combout\ & (\rand|ShiftLeft0~10_combout\)))) # (!\rand|Mux8~1_combout\ & (((!\rand|Mux8~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft0~10_combout\,
	datab => \rand|Mux8~4_combout\,
	datac => \rand|Mux8~1_combout\,
	datad => \rand|Mux8~2_combout\,
	combout => \rand|Mux8~5_combout\);

-- Location: LCCOMB_X30_Y34_N8
\rand|Mux8~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~6_combout\ = (\rand|Mux5~2_combout\ & ((\rand|Mux8~5_combout\ & ((\rand|S_2~3_combout\))) # (!\rand|Mux8~5_combout\ & (\rand|S_3~6_combout\)))) # (!\rand|Mux5~2_combout\ & (((\rand|Mux8~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|S_3~6_combout\,
	datab => \rand|Mux5~2_combout\,
	datac => \rand|S_2~3_combout\,
	datad => \rand|Mux8~5_combout\,
	combout => \rand|Mux8~6_combout\);

-- Location: LCCOMB_X30_Y34_N12
\rand|S_3~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~7_combout\ = \rand|S_3~6_combout\ $ (((\rand|reg_rand|q\(0) & !\rand|reg_rand|q\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010011010100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|S_3~6_combout\,
	datab => \rand|reg_rand|q\(0),
	datac => \rand|reg_rand|q\(1),
	combout => \rand|S_3~7_combout\);

-- Location: LCCOMB_X30_Y34_N22
\rand|Mux8~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux8~7_combout\ = (\rand|Mux8~3_combout\ & (((\rand|S_3~7_combout\)))) # (!\rand|Mux8~3_combout\ & ((\rand|Mux8~0_combout\) # ((\rand|Mux8~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~0_combout\,
	datab => \rand|Mux8~6_combout\,
	datac => \rand|Mux8~3_combout\,
	datad => \rand|S_3~7_combout\,
	combout => \rand|Mux8~7_combout\);

-- Location: IOIBUF_X31_Y39_N8
\SW[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(1),
	o => \SW[1]~input_o\);

-- Location: LCCOMB_X32_Y35_N22
\comparator_rand|comp_rand|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~1_combout\ = \rand|Mux8~7_combout\ $ (\SW[1]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \rand|Mux8~7_combout\,
	datad => \SW[1]~input_o\,
	combout => \comparator_rand|comp_rand|Equal0~1_combout\);

-- Location: LCCOMB_X31_Y34_N12
\rand|Mux6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux6~0_combout\ = ((\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) & !\rand|reg_rand|q\(2)))) # (!\rand|Mux9~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111110001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datac => \rand|Mux9~0_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux6~0_combout\);

-- Location: LCCOMB_X34_Y34_N16
\rand|ShiftLeft0~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~7_combout\ = (!\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & (\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\ & (\rand|ShiftLeft0~6_combout\ & \rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~7_combout\);

-- Location: LCCOMB_X31_Y34_N6
\rand|Mux6~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux6~1_combout\ = (\rand|Mux8~2_combout\ & (\rand|Mux6~0_combout\ & (\rand|Mux8~1_combout\))) # (!\rand|Mux8~2_combout\ & (((\rand|ShiftLeft0~7_combout\) # (!\rand|Mux8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011001110000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux6~0_combout\,
	datab => \rand|Mux8~2_combout\,
	datac => \rand|Mux8~1_combout\,
	datad => \rand|ShiftLeft0~7_combout\,
	combout => \rand|Mux6~1_combout\);

-- Location: LCCOMB_X31_Y34_N18
\rand|S_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_2~0_combout\ = \rand|ShiftLeft0~7_combout\ $ (((\rand|reg_rand|q\(0) & (\rand|reg_rand|q\(1) & !\rand|reg_rand|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datac => \rand|ShiftLeft0~7_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|S_2~0_combout\);

-- Location: LCCOMB_X31_Y35_N28
\rand|S_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~0_combout\ = (\rand|ShiftLeft2~0_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ $ (((\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\) # (!\rand|ShiftLeft1~0_combout\))))) # 
-- (!\rand|ShiftLeft2~0_combout\ & (\rand|ShiftLeft1~0_combout\ & ((!\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101011000110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft2~0_combout\,
	datab => \rand|ShiftLeft1~0_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	combout => \rand|S_3~0_combout\);

-- Location: LCCOMB_X31_Y34_N8
\rand|Mux6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux6~2_combout\ = (\rand|Mux6~1_combout\ & ((\rand|S_2~0_combout\) # ((!\rand|Mux5~2_combout\)))) # (!\rand|Mux6~1_combout\ & (((\rand|Mux5~2_combout\ & \rand|S_3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101101010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux6~1_combout\,
	datab => \rand|S_2~0_combout\,
	datac => \rand|Mux5~2_combout\,
	datad => \rand|S_3~0_combout\,
	combout => \rand|Mux6~2_combout\);

-- Location: LCCOMB_X31_Y34_N4
\rand|S_3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~1_combout\ = \rand|S_3~0_combout\ $ (((\rand|reg_rand|q\(0) & \rand|reg_rand|q\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datad => \rand|S_3~0_combout\,
	combout => \rand|S_3~1_combout\);

-- Location: LCCOMB_X31_Y34_N30
\rand|Mux6~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux6~3_combout\ = (\rand|Mux8~3_combout\ & (((\rand|S_3~1_combout\)))) # (!\rand|Mux8~3_combout\ & ((\rand|Mux8~0_combout\) # ((\rand|Mux6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~0_combout\,
	datab => \rand|Mux6~2_combout\,
	datac => \rand|S_3~1_combout\,
	datad => \rand|Mux8~3_combout\,
	combout => \rand|Mux6~3_combout\);

-- Location: IOIBUF_X31_Y39_N1
\SW[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(2),
	o => \SW[2]~input_o\);

-- Location: LCCOMB_X31_Y34_N2
\rand|S_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~2_combout\ = (\rand|ShiftLeft1~1_combout\ & (\rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\ $ (((\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\) # (!\rand|ShiftLeft2~1_combout\))))) # 
-- (!\rand|ShiftLeft1~1_combout\ & (((!\rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \rand|ShiftLeft2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft1~1_combout\,
	datab => \rand|Mod1|auto_generated|divider|divider|StageOut[58]~102_combout\,
	datac => \rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \rand|ShiftLeft2~1_combout\,
	combout => \rand|S_3~2_combout\);

-- Location: LCCOMB_X31_Y34_N14
\rand|S_3~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~3_combout\ = \rand|S_3~2_combout\ $ (((\rand|reg_rand|q\(0)) # (!\rand|reg_rand|q\(1))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010010111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datad => \rand|S_3~2_combout\,
	combout => \rand|S_3~3_combout\);

-- Location: LCCOMB_X34_Y34_N6
\rand|ShiftLeft0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|ShiftLeft0~8_combout\ = (\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\) # (((\rand|reg_rand|q\(0)) # (!\rand|ShiftLeft0~6_combout\)) # (!\rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datab => \rand|Mod0|auto_generated|divider|divider|StageOut[57]~87_combout\,
	datac => \rand|ShiftLeft0~6_combout\,
	datad => \rand|reg_rand|q\(0),
	combout => \rand|ShiftLeft0~8_combout\);

-- Location: LCCOMB_X31_Y34_N20
\rand|S_2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_2~1_combout\ = \rand|ShiftLeft0~8_combout\ $ (((\rand|reg_rand|q\(0)) # ((\rand|reg_rand|q\(2)) # (!\rand|reg_rand|q\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111101001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datac => \rand|ShiftLeft0~8_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|S_2~1_combout\);

-- Location: LCCOMB_X31_Y34_N28
\rand|Mux7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux7~0_combout\ = (\rand|reg_rand|q\(0)) # (((\rand|reg_rand|q\(2)) # (!\rand|Mux9~0_combout\)) # (!\rand|reg_rand|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|reg_rand|q\(0),
	datab => \rand|reg_rand|q\(1),
	datac => \rand|Mux9~0_combout\,
	datad => \rand|reg_rand|q\(2),
	combout => \rand|Mux7~0_combout\);

-- Location: LCCOMB_X31_Y34_N22
\rand|Mux7~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux7~1_combout\ = (\rand|Mux8~1_combout\ & ((\rand|Mux8~2_combout\ & ((!\rand|Mux7~0_combout\))) # (!\rand|Mux8~2_combout\ & (!\rand|ShiftLeft0~8_combout\)))) # (!\rand|Mux8~1_combout\ & (\rand|Mux8~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100011011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~1_combout\,
	datab => \rand|Mux8~2_combout\,
	datac => \rand|ShiftLeft0~8_combout\,
	datad => \rand|Mux7~0_combout\,
	combout => \rand|Mux7~1_combout\);

-- Location: LCCOMB_X31_Y34_N24
\rand|Mux7~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux7~2_combout\ = (\rand|Mux5~2_combout\ & ((\rand|Mux7~1_combout\ & ((\rand|S_3~2_combout\))) # (!\rand|Mux7~1_combout\ & (\rand|S_2~1_combout\)))) # (!\rand|Mux5~2_combout\ & (((\rand|Mux7~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100001011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux5~2_combout\,
	datab => \rand|S_2~1_combout\,
	datac => \rand|Mux7~1_combout\,
	datad => \rand|S_3~2_combout\,
	combout => \rand|Mux7~2_combout\);

-- Location: LCCOMB_X31_Y34_N0
\rand|Mux7~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux7~3_combout\ = (\rand|Mux8~3_combout\ & (!\rand|S_3~3_combout\)) # (!\rand|Mux8~3_combout\ & (((!\rand|Mux8~0_combout\ & \rand|Mux7~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010011100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux8~3_combout\,
	datab => \rand|S_3~3_combout\,
	datac => \rand|Mux8~0_combout\,
	datad => \rand|Mux7~2_combout\,
	combout => \rand|Mux7~3_combout\);

-- Location: IOIBUF_X34_Y39_N29
\SW[3]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(3),
	o => \SW[3]~input_o\);

-- Location: LCCOMB_X32_Y35_N0
\comparator_rand|comp_rand|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~0_combout\ = (\rand|Mux6~3_combout\ & (\SW[3]~input_o\ & (\SW[2]~input_o\ $ (!\rand|Mux7~3_combout\)))) # (!\rand|Mux6~3_combout\ & (!\SW[3]~input_o\ & (\SW[2]~input_o\ $ (!\rand|Mux7~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux6~3_combout\,
	datab => \SW[2]~input_o\,
	datac => \rand|Mux7~3_combout\,
	datad => \SW[3]~input_o\,
	combout => \comparator_rand|comp_rand|Equal0~0_combout\);

-- Location: LCCOMB_X32_Y35_N28
\comparator_rand|comp_rand|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~2_combout\ = (!\comparator_rand|comp_rand|Equal0~1_combout\ & (\comparator_rand|comp_rand|Equal0~0_combout\ & (\SW[0]~input_o\ $ (!\rand|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[0]~input_o\,
	datab => \rand|Mux9~4_combout\,
	datac => \comparator_rand|comp_rand|Equal0~1_combout\,
	datad => \comparator_rand|comp_rand|Equal0~0_combout\,
	combout => \comparator_rand|comp_rand|Equal0~2_combout\);

-- Location: IOIBUF_X31_Y39_N15
\SW[9]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(9),
	o => \SW[9]~input_o\);

-- Location: LCCOMB_X34_Y34_N26
\rand|Mux1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux1~2_combout\ = (!\rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\ & ((\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((!\rand|reg_rand|q\(1)))) # 
-- (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (!\rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	datab => \rand|reg_rand|q\(1),
	datac => \rand|Mod0|auto_generated|divider|divider|StageOut[58]~88_combout\,
	datad => \rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \rand|Mux1~2_combout\);

-- Location: LCCOMB_X34_Y34_N28
\rand|Mux0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux0~3_combout\ = (\rand|Mux0~1_combout\ & (\rand|Mux1~2_combout\ & (\rand|reg_rand|q\(0)))) # (!\rand|Mux0~1_combout\ & (((!\rand|Mux0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux1~2_combout\,
	datab => \rand|reg_rand|q\(0),
	datac => \rand|Mux0~0_combout\,
	datad => \rand|Mux0~1_combout\,
	combout => \rand|Mux0~3_combout\);

-- Location: LCCOMB_X32_Y35_N10
\rand|S_3~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|S_3~13_combout\ = (\rand|ShiftLeft2~4_combout\ & (\rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\ $ (((\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & \rand|ShiftLeft1~4_combout\))))) # 
-- (!\rand|ShiftLeft2~4_combout\ & (((\rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\ & \rand|ShiftLeft1~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|ShiftLeft2~4_combout\,
	datab => \rand|Mod2|auto_generated|divider|divider|StageOut[56]~104_combout\,
	datac => \rand|Mod1|auto_generated|divider|divider|StageOut[56]~95_combout\,
	datad => \rand|ShiftLeft1~4_combout\,
	combout => \rand|S_3~13_combout\);

-- Location: LCCOMB_X32_Y35_N20
\rand|Mux0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \rand|Mux0~4_combout\ = (\rand|Mux0~2_combout\ & ((\rand|S_3~13_combout\))) # (!\rand|Mux0~2_combout\ & (\rand|Mux0~3_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \rand|Mux0~2_combout\,
	datac => \rand|Mux0~3_combout\,
	datad => \rand|S_3~13_combout\,
	combout => \rand|Mux0~4_combout\);

-- Location: LCCOMB_X32_Y35_N2
\comparator_rand|comp_rand|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_rand|comp_rand|Equal0~6_combout\ = (\comparator_rand|comp_rand|Equal0~5_combout\ & (\comparator_rand|comp_rand|Equal0~2_combout\ & (\SW[9]~input_o\ $ (!\rand|Mux0~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comparator_rand|comp_rand|Equal0~5_combout\,
	datab => \comparator_rand|comp_rand|Equal0~2_combout\,
	datac => \SW[9]~input_o\,
	datad => \rand|Mux0~4_combout\,
	combout => \comparator_rand|comp_rand|Equal0~6_combout\);

-- Location: IOIBUF_X58_Y54_N15
\ld_lev~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ld_lev,
	o => \ld_lev~input_o\);

-- Location: LCCOMB_X58_Y53_N12
\total_level|reg_lev|q[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_level|reg_lev|q[0]~0_combout\ = \total_level|reg_lev|q\(0) $ (\ld_lev~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_level|reg_lev|q\(0),
	datad => \ld_lev~input_o\,
	combout => \total_level|reg_lev|q[0]~0_combout\);

-- Location: IOIBUF_X0_Y23_N22
\clr_lev~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clr_lev,
	o => \clr_lev~input_o\);

-- Location: CLKCTRL_G0
\clr_lev~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clr_lev~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clr_lev~inputclkctrl_outclk\);

-- Location: FF_X58_Y53_N13
\total_level|reg_lev|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_level|reg_lev|q[0]~0_combout\,
	clrn => \ALT_INV_clr_lev~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_level|reg_lev|q\(0));

-- Location: LCCOMB_X58_Y53_N16
\total_level|reg_lev|q[1]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_level|reg_lev|q[1]~2_combout\ = \total_level|reg_lev|q\(1) $ (((\ld_lev~input_o\ & \total_level|reg_lev|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \ld_lev~input_o\,
	datac => \total_level|reg_lev|q\(1),
	datad => \total_level|reg_lev|q\(0),
	combout => \total_level|reg_lev|q[1]~2_combout\);

-- Location: FF_X58_Y53_N17
\total_level|reg_lev|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_level|reg_lev|q[1]~2_combout\,
	clrn => \ALT_INV_clr_lev~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_level|reg_lev|q\(1));

-- Location: LCCOMB_X58_Y53_N26
\total_level|reg_lev|q[2]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_level|reg_lev|q[2]~1_combout\ = \total_level|reg_lev|q\(2) $ (((\total_level|reg_lev|q\(0) & (\ld_lev~input_o\ & \total_level|reg_lev|q\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_level|reg_lev|q\(0),
	datab => \ld_lev~input_o\,
	datac => \total_level|reg_lev|q\(2),
	datad => \total_level|reg_lev|q\(1),
	combout => \total_level|reg_lev|q[2]~1_combout\);

-- Location: FF_X58_Y53_N27
\total_level|reg_lev|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_level|reg_lev|q[2]~1_combout\,
	clrn => \ALT_INV_clr_lev~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_level|reg_lev|q\(2));

-- Location: LCCOMB_X58_Y53_N30
\comparator_level|comp_lev|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_level|comp_lev|Equal0~0_combout\ = (!\total_level|reg_lev|q\(1) & (\total_level|reg_lev|q\(0) & \total_level|reg_lev|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_level|reg_lev|q\(1),
	datab => \total_level|reg_lev|q\(0),
	datac => \total_level|reg_lev|q\(2),
	combout => \comparator_level|comp_lev|Equal0~0_combout\);

-- Location: LCCOMB_X32_Y35_N30
\comparator_zero|comp_lev|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_zero|comp_lev|Equal0~1_combout\ = (!\SW[7]~input_o\ & (!\SW[4]~input_o\ & (!\SW[6]~input_o\ & !\SW[5]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[7]~input_o\,
	datab => \SW[4]~input_o\,
	datac => \SW[6]~input_o\,
	datad => \SW[5]~input_o\,
	combout => \comparator_zero|comp_lev|Equal0~1_combout\);

-- Location: LCCOMB_X32_Y35_N16
\comparator_zero|comp_lev|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_zero|comp_lev|Equal0~0_combout\ = (!\SW[0]~input_o\ & (!\SW[1]~input_o\ & (!\SW[2]~input_o\ & !\SW[3]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[0]~input_o\,
	datab => \SW[1]~input_o\,
	datac => \SW[2]~input_o\,
	datad => \SW[3]~input_o\,
	combout => \comparator_zero|comp_lev|Equal0~0_combout\);

-- Location: LCCOMB_X32_Y35_N4
\comparator_zero|comp_lev|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator_zero|comp_lev|Equal0~2_combout\ = (\comparator_zero|comp_lev|Equal0~1_combout\ & (!\SW[9]~input_o\ & (!\SW[8]~input_o\ & \comparator_zero|comp_lev|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \comparator_zero|comp_lev|Equal0~1_combout\,
	datab => \SW[9]~input_o\,
	datac => \SW[8]~input_o\,
	datad => \comparator_zero|comp_lev|Equal0~0_combout\,
	combout => \comparator_zero|comp_lev|Equal0~2_combout\);

-- Location: IOIBUF_X49_Y54_N29
\ld_tim~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_ld_tim,
	o => \ld_tim~input_o\);

-- Location: LCCOMB_X49_Y50_N12
\total_timer|reg_tim|q[0]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[0]~7_combout\ = \total_timer|reg_tim|q\(0) $ (\ld_tim~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(0),
	datad => \ld_tim~input_o\,
	combout => \total_timer|reg_tim|q[0]~7_combout\);

-- Location: IOIBUF_X0_Y23_N15
\clr_tim~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clr_tim,
	o => \clr_tim~input_o\);

-- Location: CLKCTRL_G2
\clr_tim~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clr_tim~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clr_tim~inputclkctrl_outclk\);

-- Location: FF_X49_Y50_N13
\total_timer|reg_tim|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[0]~7_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(0));

-- Location: LCCOMB_X49_Y50_N16
\total_timer|reg_tim|q[1]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[1]~8_combout\ = (\total_timer|reg_tim|q\(0) & (\total_timer|reg_tim|q\(1) $ (VCC))) # (!\total_timer|reg_tim|q\(0) & (\total_timer|reg_tim|q\(1) & VCC))
-- \total_timer|reg_tim|q[1]~9\ = CARRY((\total_timer|reg_tim|q\(0) & \total_timer|reg_tim|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(0),
	datab => \total_timer|reg_tim|q\(1),
	datad => VCC,
	combout => \total_timer|reg_tim|q[1]~8_combout\,
	cout => \total_timer|reg_tim|q[1]~9\);

-- Location: FF_X49_Y50_N17
\total_timer|reg_tim|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[1]~8_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(1));

-- Location: LCCOMB_X49_Y50_N18
\total_timer|reg_tim|q[2]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[2]~10_combout\ = (\total_timer|reg_tim|q\(2) & (!\total_timer|reg_tim|q[1]~9\)) # (!\total_timer|reg_tim|q\(2) & ((\total_timer|reg_tim|q[1]~9\) # (GND)))
-- \total_timer|reg_tim|q[2]~11\ = CARRY((!\total_timer|reg_tim|q[1]~9\) # (!\total_timer|reg_tim|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(2),
	datad => VCC,
	cin => \total_timer|reg_tim|q[1]~9\,
	combout => \total_timer|reg_tim|q[2]~10_combout\,
	cout => \total_timer|reg_tim|q[2]~11\);

-- Location: FF_X49_Y50_N19
\total_timer|reg_tim|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[2]~10_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(2));

-- Location: LCCOMB_X49_Y50_N20
\total_timer|reg_tim|q[3]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[3]~12_combout\ = (\total_timer|reg_tim|q\(3) & (\total_timer|reg_tim|q[2]~11\ $ (GND))) # (!\total_timer|reg_tim|q\(3) & (!\total_timer|reg_tim|q[2]~11\ & VCC))
-- \total_timer|reg_tim|q[3]~13\ = CARRY((\total_timer|reg_tim|q\(3) & !\total_timer|reg_tim|q[2]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(3),
	datad => VCC,
	cin => \total_timer|reg_tim|q[2]~11\,
	combout => \total_timer|reg_tim|q[3]~12_combout\,
	cout => \total_timer|reg_tim|q[3]~13\);

-- Location: FF_X49_Y50_N21
\total_timer|reg_tim|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[3]~12_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(3));

-- Location: LCCOMB_X49_Y50_N22
\total_timer|reg_tim|q[4]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[4]~14_combout\ = (\total_timer|reg_tim|q\(4) & (!\total_timer|reg_tim|q[3]~13\)) # (!\total_timer|reg_tim|q\(4) & ((\total_timer|reg_tim|q[3]~13\) # (GND)))
-- \total_timer|reg_tim|q[4]~15\ = CARRY((!\total_timer|reg_tim|q[3]~13\) # (!\total_timer|reg_tim|q\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(4),
	datad => VCC,
	cin => \total_timer|reg_tim|q[3]~13\,
	combout => \total_timer|reg_tim|q[4]~14_combout\,
	cout => \total_timer|reg_tim|q[4]~15\);

-- Location: FF_X49_Y50_N23
\total_timer|reg_tim|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[4]~14_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(4));

-- Location: LCCOMB_X49_Y50_N24
\total_timer|reg_tim|q[5]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[5]~16_combout\ = (\total_timer|reg_tim|q\(5) & (\total_timer|reg_tim|q[4]~15\ $ (GND))) # (!\total_timer|reg_tim|q\(5) & (!\total_timer|reg_tim|q[4]~15\ & VCC))
-- \total_timer|reg_tim|q[5]~17\ = CARRY((\total_timer|reg_tim|q\(5) & !\total_timer|reg_tim|q[4]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(5),
	datad => VCC,
	cin => \total_timer|reg_tim|q[4]~15\,
	combout => \total_timer|reg_tim|q[5]~16_combout\,
	cout => \total_timer|reg_tim|q[5]~17\);

-- Location: FF_X49_Y50_N25
\total_timer|reg_tim|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[5]~16_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(5));

-- Location: LCCOMB_X49_Y50_N26
\total_timer|reg_tim|q[6]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[6]~18_combout\ = (\total_timer|reg_tim|q\(6) & (!\total_timer|reg_tim|q[5]~17\)) # (!\total_timer|reg_tim|q\(6) & ((\total_timer|reg_tim|q[5]~17\) # (GND)))
-- \total_timer|reg_tim|q[6]~19\ = CARRY((!\total_timer|reg_tim|q[5]~17\) # (!\total_timer|reg_tim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \total_timer|reg_tim|q[5]~17\,
	combout => \total_timer|reg_tim|q[6]~18_combout\,
	cout => \total_timer|reg_tim|q[6]~19\);

-- Location: FF_X49_Y50_N27
\total_timer|reg_tim|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[6]~18_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(6));

-- Location: LCCOMB_X49_Y50_N28
\total_timer|reg_tim|q[7]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total_timer|reg_tim|q[7]~20_combout\ = \total_timer|reg_tim|q[6]~19\ $ (!\total_timer|reg_tim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \total_timer|reg_tim|q\(7),
	cin => \total_timer|reg_tim|q[6]~19\,
	combout => \total_timer|reg_tim|q[7]~20_combout\);

-- Location: FF_X49_Y50_N29
\total_timer|reg_tim|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total_timer|reg_tim|q[7]~20_combout\,
	clrn => \ALT_INV_clr_tim~inputclkctrl_outclk\,
	ena => \ld_tim~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total_timer|reg_tim|q\(7));

-- Location: LCCOMB_X49_Y50_N0
\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \total_timer|reg_tim|q\(5) $ (VCC)
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(5),
	datad => VCC,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X49_Y50_N2
\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\total_timer|reg_tim|q\(6) & (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\total_timer|reg_tim|q\(6) & 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\total_timer|reg_tim|q\(6) & !\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X49_Y50_N4
\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\total_timer|reg_tim|q\(7) & (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # (!\total_timer|reg_tim|q\(7) & 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\total_timer|reg_tim|q\(7) & !\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X49_Y50_N6
\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X47_Y50_N14
\display|Mod1|auto_generated|divider|divider|StageOut[27]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\);

-- Location: LCCOMB_X47_Y50_N20
\display|Mod1|auto_generated|divider|divider|StageOut[27]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ = (\total_timer|reg_tim|q\(7) & \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(7),
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\);

-- Location: LCCOMB_X47_Y50_N12
\display|Mod1|auto_generated|divider|divider|StageOut[26]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\ = (\total_timer|reg_tim|q\(6) & \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(6),
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\);

-- Location: LCCOMB_X47_Y50_N18
\display|Mod1|auto_generated|divider|divider|StageOut[26]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\);

-- Location: LCCOMB_X47_Y50_N6
\display|Mod1|auto_generated|divider|divider|StageOut[25]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\);

-- Location: LCCOMB_X47_Y50_N0
\display|Mod1|auto_generated|divider|divider|StageOut[25]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \total_timer|reg_tim|q\(5),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\);

-- Location: LCCOMB_X47_Y50_N10
\display|Mod1|auto_generated|divider|divider|StageOut[24]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \total_timer|reg_tim|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \total_timer|reg_tim|q\(4),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\);

-- Location: LCCOMB_X47_Y50_N8
\display|Mod1|auto_generated|divider|divider|StageOut[24]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \total_timer|reg_tim|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \total_timer|reg_tim|q\(4),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\);

-- Location: LCCOMB_X47_Y50_N22
\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\,
	datad => VCC,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X47_Y50_N24
\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X47_Y50_N26
\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\)))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X47_Y50_N28
\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\);

-- Location: LCCOMB_X47_Y50_N30
\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X47_Y50_N4
\display|Mod1|auto_generated|divider|divider|StageOut[36]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\total_timer|reg_tim|q\(7)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datab => \total_timer|reg_tim|q\(7),
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\);

-- Location: LCCOMB_X44_Y50_N24
\display|Mod1|auto_generated|divider|divider|StageOut[36]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\);

-- Location: LCCOMB_X47_Y50_N2
\display|Mod1|auto_generated|divider|divider|StageOut[35]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\total_timer|reg_tim|q\(6))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(6),
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\);

-- Location: LCCOMB_X44_Y50_N2
\display|Mod1|auto_generated|divider|divider|StageOut[35]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\);

-- Location: LCCOMB_X47_Y50_N16
\display|Mod1|auto_generated|divider|divider|StageOut[34]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\total_timer|reg_tim|q\(5))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(5),
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\);

-- Location: LCCOMB_X44_Y50_N20
\display|Mod1|auto_generated|divider|divider|StageOut[34]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\);

-- Location: LCCOMB_X44_Y50_N22
\display|Mod1|auto_generated|divider|divider|StageOut[33]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ = (\total_timer|reg_tim|q\(4) & \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(4),
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\);

-- Location: LCCOMB_X46_Y50_N4
\display|Mod1|auto_generated|divider|divider|StageOut[33]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\);

-- Location: LCCOMB_X44_Y50_N30
\display|Mod1|auto_generated|divider|divider|StageOut[32]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\ = (\total_timer|reg_tim|q\(3) & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(3),
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\);

-- Location: LCCOMB_X44_Y50_N28
\display|Mod1|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\total_timer|reg_tim|q\(3) & \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(3),
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X44_Y50_N6
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datad => VCC,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X44_Y50_N8
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X44_Y50_N10
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\)))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X44_Y50_N12
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\);

-- Location: LCCOMB_X44_Y50_N14
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\))))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\) # (GND))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # ((\display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\);

-- Location: LCCOMB_X44_Y50_N16
\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ = !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\);

-- Location: LCCOMB_X44_Y50_N4
\display|Mod1|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X45_Y50_N30
\display|Mod1|auto_generated|divider|divider|StageOut[45]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\);

-- Location: LCCOMB_X44_Y50_N26
\display|Mod1|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X45_Y50_N24
\display|Mod1|auto_generated|divider|divider|StageOut[44]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\);

-- Location: LCCOMB_X44_Y50_N0
\display|Mod1|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X45_Y50_N18
\display|Mod1|auto_generated|divider|divider|StageOut[43]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\);

-- Location: LCCOMB_X46_Y50_N22
\display|Mod1|auto_generated|divider|divider|StageOut[42]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- (\total_timer|reg_tim|q\(4))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(4),
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\);

-- Location: LCCOMB_X46_Y50_N26
\display|Mod1|auto_generated|divider|divider|StageOut[42]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\);

-- Location: LCCOMB_X46_Y50_N2
\display|Mod1|auto_generated|divider|divider|StageOut[41]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\);

-- Location: LCCOMB_X46_Y50_N8
\display|Mod1|auto_generated|divider|divider|StageOut[41]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ = (\total_timer|reg_tim|q\(3) & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(3),
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\);

-- Location: LCCOMB_X45_Y50_N26
\display|Mod1|auto_generated|divider|divider|StageOut[40]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \total_timer|reg_tim|q\(2),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\);

-- Location: LCCOMB_X45_Y50_N20
\display|Mod1|auto_generated|divider|divider|StageOut[40]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \total_timer|reg_tim|q\(2),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\);

-- Location: LCCOMB_X45_Y50_N0
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\,
	datad => VCC,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X45_Y50_N2
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X45_Y50_N4
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\)))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X45_Y50_N6
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X45_Y50_N8
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\))))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\) # (GND))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # ((\display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\) # 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X45_Y50_N10
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X45_Y50_N12
\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X45_Y50_N28
\display|Mod1|auto_generated|divider|divider|StageOut[54]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\);

-- Location: LCCOMB_X46_Y50_N24
\display|Mod1|auto_generated|divider|divider|StageOut[54]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\);

-- Location: LCCOMB_X45_Y50_N22
\display|Mod1|auto_generated|divider|divider|StageOut[53]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\);

-- Location: LCCOMB_X46_Y50_N18
\display|Mod1|auto_generated|divider|divider|StageOut[53]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\);

-- Location: LCCOMB_X46_Y50_N16
\display|Mod1|auto_generated|divider|divider|StageOut[52]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\);

-- Location: LCCOMB_X45_Y50_N16
\display|Mod1|auto_generated|divider|divider|StageOut[52]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\);

-- Location: LCCOMB_X46_Y50_N10
\display|Mod1|auto_generated|divider|divider|StageOut[51]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\);

-- Location: LCCOMB_X46_Y50_N0
\display|Mod1|auto_generated|divider|divider|StageOut[51]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- ((!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\);

-- Location: LCCOMB_X46_Y50_N28
\display|Mod1|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & 
-- ((\total_timer|reg_tim|q\(3)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & (\display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \total_timer|reg_tim|q\(3),
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X46_Y50_N12
\display|Mod1|auto_generated|divider|divider|StageOut[50]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\);

-- Location: LCCOMB_X46_Y50_N6
\display|Mod1|auto_generated|divider|divider|StageOut[49]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & !\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\);

-- Location: LCCOMB_X46_Y51_N28
\display|Mod1|auto_generated|divider|divider|StageOut[49]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \total_timer|reg_tim|q\(2),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\);

-- Location: LCCOMB_X46_Y51_N22
\display|Mod1|auto_generated|divider|divider|StageOut[48]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\ = (!\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \total_timer|reg_tim|q\(1),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\);

-- Location: LCCOMB_X46_Y51_N20
\display|Mod1|auto_generated|divider|divider|StageOut[48]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \total_timer|reg_tim|q\(1),
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\);

-- Location: LCCOMB_X46_Y51_N0
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ = (((\display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\) # (\display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\,
	datad => VCC,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\);

-- Location: LCCOMB_X46_Y51_N2
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ & 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\)))
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\);

-- Location: LCCOMB_X46_Y51_N4
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((((\display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\)))))
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ = CARRY((!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\);

-- Location: LCCOMB_X46_Y51_N6
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\);

-- Location: LCCOMB_X46_Y51_N8
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\) # ((\display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\) # 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\);

-- Location: LCCOMB_X46_Y51_N10
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\ = CARRY((!\display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ & 
-- !\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\);

-- Location: LCCOMB_X46_Y51_N12
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\ = CARRY((\display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\) # ((\display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\) # 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\,
	datad => VCC,
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\,
	cout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\);

-- Location: LCCOMB_X46_Y51_N14
\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ = !\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\,
	combout => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\);

-- Location: LCCOMB_X46_Y51_N26
\display|Mod1|auto_generated|divider|divider|StageOut[57]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (\total_timer|reg_tim|q\(1))) # 
-- (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(1),
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\);

-- Location: LCCOMB_X46_Y51_N30
\display|Mod1|auto_generated|divider|divider|StageOut[59]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\);

-- Location: LCCOMB_X46_Y51_N24
\display|Mod1|auto_generated|divider|divider|StageOut[58]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ = (\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\) # 
-- ((\display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\)))) # (!\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datab => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\,
	combout => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\);

-- Location: LCCOMB_X50_Y51_N12
\display|Mux6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux6~0_combout\ = (!\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & (!\display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & (\total_timer|reg_tim|q\(0) $ 
-- (\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(0),
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	combout => \display|Mux6~0_combout\);

-- Location: IOIBUF_X51_Y54_N15
\d~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_d,
	o => \d~input_o\);

-- Location: LCCOMB_X50_Y51_N6
\display|res:s_u[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[0]~0_combout\ = (!\display|Mux6~0_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mux6~0_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_u[0]~0_combout\);

-- Location: LCCOMB_X50_Y51_N0
\display|res:s_u[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[1]~0_combout\ = (\d~input_o\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ $ (!\total_timer|reg_tim|q\(0))) # (!\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101000101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \d~input_o\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datad => \total_timer|reg_tim|q\(0),
	combout => \display|res:s_u[1]~0_combout\);

-- Location: LCCOMB_X50_Y51_N18
\display|res:s_u[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[2]~0_combout\ = (\d~input_o\ & (((\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\) # (\total_timer|reg_tim|q\(0))) # (!\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101010100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \d~input_o\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datad => \total_timer|reg_tim|q\(0),
	combout => \display|res:s_u[2]~0_combout\);

-- Location: LCCOMB_X50_Y51_N8
\display|Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux3~0_combout\ = (!\display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & ((\total_timer|reg_tim|q\(0) & (\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ $ 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))) # (!\total_timer|reg_tim|q\(0) & (!\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(0),
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	combout => \display|Mux3~0_combout\);

-- Location: LCCOMB_X50_Y51_N10
\display|res:s_u[3]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[3]~0_combout\ = (!\display|Mux3~0_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mux3~0_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_u[3]~0_combout\);

-- Location: LCCOMB_X50_Y51_N16
\display|res:s_u[4]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[4]~0_combout\ = (\d~input_o\ & (!\total_timer|reg_tim|q\(0) & ((\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\) # (!\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \d~input_o\,
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datad => \total_timer|reg_tim|q\(0),
	combout => \display|res:s_u[4]~0_combout\);

-- Location: LCCOMB_X50_Y51_N22
\display|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux1~0_combout\ = (!\display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & ((\total_timer|reg_tim|q\(0) & ((\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\) # 
-- (!\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))) # (!\total_timer|reg_tim|q\(0) & (\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & !\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(0),
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	combout => \display|Mux1~0_combout\);

-- Location: LCCOMB_X50_Y51_N4
\display|res:s_u[5]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[5]~0_combout\ = (!\display|Mux1~0_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mux1~0_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_u[5]~0_combout\);

-- Location: LCCOMB_X50_Y51_N14
\display|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux0~0_combout\ = (\display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\) # ((\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & ((!\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\) # 
-- (!\total_timer|reg_tim|q\(0)))) # (!\display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & ((\display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(0),
	datab => \display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	combout => \display|Mux0~0_combout\);

-- Location: LCCOMB_X50_Y51_N24
\display|res:s_u[6]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_u[6]~0_combout\ = (\display|Mux0~0_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mux0~0_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_u[6]~0_combout\);

-- Location: LCCOMB_X47_Y47_N12
\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \total_timer|reg_tim|q\(5) $ (VCC)
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(5),
	datad => VCC,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X47_Y47_N14
\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\total_timer|reg_tim|q\(6) & (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\total_timer|reg_tim|q\(6) & 
-- (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\total_timer|reg_tim|q\(6) & !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X47_Y47_N16
\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\total_timer|reg_tim|q\(7) & (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # (!\total_timer|reg_tim|q\(7) & 
-- (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\total_timer|reg_tim|q\(7) & !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X47_Y47_N18
\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X47_Y47_N28
\display|Div1|auto_generated|divider|divider|StageOut[18]~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \total_timer|reg_tim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \total_timer|reg_tim|q\(7),
	combout => \display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\);

-- Location: LCCOMB_X47_Y47_N6
\display|Div1|auto_generated|divider|divider|StageOut[18]~37\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\);

-- Location: LCCOMB_X49_Y47_N22
\display|Div1|auto_generated|divider|divider|StageOut[17]~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \total_timer|reg_tim|q\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \total_timer|reg_tim|q\(6),
	combout => \display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\);

-- Location: LCCOMB_X47_Y47_N4
\display|Div1|auto_generated|divider|divider|StageOut[17]~39\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\);

-- Location: LCCOMB_X49_Y47_N26
\display|Div1|auto_generated|divider|divider|StageOut[16]~41\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\);

-- Location: LCCOMB_X49_Y47_N20
\display|Div1|auto_generated|divider|divider|StageOut[16]~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ = (\total_timer|reg_tim|q\(5) & \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(5),
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\);

-- Location: LCCOMB_X49_Y47_N10
\display|Div1|auto_generated|divider|divider|StageOut[15]~43\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\ = (\total_timer|reg_tim|q\(4) & !\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(4),
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\);

-- Location: LCCOMB_X49_Y47_N28
\display|Div1|auto_generated|divider|divider|StageOut[15]~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\ = (\total_timer|reg_tim|q\(4) & \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(4),
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\);

-- Location: LCCOMB_X49_Y47_N0
\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\,
	datad => VCC,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X49_Y47_N2
\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ & 
-- (!\display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X49_Y47_N4
\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\)))))
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X49_Y47_N6
\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\);

-- Location: LCCOMB_X49_Y47_N8
\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X49_Y47_N12
\display|Div1|auto_generated|divider|divider|StageOut[23]~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\);

-- Location: LCCOMB_X47_Y47_N10
\display|Div1|auto_generated|divider|divider|StageOut[23]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\total_timer|reg_tim|q\(6)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datad => \total_timer|reg_tim|q\(6),
	combout => \display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\);

-- Location: LCCOMB_X49_Y47_N14
\display|Div1|auto_generated|divider|divider|StageOut[22]~45\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\);

-- Location: LCCOMB_X49_Y47_N24
\display|Div1|auto_generated|divider|divider|StageOut[22]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\total_timer|reg_tim|q\(5))) # (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datab => \total_timer|reg_tim|q\(5),
	datac => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\);

-- Location: LCCOMB_X49_Y47_N16
\display|Div1|auto_generated|divider|divider|StageOut[21]~47\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\);

-- Location: LCCOMB_X50_Y47_N18
\display|Div1|auto_generated|divider|divider|StageOut[21]~46\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ = (\total_timer|reg_tim|q\(4) & \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(4),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\);

-- Location: LCCOMB_X51_Y47_N4
\display|Div1|auto_generated|divider|divider|StageOut[20]~48\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\ = (\total_timer|reg_tim|q\(3) & \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(3),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\);

-- Location: LCCOMB_X50_Y47_N12
\display|Div1|auto_generated|divider|divider|StageOut[20]~49\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\ = (\total_timer|reg_tim|q\(3) & !\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(3),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\);

-- Location: LCCOMB_X50_Y47_N0
\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\,
	datad => VCC,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X50_Y47_N2
\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ & 
-- (!\display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X50_Y47_N4
\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\)))))
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X50_Y47_N6
\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\);

-- Location: LCCOMB_X50_Y47_N8
\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\);

-- Location: LCCOMB_X49_Y48_N14
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ $ (GND)
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY(!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101001010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => VCC,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X49_Y48_N16
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)) # 
-- (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & VCC))
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X49_Y48_N18
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & VCC)) # 
-- (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ $ (GND)))
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X49_Y48_N20
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY(!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X49_Y48_N22
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ $ (GND)
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY(!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X49_Y48_N24
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY(!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X49_Y48_N26
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X49_Y48_N0
\display|Mod0|auto_generated|divider|divider|StageOut[54]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\);

-- Location: LCCOMB_X49_Y48_N2
\display|Mod0|auto_generated|divider|divider|StageOut[53]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\);

-- Location: LCCOMB_X49_Y48_N12
\display|Mod0|auto_generated|divider|divider|StageOut[52]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\ = (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\);

-- Location: LCCOMB_X49_Y48_N8
\display|Mod0|auto_generated|divider|divider|StageOut[51]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ = (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\);

-- Location: LCCOMB_X49_Y48_N6
\display|Mod0|auto_generated|divider|divider|StageOut[51]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\);

-- Location: LCCOMB_X49_Y48_N30
\display|Mod0|auto_generated|divider|divider|StageOut[50]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\);

-- Location: LCCOMB_X49_Y48_N28
\display|Mod0|auto_generated|divider|divider|StageOut[50]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\ = (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\);

-- Location: LCCOMB_X49_Y48_N10
\display|Mod0|auto_generated|divider|divider|StageOut[49]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & !\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\);

-- Location: LCCOMB_X49_Y48_N4
\display|Mod0|auto_generated|divider|divider|StageOut[49]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\);

-- Location: LCCOMB_X50_Y47_N10
\display|Div1|auto_generated|divider|divider|StageOut[28]~50\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\);

-- Location: LCCOMB_X49_Y47_N18
\display|Div1|auto_generated|divider|divider|StageOut[28]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\) # 
-- ((!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\);

-- Location: LCCOMB_X51_Y47_N6
\display|Div1|auto_generated|divider|divider|StageOut[27]~51\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\);

-- Location: LCCOMB_X49_Y47_N30
\display|Div1|auto_generated|divider|divider|StageOut[27]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- (\total_timer|reg_tim|q\(4))) # (!\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \total_timer|reg_tim|q\(4),
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\);

-- Location: LCCOMB_X50_Y47_N30
\display|Div1|auto_generated|divider|divider|StageOut[26]~53\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ = (!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\);

-- Location: LCCOMB_X50_Y47_N16
\display|Div1|auto_generated|divider|divider|StageOut[26]~52\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \total_timer|reg_tim|q\(3),
	combout => \display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\);

-- Location: LCCOMB_X51_Y47_N2
\display|Div1|auto_generated|divider|divider|StageOut[25]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\ = (\total_timer|reg_tim|q\(2) & !\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(2),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\);

-- Location: LCCOMB_X51_Y47_N12
\display|Div1|auto_generated|divider|divider|StageOut[25]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\ = (\total_timer|reg_tim|q\(2) & \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(2),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\);

-- Location: LCCOMB_X50_Y47_N20
\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\,
	datad => VCC,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X50_Y47_N22
\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ & 
-- (!\display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\)))
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X50_Y47_N24
\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\)))) # (!\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\)))))
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X50_Y47_N26
\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\);

-- Location: LCCOMB_X50_Y47_N28
\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\);

-- Location: LCCOMB_X50_Y48_N6
\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\ = !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\);

-- Location: LCCOMB_X50_Y48_N30
\display|Mod0|auto_generated|divider|divider|StageOut[48]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\ = (!\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\);

-- Location: LCCOMB_X50_Y48_N24
\display|Mod0|auto_generated|divider|divider|StageOut[48]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\);

-- Location: LCCOMB_X50_Y48_N8
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\ = (((\display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # (\display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\)))
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ = CARRY((\display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # (\display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\,
	datad => VCC,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\);

-- Location: LCCOMB_X50_Y48_N10
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ & (((\display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\)))) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ & 
-- (!\display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\)))
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ = CARRY((!\display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ & 
-- !\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\);

-- Location: LCCOMB_X50_Y48_N12
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & (((\display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\)))) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & ((((\display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\)))))
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\ = CARRY((!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & ((\display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\);

-- Location: LCCOMB_X50_Y48_N14
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\ = CARRY((!\display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ & 
-- !\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\);

-- Location: LCCOMB_X50_Y48_N16
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\ = CARRY((\display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\);

-- Location: LCCOMB_X50_Y48_N18
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\ = CARRY((!\display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ & !\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\);

-- Location: LCCOMB_X50_Y48_N20
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\ = CARRY((\display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\,
	datad => VCC,
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\,
	cout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\);

-- Location: LCCOMB_X50_Y48_N22
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ = !\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\);

-- Location: LCCOMB_X50_Y48_N2
\display|Mod0|auto_generated|divider|divider|StageOut[57]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (((\display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\)))) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\);

-- Location: LCCOMB_X50_Y48_N28
\display|Mod0|auto_generated|divider|divider|StageOut[58]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & ((\display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\) # 
-- ((\display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\)))) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (((\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\);

-- Location: LCCOMB_X50_Y48_N26
\display|Mod0|auto_generated|divider|divider|StageOut[59]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (((\display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\) # 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\)))) # (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\);

-- Location: LCCOMB_X51_Y47_N10
\display|Div1|auto_generated|divider|divider|StageOut[33]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- ((!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datab => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\);

-- Location: LCCOMB_X51_Y47_N0
\display|Div1|auto_generated|divider|divider|StageOut[33]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\);

-- Location: LCCOMB_X50_Y47_N14
\display|Div1|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & 
-- (\total_timer|reg_tim|q\(3))) # (!\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & ((\display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(3),
	datab => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X51_Y47_N14
\display|Div1|auto_generated|divider|divider|StageOut[32]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\);

-- Location: LCCOMB_X51_Y47_N30
\display|Div1|auto_generated|divider|divider|StageOut[31]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ = (\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\);

-- Location: LCCOMB_X51_Y47_N8
\display|Div1|auto_generated|divider|divider|StageOut[31]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ = (\total_timer|reg_tim|q\(2) & \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(2),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\);

-- Location: LCCOMB_X51_Y47_N26
\display|Div1|auto_generated|divider|divider|StageOut[30]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\ = (\total_timer|reg_tim|q\(1) & \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(1),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\);

-- Location: LCCOMB_X51_Y47_N28
\display|Div1|auto_generated|divider|divider|StageOut[30]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\ = (\total_timer|reg_tim|q\(1) & !\display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(1),
	datad => \display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\);

-- Location: LCCOMB_X51_Y47_N16
\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\ = CARRY((\display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\) # (\display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\,
	datad => VCC,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\);

-- Location: LCCOMB_X51_Y47_N18
\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\);

-- Location: LCCOMB_X51_Y47_N20
\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ & ((\display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\) # 
-- (\display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\);

-- Location: LCCOMB_X51_Y47_N22
\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ = CARRY((!\display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ & (!\display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ & 
-- !\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\,
	datab => \display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\,
	datad => VCC,
	cin => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\,
	cout => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\);

-- Location: LCCOMB_X51_Y47_N24
\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ = \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\,
	combout => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\);

-- Location: LCCOMB_X50_Y48_N0
\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\ = !\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\);

-- Location: LCCOMB_X50_Y48_N4
\display|Mod0|auto_generated|divider|divider|StageOut[56]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ = (\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & (!\display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\)) # 
-- (!\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & ((\display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datac => \display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\,
	combout => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\);

-- Location: LCCOMB_X51_Y51_N16
\display|Mux20~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux20~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ $ 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \display|Mux20~0_combout\);

-- Location: LCCOMB_X46_Y49_N18
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\ = \total_timer|reg_tim|q\(3) $ (VCC)
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ = CARRY(\total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(3),
	datad => VCC,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\);

-- Location: LCCOMB_X46_Y49_N20
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\ = (\total_timer|reg_tim|q\(4) & (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ & VCC)) # (!\total_timer|reg_tim|q\(4) & 
-- (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\))
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ = CARRY((!\total_timer|reg_tim|q\(4) & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(4),
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\);

-- Location: LCCOMB_X46_Y49_N22
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\ = (\total_timer|reg_tim|q\(5) & ((GND) # (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\))) # (!\total_timer|reg_tim|q\(5) & 
-- (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ $ (GND)))
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\ = CARRY((\total_timer|reg_tim|q\(5)) # (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(5),
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\);

-- Location: LCCOMB_X46_Y49_N24
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ = (\total_timer|reg_tim|q\(6) & (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\)) # (!\total_timer|reg_tim|q\(6) & 
-- ((\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\) # (GND)))
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ = CARRY((!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\) # (!\total_timer|reg_tim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\);

-- Location: LCCOMB_X46_Y49_N26
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ = (\total_timer|reg_tim|q\(7) & (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ $ (GND))) # (!\total_timer|reg_tim|q\(7) & 
-- (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ & VCC))
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\ = CARRY((\total_timer|reg_tim|q\(7) & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\);

-- Location: LCCOMB_X46_Y49_N28
\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ = !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\);

-- Location: LCCOMB_X47_Y49_N10
\display|Div0|auto_generated|divider|divider|StageOut[54]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\,
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\);

-- Location: LCCOMB_X47_Y49_N4
\display|Div0|auto_generated|divider|divider|StageOut[54]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ = (\total_timer|reg_tim|q\(7) & \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(7),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\);

-- Location: LCCOMB_X46_Y49_N16
\display|Div0|auto_generated|divider|divider|StageOut[53]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \total_timer|reg_tim|q\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \total_timer|reg_tim|q\(6),
	combout => \display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\);

-- Location: LCCOMB_X46_Y49_N30
\display|Div0|auto_generated|divider|divider|StageOut[53]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\,
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\);

-- Location: LCCOMB_X47_Y49_N6
\display|Div0|auto_generated|divider|divider|StageOut[52]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\ & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\,
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\);

-- Location: LCCOMB_X47_Y49_N8
\display|Div0|auto_generated|divider|divider|StageOut[52]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\ = (\total_timer|reg_tim|q\(5) & \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(5),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\);

-- Location: LCCOMB_X46_Y49_N8
\display|Div0|auto_generated|divider|divider|StageOut[51]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\ & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\,
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\);

-- Location: LCCOMB_X47_Y49_N0
\display|Div0|auto_generated|divider|divider|StageOut[51]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\ = (\total_timer|reg_tim|q\(4) & \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(4),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\);

-- Location: LCCOMB_X47_Y49_N12
\display|Div0|auto_generated|divider|divider|StageOut[50]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\ & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\,
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\);

-- Location: LCCOMB_X47_Y49_N2
\display|Div0|auto_generated|divider|divider|StageOut[50]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ = (\total_timer|reg_tim|q\(3) & \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total_timer|reg_tim|q\(3),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\);

-- Location: LCCOMB_X47_Y49_N30
\display|Div0|auto_generated|divider|divider|StageOut[49]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\ = (\total_timer|reg_tim|q\(2) & !\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(2),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\);

-- Location: LCCOMB_X47_Y49_N14
\display|Div0|auto_generated|divider|divider|StageOut[49]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\ = (\total_timer|reg_tim|q\(2) & \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \total_timer|reg_tim|q\(2),
	datad => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\);

-- Location: LCCOMB_X47_Y49_N16
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\ = CARRY((\display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\) # (\display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\,
	datad => VCC,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\);

-- Location: LCCOMB_X47_Y49_N18
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\ = CARRY((!\display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ & (!\display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ & 
-- !\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\,
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\);

-- Location: LCCOMB_X47_Y49_N20
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\ = CARRY((\display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\) # ((\display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\) # 
-- (!\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\,
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\);

-- Location: LCCOMB_X47_Y49_N22
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ = CARRY(((!\display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\ & !\display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\)) # 
-- (!\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\,
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\);

-- Location: LCCOMB_X47_Y49_N24
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\ = CARRY((!\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ & ((\display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\) # 
-- (\display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\,
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\);

-- Location: LCCOMB_X47_Y49_N26
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\ = CARRY((!\display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ & (!\display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ & 
-- !\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\,
	datab => \display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\,
	datad => VCC,
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\,
	cout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\);

-- Location: LCCOMB_X47_Y49_N28
\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ = \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\,
	combout => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\);

-- Location: LCCOMB_X51_Y51_N18
\display|s_dz~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|s_dz~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ & (\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ & 
-- (\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & !\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	datab => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	datac => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	combout => \display|s_dz~0_combout\);

-- Location: LCCOMB_X51_Y51_N28
\display|s_dz~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|s_dz~1_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & \display|s_dz~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \display|s_dz~0_combout\,
	combout => \display|s_dz~1_combout\);

-- Location: LCCOMB_X51_Y51_N22
\display|Mux20~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux20~1_combout\ = (!\display|Mux20~0_combout\ & (\d~input_o\ & !\display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mux20~0_combout\,
	datac => \d~input_o\,
	datad => \display|s_dz~1_combout\,
	combout => \display|Mux20~1_combout\);

-- Location: LCCOMB_X51_Y51_N0
\display|Mux19~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux19~0_combout\ = (\display|s_dz~1_combout\) # ((\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ $ 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \display|s_dz~1_combout\,
	combout => \display|Mux19~0_combout\);

-- Location: LCCOMB_X51_Y51_N6
\display|Mux19~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux19~1_combout\ = (!\display|Mux19~0_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mux19~0_combout\,
	datac => \d~input_o\,
	combout => \display|Mux19~1_combout\);

-- Location: LCCOMB_X51_Y51_N20
\display|Mux18~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux18~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & !\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \display|Mux18~0_combout\);

-- Location: LCCOMB_X51_Y51_N30
\display|res:s_dz[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_dz[2]~0_combout\ = (\display|Mux18~0_combout\ $ (\display|s_dz~1_combout\)) # (!\d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111111001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mux18~0_combout\,
	datac => \d~input_o\,
	datad => \display|s_dz~1_combout\,
	combout => \display|res:s_dz[2]~0_combout\);

-- Location: LCCOMB_X51_Y51_N8
\display|Mux17~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux17~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & ((\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\)) # (!\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ $ 
-- (\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \display|Mux17~0_combout\);

-- Location: LCCOMB_X51_Y51_N26
\display|Mux17~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux17~1_combout\ = (!\display|Mux17~0_combout\ & (\d~input_o\ & !\display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mux17~0_combout\,
	datac => \d~input_o\,
	datad => \display|s_dz~1_combout\,
	combout => \display|Mux17~1_combout\);

-- Location: LCCOMB_X51_Y51_N4
\display|Mux16~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux16~0_combout\ = (\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\) # ((\display|s_dz~1_combout\) # ((\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- !\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \display|s_dz~1_combout\,
	combout => \display|Mux16~0_combout\);

-- Location: LCCOMB_X51_Y51_N14
\display|Mux16~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux16~1_combout\ = (\d~input_o\ & !\display|Mux16~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \d~input_o\,
	datac => \display|Mux16~0_combout\,
	combout => \display|Mux16~1_combout\);

-- Location: LCCOMB_X51_Y51_N24
\display|Mux15~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux15~0_combout\ = (!\display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & ((\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & ((\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\) # 
-- (!\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\))) # (!\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (!\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \display|Mux15~0_combout\);

-- Location: LCCOMB_X51_Y51_N2
\display|Mux15~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux15~1_combout\ = (!\display|Mux15~0_combout\ & (\d~input_o\ & !\display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Mux15~0_combout\,
	datac => \d~input_o\,
	datad => \display|s_dz~1_combout\,
	combout => \display|Mux15~1_combout\);

-- Location: LCCOMB_X51_Y51_N12
\display|Mux14~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux14~0_combout\ = (\display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\) # ((\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & ((!\display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\) # 
-- (!\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\))) # (!\display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (\display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datab => \display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \display|Mux14~0_combout\);

-- Location: LCCOMB_X51_Y51_N10
\display|Mux14~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|Mux14~1_combout\ = (\display|Mux14~0_combout\ & (!\display|s_dz~1_combout\ & \d~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \display|Mux14~0_combout\,
	datab => \display|s_dz~1_combout\,
	datac => \d~input_o\,
	combout => \display|Mux14~1_combout\);

-- Location: LCCOMB_X50_Y51_N26
\display|res:s_c[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_c[0]~0_combout\ = (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_c[0]~0_combout\);

-- Location: LCCOMB_X50_Y51_N28
\display|res:s_c[0]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_c[0]~1_combout\ = (\d~input_o\ & ((!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\) # (!\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	datac => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_c[0]~1_combout\);

-- Location: LCCOMB_X50_Y51_N30
\display|res:s_c[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_c[2]~0_combout\ = (!\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ & \d~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_c[2]~0_combout\);

-- Location: LCCOMB_X50_Y51_N20
\display|res:s_c[4]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \display|res:s_c[4]~0_combout\ = (\display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ & (!\display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \d~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	datac => \display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \d~input_o\,
	combout => \display|res:s_c[4]~0_combout\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_eq <= \eq~output_o\;

ww_l <= \l~output_o\;

ww_sw_z <= \sw_z~output_o\;

ww_RS(0) <= \RS[0]~output_o\;

ww_RS(1) <= \RS[1]~output_o\;

ww_RS(2) <= \RS[2]~output_o\;

ww_RS(3) <= \RS[3]~output_o\;

ww_RS(4) <= \RS[4]~output_o\;

ww_RS(5) <= \RS[5]~output_o\;

ww_RS(6) <= \RS[6]~output_o\;

ww_RS(7) <= \RS[7]~output_o\;

ww_RS(8) <= \RS[8]~output_o\;

ww_RS(9) <= \RS[9]~output_o\;

ww_u(0) <= \u[0]~output_o\;

ww_u(1) <= \u[1]~output_o\;

ww_u(2) <= \u[2]~output_o\;

ww_u(3) <= \u[3]~output_o\;

ww_u(4) <= \u[4]~output_o\;

ww_u(5) <= \u[5]~output_o\;

ww_u(6) <= \u[6]~output_o\;

ww_dz(0) <= \dz[0]~output_o\;

ww_dz(1) <= \dz[1]~output_o\;

ww_dz(2) <= \dz[2]~output_o\;

ww_dz(3) <= \dz[3]~output_o\;

ww_dz(4) <= \dz[4]~output_o\;

ww_dz(5) <= \dz[5]~output_o\;

ww_dz(6) <= \dz[6]~output_o\;

ww_c(0) <= \c[0]~output_o\;

ww_c(1) <= \c[1]~output_o\;

ww_c(2) <= \c[2]~output_o\;

ww_c(3) <= \c[3]~output_o\;

ww_c(4) <= \c[4]~output_o\;

ww_c(5) <= \c[5]~output_o\;

ww_c(6) <= \c[6]~output_o\;
END structure;


