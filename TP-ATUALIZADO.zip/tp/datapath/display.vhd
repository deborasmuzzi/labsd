library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity display is 
	port (
	FT : in std_logic_vector(7 downto 0);
	e : in std_logic;
	u : out std_logic_vector(6 downto 0);
	dz : out std_logic_vector(6 downto 0);
	c : out std_logic_vector(6 downto 0)
	);
end;

architecture arch of display is
	--segmento acende com '0';
	constant a : boolean := true;
	signal unidade, dezena, centena : integer range 0 to 9;
	
	-- função de determinação de cada segmento do display 
	function seg(n : integer range 0 to 9) return std_logic_vector is
	begin
		case n is
			when 0 => return "0111111";
			when 1 => return "0000110";
			when 2 => return "1011011";
			when 3 => return "1001111";
			when 4 => return "1100110";
			when 5 => return "1101101";
			when 6 => return "1111101";
			when 7 => return "0000111";
			when 8 => return "1111111";
			when 9 => return "1101111";
		end case;
	end function;
	
begin
--separa tempo total em centena, dezena e unidade transformando o binário para inteiro 
	separa_digitos : process(FT)
		variable v : integer range 0 to 255;
	begin
		v := to_integer(unsigned(FT));
		centena <= v/100;
		dezena <= (v/10) mod 10;
		unidade <= v mod 10;
	end process;
	
	res : process(e, centena, dezena, unidade)
		variable s_u, s_dz, s_c : std_logic_vector(6 downto 0);
		begin
		s_u  := "0000000";
		s_dz := "0000000";
		s_c  := "0000000";
		
		if e = '1' then --enable para display 
			s_u := seg(unidade);
			if centena /= 0 then -- se centena diferente de 0
				s_c := seg(centena);
				s_dz := seg(dezena); --se dezena diferente de 0
			elsif dezena /= 0 then 
				s_dz := seg(dezena);
			end if;
		end if;
		
		if a then 
			u <= not s_u;
			dz <= not s_dz;
			c <= not s_c;
		else 
			u <= s_u;
			dz <= s_dz;
			c <= s_c;
		end if;
		end process;
		
end;