library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;


entity datapath is
	port(
	SW : in std_logic_vector(9 downto 0);
	STG : in std_logic_vector(2 downto 0);
	ld_lev, ld_tim, ld_rand, d: in std_logic;
	clr_lev, clr_tim, clr_rand : in std_logic;
	clk : in std_logic;
	eq, l, sw_z : out std_logic;
	RS : out std_logic_vector(9 downto 0);
	u, dz, c : out std_logic_vector(6 downto 0)
	);
end;


architecture arch of datapath is
	signal CL : std_logic_vector(2 downto 0);
	signal NL : std_logic_vector (2 downto 0);
	
	signal CGT, NGT : std_logic_vector(7 downto 0);
	
	signal CT, NT : std_logic_vector(7 downto 0);
	signal ROUT : std_logic_vector(9 downto 0);
	
	signal FT : std_logic_vector(7 downto 0);
	
begin 

total_level : entity work.total_level
	port map(
	clk => clk,
	ld_lev => ld_lev,
	clr_lev => clr_lev,
	PL => NL,
	NL => CL
);

adder_level : entity work.adder_level
	port map(
	PL => CL,
	NL => NL
	);
	
comparator_level : entity work.comparator_level
	port map(
	CL => CL,
	eq => l
	);

	
total_timer : entity work.total_timer
	port map (
	clk => clk,
	ld_tim => ld_tim,
	clr_tim => clr_tim,
	PT => CT,
	NT => NT
	);

adder_timer : entity work.adder_timer
	port map(
	PT => NT,
	NT => CT
	);

total_Gtimer : entity work.total_Gtimer
	port map(
	clk => clk,
	PGT => CGT,
	NGT => NGT
	);
	
adder_Gtimer : entity work.adder_Gtimer
	port map(
	PGT => NGT,
	NGT => CGT
	);

rand : entity work.rand
	generic map (
			W => 8,
			STG_W => 3
	)
	port map(
	ld => ld_rand,
	clk => clk,
	clr => clr_rand,
	STG_In => STG,
	Time_In => NGT,
	S => ROUT
	);
	
comparator_rand : entity work.comparator_rand
	port map(
	A => ROUT,
	B => SW,
	eq => eq
	);

comparator_zero : entity work.comparator_zero
	port map(
	SW => SW,
	eq => sw_z
	);
	
display : entity work.display
	port map(
	FT => FT,
	e => d,
	u => u, 
	dz => dz,
	c => c
	);
	
	
FT <= NT;
RS <= ROUT; 
end;