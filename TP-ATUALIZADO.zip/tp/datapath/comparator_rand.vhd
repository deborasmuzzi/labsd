library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity comparator_rand is
	port(
	A : in std_logic_vector(9 downto 0);
	B : in std_logic_vector(9 downto 0);
	eq   : out std_logic
	);
end;

architecture arch of comparator_rand is

begin
comp_rand : entity work.comparator
	generic map (data_width => 10)
	port map (
	a => A,
	b => B,
	eq => eq,
	gt => open, 
	lt => open
	);

end;