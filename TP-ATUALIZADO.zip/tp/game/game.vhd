library IEEE;
use IEEE.STD_LOGIC_1164.all;

entity game is
	port(
	SW : in std_logic_vector(9 downto 0);
	m : in std_logic_vector(2 downto 0);
	p, a : in std_logic;
	clk : in std_logic;
	RS : out std_logic_vector(9 downto 0);
	u, dz, c : out std_logic_vector(6 downto 0)
	);
end;

architecture arch of game is
	signal eq, l, sw_z : std_logic;
	signal ld_lev, ld_tim, ld_rand : std_logic;
	signal clr_lev, clr_tim, clr_rand : std_logic;
	signal stg : std_logic_vector(2 downto 0);
	signal d : std_logic;
	signal d_clock : std_logic;
begin

	clock_div : entity work.clock_div
		port map(
		clock => clk,
		clock_mod => d_clock
		);
		
	datapth : entity work.datapath
		port map(
		clk => d_clock,
		SW => SW,
		STG => stg,
		ld_lev => ld_lev, 
		ld_tim => ld_tim,
		ld_rand => ld_rand,
		clr_lev => clr_lev,
		clr_tim => clr_tim,
		clr_rand => clr_rand,
		d => d,
		eq => eq,
		l => l,
		sw_z => sw_z,
		RS => RS,
		u => u,
		dz => dz,
		c => c
		);
	 
	 controller : entity work.controller 
		port map(
		clk => d_clock,
		eq => eq,
		l => l,
		p => p,
		sw_z => sw_z,
		a => a,
		m => m,
		stg => stg,
		d => d,
		clr_tim => clr_tim,
		clr_rand => clr_rand,
		clr_lev => clr_lev,
		ld_lev => ld_lev, 
		ld_rand => ld_rand,
		ld_tim => ld_tim
		);
	

end;