-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "11/09/2026 22:37:18"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	game IS
    PORT (
	SW : IN std_logic_vector(9 DOWNTO 0);
	m : IN std_logic_vector(2 DOWNTO 0);
	p : IN std_logic;
	a : IN std_logic;
	clk : IN std_logic;
	RS : OUT std_logic_vector(9 DOWNTO 0);
	u : OUT std_logic_vector(6 DOWNTO 0);
	dz : OUT std_logic_vector(6 DOWNTO 0);
	c : OUT std_logic_vector(6 DOWNTO 0)
	);
END game;

-- Design Ports Information
-- RS[0]	=>  Location: PIN_A8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[1]	=>  Location: PIN_A9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[2]	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[3]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[4]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[5]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[6]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[7]	=>  Location: PIN_D14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[8]	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- RS[9]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[0]	=>  Location: PIN_B3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[1]	=>  Location: PIN_D10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[2]	=>  Location: PIN_A3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[3]	=>  Location: PIN_A2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[4]	=>  Location: PIN_A4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[5]	=>  Location: PIN_J10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- u[6]	=>  Location: PIN_D9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[0]	=>  Location: PIN_H11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[1]	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[2]	=>  Location: PIN_L18,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[3]	=>  Location: PIN_B7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[4]	=>  Location: PIN_E10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[5]	=>  Location: PIN_C8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- dz[6]	=>  Location: PIN_A6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[0]	=>  Location: PIN_C6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[1]	=>  Location: PIN_C7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[2]	=>  Location: PIN_A5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[3]	=>  Location: PIN_D7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[4]	=>  Location: PIN_D8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[5]	=>  Location: PIN_AA13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c[6]	=>  Location: PIN_E9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[1]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[0]	=>  Location: PIN_C9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[3]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[2]	=>  Location: PIN_E21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[8]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[9]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[7]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[6]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[5]	=>  Location: PIN_B12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SW[4]	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_P11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- m[2]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- m[1]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- m[0]	=>  Location: PIN_C10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- p	=>  Location: PIN_A7,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF game IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_SW : std_logic_vector(9 DOWNTO 0);
SIGNAL ww_m : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_p : std_logic;
SIGNAL ww_a : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_RS : std_logic_vector(9 DOWNTO 0);
SIGNAL ww_u : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_dz : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_c : std_logic_vector(6 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \clock_div|clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \RS[0]~output_o\ : std_logic;
SIGNAL \RS[1]~output_o\ : std_logic;
SIGNAL \RS[2]~output_o\ : std_logic;
SIGNAL \RS[3]~output_o\ : std_logic;
SIGNAL \RS[4]~output_o\ : std_logic;
SIGNAL \RS[5]~output_o\ : std_logic;
SIGNAL \RS[6]~output_o\ : std_logic;
SIGNAL \RS[7]~output_o\ : std_logic;
SIGNAL \RS[8]~output_o\ : std_logic;
SIGNAL \RS[9]~output_o\ : std_logic;
SIGNAL \u[0]~output_o\ : std_logic;
SIGNAL \u[1]~output_o\ : std_logic;
SIGNAL \u[2]~output_o\ : std_logic;
SIGNAL \u[3]~output_o\ : std_logic;
SIGNAL \u[4]~output_o\ : std_logic;
SIGNAL \u[5]~output_o\ : std_logic;
SIGNAL \u[6]~output_o\ : std_logic;
SIGNAL \dz[0]~output_o\ : std_logic;
SIGNAL \dz[1]~output_o\ : std_logic;
SIGNAL \dz[2]~output_o\ : std_logic;
SIGNAL \dz[3]~output_o\ : std_logic;
SIGNAL \dz[4]~output_o\ : std_logic;
SIGNAL \dz[5]~output_o\ : std_logic;
SIGNAL \dz[6]~output_o\ : std_logic;
SIGNAL \c[0]~output_o\ : std_logic;
SIGNAL \c[1]~output_o\ : std_logic;
SIGNAL \c[2]~output_o\ : std_logic;
SIGNAL \c[3]~output_o\ : std_logic;
SIGNAL \c[4]~output_o\ : std_logic;
SIGNAL \c[5]~output_o\ : std_logic;
SIGNAL \c[6]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \clock_div|Add0~0_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[0]~q\ : std_logic;
SIGNAL \clock_div|Add0~1\ : std_logic;
SIGNAL \clock_div|Add0~2_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[1]~q\ : std_logic;
SIGNAL \clock_div|Add0~3\ : std_logic;
SIGNAL \clock_div|Add0~4_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[2]~q\ : std_logic;
SIGNAL \clock_div|Add0~5\ : std_logic;
SIGNAL \clock_div|Add0~6_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[3]~q\ : std_logic;
SIGNAL \clock_div|Add0~7\ : std_logic;
SIGNAL \clock_div|Add0~8_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[4]~q\ : std_logic;
SIGNAL \clock_div|Add0~9\ : std_logic;
SIGNAL \clock_div|Add0~10_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[5]~q\ : std_logic;
SIGNAL \clock_div|Add0~11\ : std_logic;
SIGNAL \clock_div|Add0~12_combout\ : std_logic;
SIGNAL \clock_div|count_var~1_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[6]~q\ : std_logic;
SIGNAL \clock_div|Add0~13\ : std_logic;
SIGNAL \clock_div|Add0~14_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[7]~q\ : std_logic;
SIGNAL \clock_div|Add0~15\ : std_logic;
SIGNAL \clock_div|Add0~16_combout\ : std_logic;
SIGNAL \clock_div|count_var~0_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[8]~q\ : std_logic;
SIGNAL \clock_div|Add0~17\ : std_logic;
SIGNAL \clock_div|Add0~18_combout\ : std_logic;
SIGNAL \clock_div|count_var~2_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[9]~q\ : std_logic;
SIGNAL \clock_div|Add0~19\ : std_logic;
SIGNAL \clock_div|Add0~20_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[10]~q\ : std_logic;
SIGNAL \clock_div|Add0~21\ : std_logic;
SIGNAL \clock_div|Add0~22_combout\ : std_logic;
SIGNAL \clock_div|count_var~3_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[11]~q\ : std_logic;
SIGNAL \clock_div|Add0~23\ : std_logic;
SIGNAL \clock_div|Add0~24_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[12]~q\ : std_logic;
SIGNAL \clock_div|Add0~25\ : std_logic;
SIGNAL \clock_div|Add0~26_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[13]~q\ : std_logic;
SIGNAL \clock_div|Add0~27\ : std_logic;
SIGNAL \clock_div|Add0~28_combout\ : std_logic;
SIGNAL \clock_div|count_var~4_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[14]~q\ : std_logic;
SIGNAL \clock_div|Add0~29\ : std_logic;
SIGNAL \clock_div|Add0~30_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[15]~q\ : std_logic;
SIGNAL \clock_div|Equal0~3_combout\ : std_logic;
SIGNAL \clock_div|Equal0~1_combout\ : std_logic;
SIGNAL \clock_div|Equal0~2_combout\ : std_logic;
SIGNAL \clock_div|Equal0~0_combout\ : std_logic;
SIGNAL \clock_div|Equal0~4_combout\ : std_logic;
SIGNAL \clock_div|Add0~31\ : std_logic;
SIGNAL \clock_div|Add0~32_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[16]~q\ : std_logic;
SIGNAL \clock_div|Add0~33\ : std_logic;
SIGNAL \clock_div|Add0~34_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[17]~q\ : std_logic;
SIGNAL \clock_div|Add0~35\ : std_logic;
SIGNAL \clock_div|Add0~36_combout\ : std_logic;
SIGNAL \clock_div|count_var~5_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[18]~q\ : std_logic;
SIGNAL \clock_div|Add0~37\ : std_logic;
SIGNAL \clock_div|Add0~38_combout\ : std_logic;
SIGNAL \clock_div|count_var~6_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[19]~q\ : std_logic;
SIGNAL \clock_div|Add0~39\ : std_logic;
SIGNAL \clock_div|Add0~40_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[20]~q\ : std_logic;
SIGNAL \clock_div|Add0~41\ : std_logic;
SIGNAL \clock_div|Add0~42_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[21]~q\ : std_logic;
SIGNAL \clock_div|Add0~43\ : std_logic;
SIGNAL \clock_div|Add0~44_combout\ : std_logic;
SIGNAL \clock_div|count_var~7_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[22]~q\ : std_logic;
SIGNAL \clock_div|Equal0~5_combout\ : std_logic;
SIGNAL \clock_div|Equal0~6_combout\ : std_logic;
SIGNAL \clock_div|clk~0_combout\ : std_logic;
SIGNAL \clock_div|clk~feeder_combout\ : std_logic;
SIGNAL \clock_div|clk~q\ : std_logic;
SIGNAL \clock_div|clk~clkctrl_outclk\ : std_logic;
SIGNAL \SW[8]~input_o\ : std_logic;
SIGNAL \SW[9]~input_o\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[0]~21_combout\ : std_logic;
SIGNAL \m[0]~input_o\ : std_logic;
SIGNAL \m[1]~input_o\ : std_logic;
SIGNAL \p~input_o\ : std_logic;
SIGNAL \m[2]~input_o\ : std_logic;
SIGNAL \controller|comb_proc~0_combout\ : std_logic;
SIGNAL \a~input_o\ : std_logic;
SIGNAL \controller|Selector8~0_combout\ : std_logic;
SIGNAL \controller|PS.S4~q\ : std_logic;
SIGNAL \controller|Selector1~0_combout\ : std_logic;
SIGNAL \controller|Selector1~1_combout\ : std_logic;
SIGNAL \controller|Selector1~2_combout\ : std_logic;
SIGNAL \controller|PS.S0~q\ : std_logic;
SIGNAL \SW[4]~input_o\ : std_logic;
SIGNAL \SW[6]~input_o\ : std_logic;
SIGNAL \SW[5]~input_o\ : std_logic;
SIGNAL \SW[7]~input_o\ : std_logic;
SIGNAL \datapth|comparator_zero|comp_lev|Equal0~1_combout\ : std_logic;
SIGNAL \SW[3]~input_o\ : std_logic;
SIGNAL \SW[0]~input_o\ : std_logic;
SIGNAL \SW[1]~input_o\ : std_logic;
SIGNAL \SW[2]~input_o\ : std_logic;
SIGNAL \datapth|comparator_zero|comp_lev|Equal0~0_combout\ : std_logic;
SIGNAL \datapth|comparator_zero|comp_lev|Equal0~2_combout\ : std_logic;
SIGNAL \controller|Selector10~1_combout\ : std_logic;
SIGNAL \datapth|total_level|reg_lev|q[1]~2_combout\ : std_logic;
SIGNAL \datapth|total_level|reg_lev|q[2]~1_combout\ : std_logic;
SIGNAL \controller|Selector2~0_combout\ : std_logic;
SIGNAL \controller|comb_proc~1_combout\ : std_logic;
SIGNAL \controller|Selector2~1_combout\ : std_logic;
SIGNAL \controller|Selector3~0_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[1]~7_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[1]~8\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[2]~9_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[2]~10\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[3]~11_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[3]~12\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[4]~13_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[4]~14\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[5]~15_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[5]~16\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[6]~17_combout\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[6]~18\ : std_logic;
SIGNAL \datapth|total_Gtimer|reg_Gtim|q[7]~19_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~7\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~9\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~11\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~13\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~15\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~7\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~9\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~11\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~13\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_5~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~15\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\ : std_logic;
SIGNAL \datapth|rand|Equal1~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft1~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107_combout\ : std_logic;
SIGNAL \datapth|rand|Equal2~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft2~0_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~2_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~4_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~7_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~8_combout\ : std_logic;
SIGNAL \datapth|rand|S_2~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux8~0_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~7_combout\ : std_logic;
SIGNAL \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~3_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~1_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~4_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~2_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~3_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~5_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mux8~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux8~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux8~3_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft3~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft1~1_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft2~1_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~2_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~5_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~9_combout\ : std_logic;
SIGNAL \datapth|rand|S_2~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux7~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux7~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux7~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux7~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft3~1_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft1~2_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft2~2_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~10_combout\ : std_logic;
SIGNAL \datapth|rand|S_2~3_combout\ : std_logic;
SIGNAL \datapth|rand|Mux6~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux6~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux6~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux6~3_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~1_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~2_combout\ : std_logic;
SIGNAL \controller|Selector3~1_combout\ : std_logic;
SIGNAL \controller|PS.P1~q\ : std_logic;
SIGNAL \controller|Selector2~2_combout\ : std_logic;
SIGNAL \controller|PS.S1~q\ : std_logic;
SIGNAL \controller|comb_proc~2_combout\ : std_logic;
SIGNAL \controller|Selector4~0_combout\ : std_logic;
SIGNAL \controller|Selector4~1_combout\ : std_logic;
SIGNAL \controller|PS.S2~q\ : std_logic;
SIGNAL \controller|Selector6~0_combout\ : std_logic;
SIGNAL \controller|Selector6~1_combout\ : std_logic;
SIGNAL \controller|PS.S3~q\ : std_logic;
SIGNAL \controller|Selector10~0_combout\ : std_logic;
SIGNAL \datapth|total_level|reg_lev|q[0]~0_combout\ : std_logic;
SIGNAL \datapth|comparator_level|comp_lev|Equal0~0_combout\ : std_logic;
SIGNAL \controller|Selector5~0_combout\ : std_logic;
SIGNAL \controller|Selector5~1_combout\ : std_logic;
SIGNAL \controller|PS.P2~q\ : std_logic;
SIGNAL \controller|WideOr1~combout\ : std_logic;
SIGNAL \controller|Selector0~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|op_6~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft1~4_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft2~4_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~8_combout\ : std_logic;
SIGNAL \datapth|rand|Equal2~1_combout\ : std_logic;
SIGNAL \datapth|rand|Equal2~2_combout\ : std_logic;
SIGNAL \datapth|rand|Equal2~3_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~2_combout\ : std_logic;
SIGNAL \datapth|rand|Equal0~8_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~3_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux1~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux1~1_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~9_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~14_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~5_combout\ : std_logic;
SIGNAL \datapth|rand|Mux0~6_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~4_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~11_combout\ : std_logic;
SIGNAL \datapth|rand|Mux3~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux5~0_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mux5~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux3~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux3~2_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~5_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~7_combout\ : std_logic;
SIGNAL \datapth|rand|Mux2~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~13_combout\ : std_logic;
SIGNAL \datapth|rand|Mux2~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux2~2_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~4_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux5~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft2~3_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft1~3_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~4_combout\ : std_logic;
SIGNAL \datapth|rand|Mux5~2_combout\ : std_logic;
SIGNAL \datapth|rand|Mux5~4_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~3_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~5_combout\ : std_logic;
SIGNAL \datapth|rand|Mux4~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~12_combout\ : std_logic;
SIGNAL \datapth|rand|Mux4~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux4~2_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~5_combout\ : std_logic;
SIGNAL \datapth|comparator_rand|comp_rand|Equal0~6_combout\ : std_logic;
SIGNAL \controller|Selector7~0_combout\ : std_logic;
SIGNAL \controller|Selector7~1_combout\ : std_logic;
SIGNAL \controller|PS.P3~q\ : std_logic;
SIGNAL \datapth|rand|Equal1~2_combout\ : std_logic;
SIGNAL \datapth|rand|Equal1~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~7_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~8_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft4~0_combout\ : std_logic;
SIGNAL \datapth|rand|S_3~0_combout\ : std_logic;
SIGNAL \datapth|rand|ShiftLeft0~6_combout\ : std_logic;
SIGNAL \datapth|rand|S_2~0_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~1_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~5_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~6_combout\ : std_logic;
SIGNAL \datapth|rand|Mux9~9_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[0]~7_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[1]~8_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[1]~9\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[2]~10_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[2]~11\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[3]~12_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[3]~13\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[4]~14_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[4]~15\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[5]~16_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[5]~17\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[6]~18_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[6]~19\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q[7]~20_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ : std_logic;
SIGNAL \datapth|display|Mux6~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[0]~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux3~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[3]~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[4]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux1~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[5]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux0~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_u[6]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ : std_logic;
SIGNAL \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ : std_logic;
SIGNAL \datapth|display|Mux20~0_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\ : std_logic;
SIGNAL \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ : std_logic;
SIGNAL \datapth|display|s_dz~0_combout\ : std_logic;
SIGNAL \datapth|display|s_dz~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux20~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux19~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux19~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux18~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_dz[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux17~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux17~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux16~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux16~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux15~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux15~1_combout\ : std_logic;
SIGNAL \datapth|display|Mux14~0_combout\ : std_logic;
SIGNAL \datapth|display|Mux14~1_combout\ : std_logic;
SIGNAL \datapth|display|res:s_c[0]~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_c[0]~1_combout\ : std_logic;
SIGNAL \datapth|display|res:s_c[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|res:s_c[4]~0_combout\ : std_logic;
SIGNAL \datapth|total_timer|reg_tim|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \datapth|total_Gtimer|reg_Gtim|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \datapth|total_level|reg_lev|q\ : std_logic_vector(2 DOWNTO 0);
SIGNAL \datapth|rand|reg_rand|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \controller|ALT_INV_Selector0~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_c[4]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_c[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_c[0]~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_c[0]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux14~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux15~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux16~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux17~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux19~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_Mux20~1_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[6]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[5]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[4]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[3]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[2]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[1]~0_combout\ : std_logic;
SIGNAL \datapth|display|ALT_INV_res:s_u[0]~0_combout\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_SW <= SW;
ww_m <= m;
ww_p <= p;
ww_a <= a;
ww_clk <= clk;
RS <= ww_RS;
u <= ww_u;
dz <= ww_dz;
c <= ww_c;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\clock_div|clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clock_div|clk~q\);

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\controller|ALT_INV_Selector0~0_combout\ <= NOT \controller|Selector0~0_combout\;
\datapth|display|ALT_INV_res:s_c[4]~0_combout\ <= NOT \datapth|display|res:s_c[4]~0_combout\;
\datapth|display|ALT_INV_res:s_c[2]~0_combout\ <= NOT \datapth|display|res:s_c[2]~0_combout\;
\datapth|display|ALT_INV_res:s_c[0]~1_combout\ <= NOT \datapth|display|res:s_c[0]~1_combout\;
\datapth|display|ALT_INV_res:s_c[0]~0_combout\ <= NOT \datapth|display|res:s_c[0]~0_combout\;
\datapth|display|ALT_INV_Mux14~1_combout\ <= NOT \datapth|display|Mux14~1_combout\;
\datapth|display|ALT_INV_Mux15~1_combout\ <= NOT \datapth|display|Mux15~1_combout\;
\datapth|display|ALT_INV_Mux16~1_combout\ <= NOT \datapth|display|Mux16~1_combout\;
\datapth|display|ALT_INV_Mux17~1_combout\ <= NOT \datapth|display|Mux17~1_combout\;
\datapth|display|ALT_INV_Mux19~1_combout\ <= NOT \datapth|display|Mux19~1_combout\;
\datapth|display|ALT_INV_Mux20~1_combout\ <= NOT \datapth|display|Mux20~1_combout\;
\datapth|display|ALT_INV_res:s_u[6]~0_combout\ <= NOT \datapth|display|res:s_u[6]~0_combout\;
\datapth|display|ALT_INV_res:s_u[5]~0_combout\ <= NOT \datapth|display|res:s_u[5]~0_combout\;
\datapth|display|ALT_INV_res:s_u[4]~0_combout\ <= NOT \datapth|display|res:s_u[4]~0_combout\;
\datapth|display|ALT_INV_res:s_u[3]~0_combout\ <= NOT \datapth|display|res:s_u[3]~0_combout\;
\datapth|display|ALT_INV_res:s_u[2]~0_combout\ <= NOT \datapth|display|res:s_u[2]~0_combout\;
\datapth|display|ALT_INV_res:s_u[1]~0_combout\ <= NOT \datapth|display|res:s_u[1]~0_combout\;
\datapth|display|ALT_INV_res:s_u[0]~0_combout\ <= NOT \datapth|display|res:s_u[0]~0_combout\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y45_N20
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X46_Y54_N2
\RS[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux9~9_combout\,
	devoe => ww_devoe,
	o => \RS[0]~output_o\);

-- Location: IOOBUF_X46_Y54_N23
\RS[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux8~3_combout\,
	devoe => ww_devoe,
	o => \RS[1]~output_o\);

-- Location: IOOBUF_X51_Y54_N16
\RS[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux7~3_combout\,
	devoe => ww_devoe,
	o => \RS[2]~output_o\);

-- Location: IOOBUF_X46_Y54_N9
\RS[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux6~3_combout\,
	devoe => ww_devoe,
	o => \RS[3]~output_o\);

-- Location: IOOBUF_X56_Y54_N30
\RS[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux5~4_combout\,
	devoe => ww_devoe,
	o => \RS[4]~output_o\);

-- Location: IOOBUF_X58_Y54_N23
\RS[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux4~2_combout\,
	devoe => ww_devoe,
	o => \RS[5]~output_o\);

-- Location: IOOBUF_X66_Y54_N23
\RS[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux3~2_combout\,
	devoe => ww_devoe,
	o => \RS[6]~output_o\);

-- Location: IOOBUF_X56_Y54_N9
\RS[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux2~2_combout\,
	devoe => ww_devoe,
	o => \RS[7]~output_o\);

-- Location: IOOBUF_X51_Y54_N9
\RS[8]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux1~1_combout\,
	devoe => ww_devoe,
	o => \RS[8]~output_o\);

-- Location: IOOBUF_X49_Y54_N9
\RS[9]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|rand|Mux0~6_combout\,
	devoe => ww_devoe,
	o => \RS[9]~output_o\);

-- Location: IOOBUF_X26_Y39_N16
\u[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[0]~0_combout\,
	devoe => ww_devoe,
	o => \u[0]~output_o\);

-- Location: IOOBUF_X31_Y39_N30
\u[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[1]~0_combout\,
	devoe => ww_devoe,
	o => \u[1]~output_o\);

-- Location: IOOBUF_X26_Y39_N9
\u[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[2]~0_combout\,
	devoe => ww_devoe,
	o => \u[2]~output_o\);

-- Location: IOOBUF_X26_Y39_N2
\u[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[3]~0_combout\,
	devoe => ww_devoe,
	o => \u[3]~output_o\);

-- Location: IOOBUF_X31_Y39_N23
\u[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[4]~0_combout\,
	devoe => ww_devoe,
	o => \u[4]~output_o\);

-- Location: IOOBUF_X34_Y39_N9
\u[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[5]~0_combout\,
	devoe => ww_devoe,
	o => \u[5]~output_o\);

-- Location: IOOBUF_X31_Y39_N9
\u[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_u[6]~0_combout\,
	devoe => ww_devoe,
	o => \u[6]~output_o\);

-- Location: IOOBUF_X34_Y39_N16
\dz[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux20~1_combout\,
	devoe => ww_devoe,
	o => \dz[0]~output_o\);

-- Location: IOOBUF_X36_Y39_N16
\dz[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux19~1_combout\,
	devoe => ww_devoe,
	o => \dz[1]~output_o\);

-- Location: IOOBUF_X78_Y37_N16
\dz[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|res:s_dz[2]~0_combout\,
	devoe => ww_devoe,
	o => \dz[2]~output_o\);

-- Location: IOOBUF_X34_Y39_N23
\dz[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux17~1_combout\,
	devoe => ww_devoe,
	o => \dz[3]~output_o\);

-- Location: IOOBUF_X36_Y39_N23
\dz[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux16~1_combout\,
	devoe => ww_devoe,
	o => \dz[4]~output_o\);

-- Location: IOOBUF_X36_Y39_N30
\dz[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux15~1_combout\,
	devoe => ww_devoe,
	o => \dz[5]~output_o\);

-- Location: IOOBUF_X34_Y39_N30
\dz[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_Mux14~1_combout\,
	devoe => ww_devoe,
	o => \dz[6]~output_o\);

-- Location: IOOBUF_X29_Y39_N9
\c[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[0]~output_o\);

-- Location: IOOBUF_X34_Y39_N2
\c[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[0]~1_combout\,
	devoe => ww_devoe,
	o => \c[1]~output_o\);

-- Location: IOOBUF_X31_Y39_N16
\c[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[2]~0_combout\,
	devoe => ww_devoe,
	o => \c[2]~output_o\);

-- Location: IOOBUF_X29_Y39_N16
\c[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[3]~output_o\);

-- Location: IOOBUF_X31_Y39_N2
\c[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[4]~0_combout\,
	devoe => ww_devoe,
	o => \c[4]~output_o\);

-- Location: IOOBUF_X49_Y0_N16
\c[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => VCC,
	devoe => ww_devoe,
	o => \c[5]~output_o\);

-- Location: IOOBUF_X29_Y39_N2
\c[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapth|display|ALT_INV_res:s_c[0]~0_combout\,
	devoe => ww_devoe,
	o => \c[6]~output_o\);

-- Location: IOIBUF_X34_Y0_N29
\clk~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G19
\clk~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X75_Y40_N10
\clock_div|Add0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~0_combout\ = \clock_div|clock_div_process:count_var[0]~q\ $ (VCC)
-- \clock_div|Add0~1\ = CARRY(\clock_div|clock_div_process:count_var[0]~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[0]~q\,
	datad => VCC,
	combout => \clock_div|Add0~0_combout\,
	cout => \clock_div|Add0~1\);

-- Location: FF_X75_Y40_N11
\clock_div|clock_div_process:count_var[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[0]~q\);

-- Location: LCCOMB_X75_Y40_N12
\clock_div|Add0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~2_combout\ = (\clock_div|clock_div_process:count_var[1]~q\ & (!\clock_div|Add0~1\)) # (!\clock_div|clock_div_process:count_var[1]~q\ & ((\clock_div|Add0~1\) # (GND)))
-- \clock_div|Add0~3\ = CARRY((!\clock_div|Add0~1\) # (!\clock_div|clock_div_process:count_var[1]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[1]~q\,
	datad => VCC,
	cin => \clock_div|Add0~1\,
	combout => \clock_div|Add0~2_combout\,
	cout => \clock_div|Add0~3\);

-- Location: FF_X75_Y40_N13
\clock_div|clock_div_process:count_var[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[1]~q\);

-- Location: LCCOMB_X75_Y40_N14
\clock_div|Add0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~4_combout\ = (\clock_div|clock_div_process:count_var[2]~q\ & (\clock_div|Add0~3\ $ (GND))) # (!\clock_div|clock_div_process:count_var[2]~q\ & (!\clock_div|Add0~3\ & VCC))
-- \clock_div|Add0~5\ = CARRY((\clock_div|clock_div_process:count_var[2]~q\ & !\clock_div|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[2]~q\,
	datad => VCC,
	cin => \clock_div|Add0~3\,
	combout => \clock_div|Add0~4_combout\,
	cout => \clock_div|Add0~5\);

-- Location: FF_X75_Y40_N15
\clock_div|clock_div_process:count_var[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[2]~q\);

-- Location: LCCOMB_X75_Y40_N16
\clock_div|Add0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~6_combout\ = (\clock_div|clock_div_process:count_var[3]~q\ & (!\clock_div|Add0~5\)) # (!\clock_div|clock_div_process:count_var[3]~q\ & ((\clock_div|Add0~5\) # (GND)))
-- \clock_div|Add0~7\ = CARRY((!\clock_div|Add0~5\) # (!\clock_div|clock_div_process:count_var[3]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[3]~q\,
	datad => VCC,
	cin => \clock_div|Add0~5\,
	combout => \clock_div|Add0~6_combout\,
	cout => \clock_div|Add0~7\);

-- Location: FF_X75_Y40_N17
\clock_div|clock_div_process:count_var[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[3]~q\);

-- Location: LCCOMB_X75_Y40_N18
\clock_div|Add0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~8_combout\ = (\clock_div|clock_div_process:count_var[4]~q\ & (\clock_div|Add0~7\ $ (GND))) # (!\clock_div|clock_div_process:count_var[4]~q\ & (!\clock_div|Add0~7\ & VCC))
-- \clock_div|Add0~9\ = CARRY((\clock_div|clock_div_process:count_var[4]~q\ & !\clock_div|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[4]~q\,
	datad => VCC,
	cin => \clock_div|Add0~7\,
	combout => \clock_div|Add0~8_combout\,
	cout => \clock_div|Add0~9\);

-- Location: FF_X75_Y40_N19
\clock_div|clock_div_process:count_var[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[4]~q\);

-- Location: LCCOMB_X75_Y40_N20
\clock_div|Add0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~10_combout\ = (\clock_div|clock_div_process:count_var[5]~q\ & (!\clock_div|Add0~9\)) # (!\clock_div|clock_div_process:count_var[5]~q\ & ((\clock_div|Add0~9\) # (GND)))
-- \clock_div|Add0~11\ = CARRY((!\clock_div|Add0~9\) # (!\clock_div|clock_div_process:count_var[5]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[5]~q\,
	datad => VCC,
	cin => \clock_div|Add0~9\,
	combout => \clock_div|Add0~10_combout\,
	cout => \clock_div|Add0~11\);

-- Location: FF_X75_Y40_N21
\clock_div|clock_div_process:count_var[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[5]~q\);

-- Location: LCCOMB_X75_Y40_N22
\clock_div|Add0~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~12_combout\ = (\clock_div|clock_div_process:count_var[6]~q\ & (\clock_div|Add0~11\ $ (GND))) # (!\clock_div|clock_div_process:count_var[6]~q\ & (!\clock_div|Add0~11\ & VCC))
-- \clock_div|Add0~13\ = CARRY((\clock_div|clock_div_process:count_var[6]~q\ & !\clock_div|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[6]~q\,
	datad => VCC,
	cin => \clock_div|Add0~11\,
	combout => \clock_div|Add0~12_combout\,
	cout => \clock_div|Add0~13\);

-- Location: LCCOMB_X75_Y40_N2
\clock_div|count_var~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~1_combout\ = (\clock_div|Add0~12_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Add0~12_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~1_combout\);

-- Location: FF_X75_Y40_N3
\clock_div|clock_div_process:count_var[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[6]~q\);

-- Location: LCCOMB_X75_Y40_N24
\clock_div|Add0~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~14_combout\ = (\clock_div|clock_div_process:count_var[7]~q\ & (!\clock_div|Add0~13\)) # (!\clock_div|clock_div_process:count_var[7]~q\ & ((\clock_div|Add0~13\) # (GND)))
-- \clock_div|Add0~15\ = CARRY((!\clock_div|Add0~13\) # (!\clock_div|clock_div_process:count_var[7]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[7]~q\,
	datad => VCC,
	cin => \clock_div|Add0~13\,
	combout => \clock_div|Add0~14_combout\,
	cout => \clock_div|Add0~15\);

-- Location: FF_X75_Y40_N25
\clock_div|clock_div_process:count_var[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[7]~q\);

-- Location: LCCOMB_X75_Y40_N26
\clock_div|Add0~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~16_combout\ = (\clock_div|clock_div_process:count_var[8]~q\ & (\clock_div|Add0~15\ $ (GND))) # (!\clock_div|clock_div_process:count_var[8]~q\ & (!\clock_div|Add0~15\ & VCC))
-- \clock_div|Add0~17\ = CARRY((\clock_div|clock_div_process:count_var[8]~q\ & !\clock_div|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[8]~q\,
	datad => VCC,
	cin => \clock_div|Add0~15\,
	combout => \clock_div|Add0~16_combout\,
	cout => \clock_div|Add0~17\);

-- Location: LCCOMB_X75_Y40_N0
\clock_div|count_var~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~0_combout\ = (\clock_div|Add0~16_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~16_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~0_combout\);

-- Location: FF_X75_Y40_N1
\clock_div|clock_div_process:count_var[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[8]~q\);

-- Location: LCCOMB_X75_Y40_N28
\clock_div|Add0~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~18_combout\ = (\clock_div|clock_div_process:count_var[9]~q\ & (!\clock_div|Add0~17\)) # (!\clock_div|clock_div_process:count_var[9]~q\ & ((\clock_div|Add0~17\) # (GND)))
-- \clock_div|Add0~19\ = CARRY((!\clock_div|Add0~17\) # (!\clock_div|clock_div_process:count_var[9]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[9]~q\,
	datad => VCC,
	cin => \clock_div|Add0~17\,
	combout => \clock_div|Add0~18_combout\,
	cout => \clock_div|Add0~19\);

-- Location: LCCOMB_X75_Y40_N8
\clock_div|count_var~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~2_combout\ = (\clock_div|Add0~18_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~18_combout\,
	combout => \clock_div|count_var~2_combout\);

-- Location: FF_X75_Y40_N9
\clock_div|clock_div_process:count_var[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[9]~q\);

-- Location: LCCOMB_X75_Y40_N30
\clock_div|Add0~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~20_combout\ = (\clock_div|clock_div_process:count_var[10]~q\ & (\clock_div|Add0~19\ $ (GND))) # (!\clock_div|clock_div_process:count_var[10]~q\ & (!\clock_div|Add0~19\ & VCC))
-- \clock_div|Add0~21\ = CARRY((\clock_div|clock_div_process:count_var[10]~q\ & !\clock_div|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[10]~q\,
	datad => VCC,
	cin => \clock_div|Add0~19\,
	combout => \clock_div|Add0~20_combout\,
	cout => \clock_div|Add0~21\);

-- Location: FF_X75_Y40_N31
\clock_div|clock_div_process:count_var[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[10]~q\);

-- Location: LCCOMB_X75_Y39_N0
\clock_div|Add0~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~22_combout\ = (\clock_div|clock_div_process:count_var[11]~q\ & (!\clock_div|Add0~21\)) # (!\clock_div|clock_div_process:count_var[11]~q\ & ((\clock_div|Add0~21\) # (GND)))
-- \clock_div|Add0~23\ = CARRY((!\clock_div|Add0~21\) # (!\clock_div|clock_div_process:count_var[11]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[11]~q\,
	datad => VCC,
	cin => \clock_div|Add0~21\,
	combout => \clock_div|Add0~22_combout\,
	cout => \clock_div|Add0~23\);

-- Location: LCCOMB_X75_Y39_N28
\clock_div|count_var~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~3_combout\ = (\clock_div|Add0~22_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~22_combout\,
	combout => \clock_div|count_var~3_combout\);

-- Location: FF_X75_Y39_N29
\clock_div|clock_div_process:count_var[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[11]~q\);

-- Location: LCCOMB_X75_Y39_N2
\clock_div|Add0~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~24_combout\ = (\clock_div|clock_div_process:count_var[12]~q\ & (\clock_div|Add0~23\ $ (GND))) # (!\clock_div|clock_div_process:count_var[12]~q\ & (!\clock_div|Add0~23\ & VCC))
-- \clock_div|Add0~25\ = CARRY((\clock_div|clock_div_process:count_var[12]~q\ & !\clock_div|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[12]~q\,
	datad => VCC,
	cin => \clock_div|Add0~23\,
	combout => \clock_div|Add0~24_combout\,
	cout => \clock_div|Add0~25\);

-- Location: FF_X75_Y39_N3
\clock_div|clock_div_process:count_var[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~24_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[12]~q\);

-- Location: LCCOMB_X75_Y39_N4
\clock_div|Add0~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~26_combout\ = (\clock_div|clock_div_process:count_var[13]~q\ & (!\clock_div|Add0~25\)) # (!\clock_div|clock_div_process:count_var[13]~q\ & ((\clock_div|Add0~25\) # (GND)))
-- \clock_div|Add0~27\ = CARRY((!\clock_div|Add0~25\) # (!\clock_div|clock_div_process:count_var[13]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[13]~q\,
	datad => VCC,
	cin => \clock_div|Add0~25\,
	combout => \clock_div|Add0~26_combout\,
	cout => \clock_div|Add0~27\);

-- Location: FF_X75_Y39_N5
\clock_div|clock_div_process:count_var[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~26_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[13]~q\);

-- Location: LCCOMB_X75_Y39_N6
\clock_div|Add0~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~28_combout\ = (\clock_div|clock_div_process:count_var[14]~q\ & (\clock_div|Add0~27\ $ (GND))) # (!\clock_div|clock_div_process:count_var[14]~q\ & (!\clock_div|Add0~27\ & VCC))
-- \clock_div|Add0~29\ = CARRY((\clock_div|clock_div_process:count_var[14]~q\ & !\clock_div|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[14]~q\,
	datad => VCC,
	cin => \clock_div|Add0~27\,
	combout => \clock_div|Add0~28_combout\,
	cout => \clock_div|Add0~29\);

-- Location: LCCOMB_X75_Y39_N30
\clock_div|count_var~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~4_combout\ = (\clock_div|Add0~28_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~28_combout\,
	combout => \clock_div|count_var~4_combout\);

-- Location: FF_X75_Y39_N31
\clock_div|clock_div_process:count_var[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[14]~q\);

-- Location: LCCOMB_X75_Y39_N8
\clock_div|Add0~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~30_combout\ = (\clock_div|clock_div_process:count_var[15]~q\ & (!\clock_div|Add0~29\)) # (!\clock_div|clock_div_process:count_var[15]~q\ & ((\clock_div|Add0~29\) # (GND)))
-- \clock_div|Add0~31\ = CARRY((!\clock_div|Add0~29\) # (!\clock_div|clock_div_process:count_var[15]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[15]~q\,
	datad => VCC,
	cin => \clock_div|Add0~29\,
	combout => \clock_div|Add0~30_combout\,
	cout => \clock_div|Add0~31\);

-- Location: FF_X75_Y39_N9
\clock_div|clock_div_process:count_var[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~30_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[15]~q\);

-- Location: LCCOMB_X76_Y39_N30
\clock_div|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~3_combout\ = (!\clock_div|clock_div_process:count_var[12]~q\ & (\clock_div|clock_div_process:count_var[14]~q\ & (!\clock_div|clock_div_process:count_var[13]~q\ & !\clock_div|clock_div_process:count_var[15]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[12]~q\,
	datab => \clock_div|clock_div_process:count_var[14]~q\,
	datac => \clock_div|clock_div_process:count_var[13]~q\,
	datad => \clock_div|clock_div_process:count_var[15]~q\,
	combout => \clock_div|Equal0~3_combout\);

-- Location: LCCOMB_X75_Y40_N6
\clock_div|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~1_combout\ = (\clock_div|clock_div_process:count_var[1]~q\ & (\clock_div|clock_div_process:count_var[3]~q\ & (\clock_div|clock_div_process:count_var[2]~q\ & \clock_div|clock_div_process:count_var[4]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[1]~q\,
	datab => \clock_div|clock_div_process:count_var[3]~q\,
	datac => \clock_div|clock_div_process:count_var[2]~q\,
	datad => \clock_div|clock_div_process:count_var[4]~q\,
	combout => \clock_div|Equal0~1_combout\);

-- Location: LCCOMB_X76_Y39_N4
\clock_div|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~2_combout\ = (!\clock_div|clock_div_process:count_var[10]~q\ & (\clock_div|clock_div_process:count_var[11]~q\ & (\clock_div|clock_div_process:count_var[9]~q\ & \clock_div|clock_div_process:count_var[0]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[10]~q\,
	datab => \clock_div|clock_div_process:count_var[11]~q\,
	datac => \clock_div|clock_div_process:count_var[9]~q\,
	datad => \clock_div|clock_div_process:count_var[0]~q\,
	combout => \clock_div|Equal0~2_combout\);

-- Location: LCCOMB_X75_Y40_N4
\clock_div|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~0_combout\ = (\clock_div|clock_div_process:count_var[5]~q\ & (!\clock_div|clock_div_process:count_var[7]~q\ & (!\clock_div|clock_div_process:count_var[6]~q\ & \clock_div|clock_div_process:count_var[8]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[5]~q\,
	datab => \clock_div|clock_div_process:count_var[7]~q\,
	datac => \clock_div|clock_div_process:count_var[6]~q\,
	datad => \clock_div|clock_div_process:count_var[8]~q\,
	combout => \clock_div|Equal0~0_combout\);

-- Location: LCCOMB_X76_Y39_N0
\clock_div|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~4_combout\ = (\clock_div|Equal0~3_combout\ & (\clock_div|Equal0~1_combout\ & (\clock_div|Equal0~2_combout\ & \clock_div|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~3_combout\,
	datab => \clock_div|Equal0~1_combout\,
	datac => \clock_div|Equal0~2_combout\,
	datad => \clock_div|Equal0~0_combout\,
	combout => \clock_div|Equal0~4_combout\);

-- Location: LCCOMB_X75_Y39_N10
\clock_div|Add0~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~32_combout\ = (\clock_div|clock_div_process:count_var[16]~q\ & (\clock_div|Add0~31\ $ (GND))) # (!\clock_div|clock_div_process:count_var[16]~q\ & (!\clock_div|Add0~31\ & VCC))
-- \clock_div|Add0~33\ = CARRY((\clock_div|clock_div_process:count_var[16]~q\ & !\clock_div|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[16]~q\,
	datad => VCC,
	cin => \clock_div|Add0~31\,
	combout => \clock_div|Add0~32_combout\,
	cout => \clock_div|Add0~33\);

-- Location: FF_X75_Y39_N11
\clock_div|clock_div_process:count_var[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[16]~q\);

-- Location: LCCOMB_X75_Y39_N12
\clock_div|Add0~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~34_combout\ = (\clock_div|clock_div_process:count_var[17]~q\ & (!\clock_div|Add0~33\)) # (!\clock_div|clock_div_process:count_var[17]~q\ & ((\clock_div|Add0~33\) # (GND)))
-- \clock_div|Add0~35\ = CARRY((!\clock_div|Add0~33\) # (!\clock_div|clock_div_process:count_var[17]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[17]~q\,
	datad => VCC,
	cin => \clock_div|Add0~33\,
	combout => \clock_div|Add0~34_combout\,
	cout => \clock_div|Add0~35\);

-- Location: FF_X75_Y39_N13
\clock_div|clock_div_process:count_var[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~34_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[17]~q\);

-- Location: LCCOMB_X75_Y39_N14
\clock_div|Add0~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~36_combout\ = (\clock_div|clock_div_process:count_var[18]~q\ & (\clock_div|Add0~35\ $ (GND))) # (!\clock_div|clock_div_process:count_var[18]~q\ & (!\clock_div|Add0~35\ & VCC))
-- \clock_div|Add0~37\ = CARRY((\clock_div|clock_div_process:count_var[18]~q\ & !\clock_div|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[18]~q\,
	datad => VCC,
	cin => \clock_div|Add0~35\,
	combout => \clock_div|Add0~36_combout\,
	cout => \clock_div|Add0~37\);

-- Location: LCCOMB_X75_Y39_N24
\clock_div|count_var~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~5_combout\ = (\clock_div|Add0~36_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~36_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~5_combout\);

-- Location: FF_X75_Y39_N25
\clock_div|clock_div_process:count_var[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[18]~q\);

-- Location: LCCOMB_X75_Y39_N16
\clock_div|Add0~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~38_combout\ = (\clock_div|clock_div_process:count_var[19]~q\ & (!\clock_div|Add0~37\)) # (!\clock_div|clock_div_process:count_var[19]~q\ & ((\clock_div|Add0~37\) # (GND)))
-- \clock_div|Add0~39\ = CARRY((!\clock_div|Add0~37\) # (!\clock_div|clock_div_process:count_var[19]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[19]~q\,
	datad => VCC,
	cin => \clock_div|Add0~37\,
	combout => \clock_div|Add0~38_combout\,
	cout => \clock_div|Add0~39\);

-- Location: LCCOMB_X76_Y39_N2
\clock_div|count_var~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~6_combout\ = (\clock_div|Add0~38_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Add0~38_combout\,
	datad => \clock_div|Equal0~4_combout\,
	combout => \clock_div|count_var~6_combout\);

-- Location: FF_X76_Y39_N3
\clock_div|clock_div_process:count_var[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[19]~q\);

-- Location: LCCOMB_X75_Y39_N18
\clock_div|Add0~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~40_combout\ = (\clock_div|clock_div_process:count_var[20]~q\ & (\clock_div|Add0~39\ $ (GND))) # (!\clock_div|clock_div_process:count_var[20]~q\ & (!\clock_div|Add0~39\ & VCC))
-- \clock_div|Add0~41\ = CARRY((\clock_div|clock_div_process:count_var[20]~q\ & !\clock_div|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[20]~q\,
	datad => VCC,
	cin => \clock_div|Add0~39\,
	combout => \clock_div|Add0~40_combout\,
	cout => \clock_div|Add0~41\);

-- Location: FF_X75_Y39_N19
\clock_div|clock_div_process:count_var[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~40_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[20]~q\);

-- Location: LCCOMB_X75_Y39_N20
\clock_div|Add0~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~42_combout\ = (\clock_div|clock_div_process:count_var[21]~q\ & (!\clock_div|Add0~41\)) # (!\clock_div|clock_div_process:count_var[21]~q\ & ((\clock_div|Add0~41\) # (GND)))
-- \clock_div|Add0~43\ = CARRY((!\clock_div|Add0~41\) # (!\clock_div|clock_div_process:count_var[21]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[21]~q\,
	datad => VCC,
	cin => \clock_div|Add0~41\,
	combout => \clock_div|Add0~42_combout\,
	cout => \clock_div|Add0~43\);

-- Location: FF_X75_Y39_N21
\clock_div|clock_div_process:count_var[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~42_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[21]~q\);

-- Location: LCCOMB_X75_Y39_N22
\clock_div|Add0~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~44_combout\ = \clock_div|clock_div_process:count_var[22]~q\ $ (!\clock_div|Add0~43\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110100101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[22]~q\,
	cin => \clock_div|Add0~43\,
	combout => \clock_div|Add0~44_combout\);

-- Location: LCCOMB_X75_Y39_N26
\clock_div|count_var~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~7_combout\ = (\clock_div|Add0~44_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~44_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~7_combout\);

-- Location: FF_X75_Y39_N27
\clock_div|clock_div_process:count_var[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[22]~q\);

-- Location: LCCOMB_X76_Y39_N28
\clock_div|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~5_combout\ = (!\clock_div|clock_div_process:count_var[16]~q\ & (\clock_div|clock_div_process:count_var[18]~q\ & (\clock_div|clock_div_process:count_var[19]~q\ & !\clock_div|clock_div_process:count_var[17]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[16]~q\,
	datab => \clock_div|clock_div_process:count_var[18]~q\,
	datac => \clock_div|clock_div_process:count_var[19]~q\,
	datad => \clock_div|clock_div_process:count_var[17]~q\,
	combout => \clock_div|Equal0~5_combout\);

-- Location: LCCOMB_X76_Y39_N6
\clock_div|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~6_combout\ = (!\clock_div|clock_div_process:count_var[21]~q\ & (!\clock_div|clock_div_process:count_var[20]~q\ & (\clock_div|clock_div_process:count_var[22]~q\ & \clock_div|Equal0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[21]~q\,
	datab => \clock_div|clock_div_process:count_var[20]~q\,
	datac => \clock_div|clock_div_process:count_var[22]~q\,
	datad => \clock_div|Equal0~5_combout\,
	combout => \clock_div|Equal0~6_combout\);

-- Location: LCCOMB_X76_Y39_N24
\clock_div|clk~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|clk~0_combout\ = \clock_div|clk~q\ $ (((\clock_div|Equal0~6_combout\ & \clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|clk~q\,
	datad => \clock_div|Equal0~4_combout\,
	combout => \clock_div|clk~0_combout\);

-- Location: LCCOMB_X77_Y39_N28
\clock_div|clk~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|clk~feeder_combout\ = \clock_div|clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \clock_div|clk~0_combout\,
	combout => \clock_div|clk~feeder_combout\);

-- Location: FF_X77_Y39_N29
\clock_div|clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|clk~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clk~q\);

-- Location: CLKCTRL_G9
\clock_div|clk~clkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clock_div|clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clock_div|clk~clkctrl_outclk\);

-- Location: IOIBUF_X56_Y54_N1
\SW[8]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(8),
	o => \SW[8]~input_o\);

-- Location: IOIBUF_X69_Y54_N1
\SW[9]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(9),
	o => \SW[9]~input_o\);

-- Location: LCCOMB_X46_Y34_N8
\datapth|total_Gtimer|reg_Gtim|q[0]~21\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[0]~21_combout\ = !\datapth|total_Gtimer|reg_Gtim|q\(0)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|total_Gtimer|reg_Gtim|q\(0),
	combout => \datapth|total_Gtimer|reg_Gtim|q[0]~21_combout\);

-- Location: FF_X46_Y34_N9
\datapth|total_Gtimer|reg_Gtim|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[0]~21_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(0));

-- Location: IOIBUF_X51_Y54_N29
\m[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_m(0),
	o => \m[0]~input_o\);

-- Location: IOIBUF_X51_Y54_N22
\m[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_m(1),
	o => \m[1]~input_o\);

-- Location: IOIBUF_X49_Y54_N29
\p~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_p,
	o => \p~input_o\);

-- Location: IOIBUF_X51_Y54_N1
\m[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_m(2),
	o => \m[2]~input_o\);

-- Location: LCCOMB_X47_Y47_N10
\controller|comb_proc~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|comb_proc~0_combout\ = (!\m[0]~input_o\ & (!\m[1]~input_o\ & (\p~input_o\ & \m[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m[0]~input_o\,
	datab => \m[1]~input_o\,
	datac => \p~input_o\,
	datad => \m[2]~input_o\,
	combout => \controller|comb_proc~0_combout\);

-- Location: IOIBUF_X46_Y54_N29
\a~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a,
	o => \a~input_o\);

-- Location: LCCOMB_X47_Y36_N12
\controller|Selector8~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector8~0_combout\ = (\a~input_o\ & (\controller|Selector10~0_combout\ & ((\datapth|comparator_level|comp_lev|Equal0~0_combout\)))) # (!\a~input_o\ & ((\controller|PS.S4~q\) # ((\controller|Selector10~0_combout\ & 
-- \datapth|comparator_level|comp_lev|Equal0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \a~input_o\,
	datab => \controller|Selector10~0_combout\,
	datac => \controller|PS.S4~q\,
	datad => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	combout => \controller|Selector8~0_combout\);

-- Location: FF_X47_Y36_N13
\controller|PS.S4\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector8~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S4~q\);

-- Location: LCCOMB_X47_Y36_N2
\controller|Selector1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~0_combout\ = (\a~input_o\ & \controller|PS.S4~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \a~input_o\,
	datad => \controller|PS.S4~q\,
	combout => \controller|Selector1~0_combout\);

-- Location: LCCOMB_X47_Y47_N24
\controller|Selector1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~1_combout\ = ((\m[2]~input_o\) # (\m[0]~input_o\ $ (!\m[1]~input_o\))) # (!\p~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m[0]~input_o\,
	datab => \m[1]~input_o\,
	datac => \p~input_o\,
	datad => \m[2]~input_o\,
	combout => \controller|Selector1~1_combout\);

-- Location: LCCOMB_X47_Y36_N14
\controller|Selector1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~2_combout\ = (!\controller|Selector1~0_combout\ & ((\controller|comb_proc~0_combout\) # ((\controller|PS.S0~q\) # (!\controller|Selector1~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|comb_proc~0_combout\,
	datab => \controller|Selector1~0_combout\,
	datac => \controller|PS.S0~q\,
	datad => \controller|Selector1~1_combout\,
	combout => \controller|Selector1~2_combout\);

-- Location: FF_X47_Y36_N15
\controller|PS.S0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector1~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S0~q\);

-- Location: IOIBUF_X54_Y54_N22
\SW[4]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(4),
	o => \SW[4]~input_o\);

-- Location: IOIBUF_X54_Y54_N15
\SW[6]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(6),
	o => \SW[6]~input_o\);

-- Location: IOIBUF_X49_Y54_N1
\SW[5]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(5),
	o => \SW[5]~input_o\);

-- Location: IOIBUF_X58_Y54_N29
\SW[7]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(7),
	o => \SW[7]~input_o\);

-- Location: LCCOMB_X47_Y38_N18
\datapth|comparator_zero|comp_lev|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_zero|comp_lev|Equal0~1_combout\ = (!\SW[4]~input_o\ & (!\SW[6]~input_o\ & (!\SW[5]~input_o\ & !\SW[7]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[4]~input_o\,
	datab => \SW[6]~input_o\,
	datac => \SW[5]~input_o\,
	datad => \SW[7]~input_o\,
	combout => \datapth|comparator_zero|comp_lev|Equal0~1_combout\);

-- Location: IOIBUF_X54_Y54_N29
\SW[3]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(3),
	o => \SW[3]~input_o\);

-- Location: IOIBUF_X46_Y54_N15
\SW[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(0),
	o => \SW[0]~input_o\);

-- Location: IOIBUF_X49_Y54_N15
\SW[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(1),
	o => \SW[1]~input_o\);

-- Location: IOIBUF_X78_Y33_N1
\SW[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_SW(2),
	o => \SW[2]~input_o\);

-- Location: LCCOMB_X47_Y38_N28
\datapth|comparator_zero|comp_lev|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_zero|comp_lev|Equal0~0_combout\ = (!\SW[3]~input_o\ & (!\SW[0]~input_o\ & (!\SW[1]~input_o\ & !\SW[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[3]~input_o\,
	datab => \SW[0]~input_o\,
	datac => \SW[1]~input_o\,
	datad => \SW[2]~input_o\,
	combout => \datapth|comparator_zero|comp_lev|Equal0~0_combout\);

-- Location: LCCOMB_X47_Y38_N8
\datapth|comparator_zero|comp_lev|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_zero|comp_lev|Equal0~2_combout\ = (!\SW[9]~input_o\ & (\datapth|comparator_zero|comp_lev|Equal0~1_combout\ & (!\SW[8]~input_o\ & \datapth|comparator_zero|comp_lev|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[9]~input_o\,
	datab => \datapth|comparator_zero|comp_lev|Equal0~1_combout\,
	datac => \SW[8]~input_o\,
	datad => \datapth|comparator_zero|comp_lev|Equal0~0_combout\,
	combout => \datapth|comparator_zero|comp_lev|Equal0~2_combout\);

-- Location: LCCOMB_X47_Y36_N26
\controller|Selector10~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector10~1_combout\ = (!\datapth|comparator_level|comp_lev|Equal0~0_combout\ & (\controller|Selector10~0_combout\ & \datapth|comparator_zero|comp_lev|Equal0~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	datac => \controller|Selector10~0_combout\,
	datad => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \controller|Selector10~1_combout\);

-- Location: LCCOMB_X47_Y36_N22
\datapth|total_level|reg_lev|q[1]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_level|reg_lev|q[1]~2_combout\ = \datapth|total_level|reg_lev|q\(1) $ (((\datapth|total_level|reg_lev|q\(0) & \controller|Selector10~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_level|reg_lev|q\(0),
	datac => \datapth|total_level|reg_lev|q\(1),
	datad => \controller|Selector10~1_combout\,
	combout => \datapth|total_level|reg_lev|q[1]~2_combout\);

-- Location: FF_X47_Y36_N23
\datapth|total_level|reg_lev|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_level|reg_lev|q[1]~2_combout\,
	clrn => \controller|PS.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_level|reg_lev|q\(1));

-- Location: LCCOMB_X47_Y36_N8
\datapth|total_level|reg_lev|q[2]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_level|reg_lev|q[2]~1_combout\ = \datapth|total_level|reg_lev|q\(2) $ (((\datapth|total_level|reg_lev|q\(1) & (\datapth|total_level|reg_lev|q\(0) & \controller|Selector10~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_level|reg_lev|q\(1),
	datab => \datapth|total_level|reg_lev|q\(0),
	datac => \datapth|total_level|reg_lev|q\(2),
	datad => \controller|Selector10~1_combout\,
	combout => \datapth|total_level|reg_lev|q[2]~1_combout\);

-- Location: FF_X47_Y36_N9
\datapth|total_level|reg_lev|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_level|reg_lev|q[2]~1_combout\,
	clrn => \controller|PS.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_level|reg_lev|q\(2));

-- Location: LCCOMB_X47_Y36_N20
\controller|Selector2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector2~0_combout\ = (!\datapth|comparator_zero|comp_lev|Equal0~2_combout\ & (((\datapth|total_level|reg_lev|q\(1)) # (!\datapth|total_level|reg_lev|q\(2))) # (!\datapth|total_level|reg_lev|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_level|reg_lev|q\(0),
	datab => \datapth|total_level|reg_lev|q\(2),
	datac => \datapth|total_level|reg_lev|q\(1),
	datad => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \controller|Selector2~0_combout\);

-- Location: LCCOMB_X47_Y47_N4
\controller|comb_proc~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|comb_proc~1_combout\ = (\m[0]~input_o\ & (!\m[1]~input_o\ & (\p~input_o\ & !\m[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m[0]~input_o\,
	datab => \m[1]~input_o\,
	datac => \p~input_o\,
	datad => \m[2]~input_o\,
	combout => \controller|comb_proc~1_combout\);

-- Location: LCCOMB_X47_Y36_N6
\controller|Selector2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector2~1_combout\ = (\controller|PS.S0~q\ & (\controller|Selector2~0_combout\ & ((\controller|PS.S1~q\)))) # (!\controller|PS.S0~q\ & ((\controller|comb_proc~1_combout\) # ((\controller|Selector2~0_combout\ & \controller|PS.S1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S0~q\,
	datab => \controller|Selector2~0_combout\,
	datac => \controller|comb_proc~1_combout\,
	datad => \controller|PS.S1~q\,
	combout => \controller|Selector2~1_combout\);

-- Location: LCCOMB_X47_Y36_N18
\controller|Selector3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector3~0_combout\ = (\controller|PS.S1~q\ & (!\datapth|comparator_level|comp_lev|Equal0~0_combout\ & \datapth|comparator_zero|comp_lev|Equal0~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S1~q\,
	datab => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	datac => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \controller|Selector3~0_combout\);

-- Location: LCCOMB_X46_Y34_N16
\datapth|total_Gtimer|reg_Gtim|q[1]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[1]~7_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(0) & (\datapth|total_Gtimer|reg_Gtim|q\(1) $ (VCC))) # (!\datapth|total_Gtimer|reg_Gtim|q\(0) & (\datapth|total_Gtimer|reg_Gtim|q\(1) & VCC))
-- \datapth|total_Gtimer|reg_Gtim|q[1]~8\ = CARRY((\datapth|total_Gtimer|reg_Gtim|q\(0) & \datapth|total_Gtimer|reg_Gtim|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_Gtimer|reg_Gtim|q\(0),
	datab => \datapth|total_Gtimer|reg_Gtim|q\(1),
	datad => VCC,
	combout => \datapth|total_Gtimer|reg_Gtim|q[1]~7_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[1]~8\);

-- Location: FF_X46_Y34_N17
\datapth|total_Gtimer|reg_Gtim|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[1]~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(1));

-- Location: FF_X46_Y32_N5
\datapth|rand|reg_rand|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(1),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(1));

-- Location: LCCOMB_X51_Y34_N28
\datapth|rand|ShiftLeft4~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~1_combout\ = (\datapth|rand|reg_rand|q\(0) & !\datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft4~1_combout\);

-- Location: LCCOMB_X50_Y34_N10
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ = \datapth|rand|reg_rand|q\(0) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\ = CARRY(\datapth|rand|reg_rand|q\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(0),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\);

-- Location: LCCOMB_X46_Y34_N18
\datapth|total_Gtimer|reg_Gtim|q[2]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[2]~9_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(2) & (!\datapth|total_Gtimer|reg_Gtim|q[1]~8\)) # (!\datapth|total_Gtimer|reg_Gtim|q\(2) & ((\datapth|total_Gtimer|reg_Gtim|q[1]~8\) # (GND)))
-- \datapth|total_Gtimer|reg_Gtim|q[2]~10\ = CARRY((!\datapth|total_Gtimer|reg_Gtim|q[1]~8\) # (!\datapth|total_Gtimer|reg_Gtim|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_Gtimer|reg_Gtim|q\(2),
	datad => VCC,
	cin => \datapth|total_Gtimer|reg_Gtim|q[1]~8\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[2]~9_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[2]~10\);

-- Location: FF_X46_Y34_N19
\datapth|total_Gtimer|reg_Gtim|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[2]~9_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(2));

-- Location: LCCOMB_X46_Y34_N20
\datapth|total_Gtimer|reg_Gtim|q[3]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[3]~11_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(3) & (\datapth|total_Gtimer|reg_Gtim|q[2]~10\ $ (GND))) # (!\datapth|total_Gtimer|reg_Gtim|q\(3) & (!\datapth|total_Gtimer|reg_Gtim|q[2]~10\ & VCC))
-- \datapth|total_Gtimer|reg_Gtim|q[3]~12\ = CARRY((\datapth|total_Gtimer|reg_Gtim|q\(3) & !\datapth|total_Gtimer|reg_Gtim|q[2]~10\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_Gtimer|reg_Gtim|q\(3),
	datad => VCC,
	cin => \datapth|total_Gtimer|reg_Gtim|q[2]~10\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[3]~11_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[3]~12\);

-- Location: FF_X46_Y34_N21
\datapth|total_Gtimer|reg_Gtim|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[3]~11_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(3));

-- Location: LCCOMB_X46_Y34_N22
\datapth|total_Gtimer|reg_Gtim|q[4]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[4]~13_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(4) & (!\datapth|total_Gtimer|reg_Gtim|q[3]~12\)) # (!\datapth|total_Gtimer|reg_Gtim|q\(4) & ((\datapth|total_Gtimer|reg_Gtim|q[3]~12\) # (GND)))
-- \datapth|total_Gtimer|reg_Gtim|q[4]~14\ = CARRY((!\datapth|total_Gtimer|reg_Gtim|q[3]~12\) # (!\datapth|total_Gtimer|reg_Gtim|q\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_Gtimer|reg_Gtim|q\(4),
	datad => VCC,
	cin => \datapth|total_Gtimer|reg_Gtim|q[3]~12\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[4]~13_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[4]~14\);

-- Location: FF_X46_Y34_N23
\datapth|total_Gtimer|reg_Gtim|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[4]~13_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(4));

-- Location: LCCOMB_X46_Y34_N24
\datapth|total_Gtimer|reg_Gtim|q[5]~15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[5]~15_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(5) & (\datapth|total_Gtimer|reg_Gtim|q[4]~14\ $ (GND))) # (!\datapth|total_Gtimer|reg_Gtim|q\(5) & (!\datapth|total_Gtimer|reg_Gtim|q[4]~14\ & VCC))
-- \datapth|total_Gtimer|reg_Gtim|q[5]~16\ = CARRY((\datapth|total_Gtimer|reg_Gtim|q\(5) & !\datapth|total_Gtimer|reg_Gtim|q[4]~14\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_Gtimer|reg_Gtim|q\(5),
	datad => VCC,
	cin => \datapth|total_Gtimer|reg_Gtim|q[4]~14\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[5]~15_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[5]~16\);

-- Location: FF_X46_Y34_N25
\datapth|total_Gtimer|reg_Gtim|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[5]~15_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(5));

-- Location: LCCOMB_X46_Y34_N26
\datapth|total_Gtimer|reg_Gtim|q[6]~17\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[6]~17_combout\ = (\datapth|total_Gtimer|reg_Gtim|q\(6) & (!\datapth|total_Gtimer|reg_Gtim|q[5]~16\)) # (!\datapth|total_Gtimer|reg_Gtim|q\(6) & ((\datapth|total_Gtimer|reg_Gtim|q[5]~16\) # (GND)))
-- \datapth|total_Gtimer|reg_Gtim|q[6]~18\ = CARRY((!\datapth|total_Gtimer|reg_Gtim|q[5]~16\) # (!\datapth|total_Gtimer|reg_Gtim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_Gtimer|reg_Gtim|q\(6),
	datad => VCC,
	cin => \datapth|total_Gtimer|reg_Gtim|q[5]~16\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[6]~17_combout\,
	cout => \datapth|total_Gtimer|reg_Gtim|q[6]~18\);

-- Location: FF_X46_Y34_N27
\datapth|total_Gtimer|reg_Gtim|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[6]~17_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(6));

-- Location: LCCOMB_X46_Y34_N28
\datapth|total_Gtimer|reg_Gtim|q[7]~19\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_Gtimer|reg_Gtim|q[7]~19_combout\ = \datapth|total_Gtimer|reg_Gtim|q[6]~18\ $ (!\datapth|total_Gtimer|reg_Gtim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \datapth|total_Gtimer|reg_Gtim|q\(7),
	cin => \datapth|total_Gtimer|reg_Gtim|q[6]~18\,
	combout => \datapth|total_Gtimer|reg_Gtim|q[7]~19_combout\);

-- Location: FF_X46_Y34_N29
\datapth|total_Gtimer|reg_Gtim|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_Gtimer|reg_Gtim|q[7]~19_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_Gtimer|reg_Gtim|q\(7));

-- Location: FF_X47_Y33_N29
\datapth|rand|reg_rand|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(7),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(7));

-- Location: FF_X47_Y33_N25
\datapth|rand|reg_rand|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(6),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(6));

-- Location: FF_X47_Y33_N23
\datapth|rand|reg_rand|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(5),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(5));

-- Location: LCCOMB_X47_Y33_N14
\datapth|rand|Mod2|auto_generated|divider|divider|op_1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ = \datapth|rand|reg_rand|q\(5) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\ = CARRY(\datapth|rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(5),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\);

-- Location: LCCOMB_X47_Y33_N16
\datapth|rand|Mod2|auto_generated|divider|divider|op_1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\ = (\datapth|rand|reg_rand|q\(6) & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\)) # (!\datapth|rand|reg_rand|q\(6) & 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\) # (GND)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\) # (!\datapth|rand|reg_rand|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(6),
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\);

-- Location: LCCOMB_X47_Y33_N18
\datapth|rand|Mod2|auto_generated|divider|divider|op_1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\ = (\datapth|rand|reg_rand|q\(7) & (\datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\ $ (GND))) # (!\datapth|rand|reg_rand|q\(7) & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\ & VCC))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~5\ = CARRY((\datapth|rand|reg_rand|q\(7) & !\datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(7),
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~5\);

-- Location: LCCOMB_X47_Y33_N20
\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ = !\datapth|rand|Mod2|auto_generated|divider|divider|op_1~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\);

-- Location: LCCOMB_X47_Y33_N26
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\);

-- Location: LCCOMB_X47_Y33_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ = (\datapth|rand|reg_rand|q\(7) & \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(7),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\);

-- Location: LCCOMB_X47_Y33_N12
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\);

-- Location: LCCOMB_X47_Y33_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\ = (\datapth|rand|reg_rand|q\(6) & \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(6),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\);

-- Location: LCCOMB_X47_Y33_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\);

-- Location: LCCOMB_X47_Y33_N28
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ = (\datapth|rand|reg_rand|q\(5) & \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(5),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\);

-- Location: FF_X46_Y33_N17
\datapth|rand|reg_rand|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(4),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(4));

-- Location: LCCOMB_X47_Y33_N2
\datapth|rand|Mod2|auto_generated|divider|divider|op_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\ = \datapth|rand|reg_rand|q\(4) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\ = CARRY(\datapth|rand|reg_rand|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(4),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\);

-- Location: LCCOMB_X47_Y33_N4
\datapth|rand|Mod2|auto_generated|divider|divider|op_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\) # (GND)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\ = CARRY(((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~77_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[16]~76_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\);

-- Location: LCCOMB_X47_Y33_N6
\datapth|rand|Mod2|auto_generated|divider|divider|op_2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~75_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[17]~74_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\);

-- Location: LCCOMB_X47_Y33_N8
\datapth|rand|Mod2|auto_generated|divider|divider|op_2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~7\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~73_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[18]~72_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~7\);

-- Location: LCCOMB_X47_Y33_N10
\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ = \datapth|rand|Mod2|auto_generated|divider|divider|op_2~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~7\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\);

-- Location: LCCOMB_X47_Y33_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\datapth|rand|reg_rand|q\(7)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~4_combout\,
	datac => \datapth|rand|reg_rand|q\(7),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\);

-- Location: LCCOMB_X52_Y33_N28
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\);

-- Location: LCCOMB_X52_Y33_N26
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\);

-- Location: LCCOMB_X52_Y33_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\datapth|rand|reg_rand|q\(6))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(6),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\);

-- Location: LCCOMB_X49_Y33_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\);

-- Location: LCCOMB_X52_Y33_N18
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & (\datapth|rand|reg_rand|q\(5))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(5),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~6_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_1~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\);

-- Location: LCCOMB_X49_Y33_N6
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\);

-- Location: LCCOMB_X52_Y33_N16
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ = (\datapth|rand|reg_rand|q\(4) & \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(4),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\);

-- Location: FF_X46_Y33_N19
\datapth|rand|reg_rand|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(3),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(3));

-- Location: LCCOMB_X52_Y33_N2
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ = \datapth|rand|reg_rand|q\(3) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\ = CARRY(\datapth|rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(3),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\);

-- Location: LCCOMB_X52_Y33_N4
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\) # (GND)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\ = CARRY(((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~82_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[24]~81_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\);

-- Location: LCCOMB_X52_Y33_N6
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~80_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\);

-- Location: LCCOMB_X52_Y33_N8
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~79_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\);

-- Location: LCCOMB_X52_Y33_N10
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~9\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~78_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~7\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~9\);

-- Location: LCCOMB_X52_Y33_N12
\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ = !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~9\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\);

-- Location: LCCOMB_X51_Y33_N2
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~6_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[27]~129_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\);

-- Location: LCCOMB_X52_Y33_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\);

-- Location: LCCOMB_X52_Y33_N20
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\);

-- Location: LCCOMB_X51_Y33_N28
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~4_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[26]~130_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\);

-- Location: LCCOMB_X51_Y33_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~2_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[25]~131_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\);

-- Location: LCCOMB_X52_Y33_N14
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\);

-- Location: LCCOMB_X51_Y33_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & (\datapth|rand|reg_rand|q\(4))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(4),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~8_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_2~0_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\);

-- Location: LCCOMB_X52_Y33_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\);

-- Location: LCCOMB_X52_Y33_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\);

-- Location: LCCOMB_X51_Y33_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|reg_rand|q\(3),
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\);

-- Location: FF_X47_Y32_N9
\datapth|rand|reg_rand|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(2),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(2));

-- Location: LCCOMB_X51_Y33_N8
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\ = \datapth|rand|reg_rand|q\(2) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\ = CARRY(\datapth|rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\);

-- Location: LCCOMB_X51_Y33_N10
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\) # (GND)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\ = CARRY(((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~88_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[32]~87_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\);

-- Location: LCCOMB_X51_Y33_N12
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~86_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\);

-- Location: LCCOMB_X51_Y33_N14
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~85_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\);

-- Location: LCCOMB_X51_Y33_N16
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~84_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~7\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\);

-- Location: LCCOMB_X51_Y33_N18
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~11\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~83_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~9\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~11\);

-- Location: LCCOMB_X51_Y33_N20
\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ = \datapth|rand|Mod2|auto_generated|divider|divider|op_4~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~11\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\);

-- Location: LCCOMB_X50_Y33_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[36]~117_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\);

-- Location: LCCOMB_X50_Y33_N28
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X51_Y33_N6
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X51_Y33_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[35]~118_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~6_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\);

-- Location: LCCOMB_X51_Y33_N4
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X50_Y33_N4
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~4_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[34]~119_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\);

-- Location: LCCOMB_X49_Y33_N16
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~2_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[33]~132_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\);

-- Location: LCCOMB_X51_Y33_N26
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\);

-- Location: LCCOMB_X51_Y32_N2
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & (\datapth|rand|reg_rand|q\(3))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(3),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~10_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_3~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\);

-- Location: LCCOMB_X49_Y33_N20
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\);

-- Location: LCCOMB_X51_Y34_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ = (\datapth|rand|reg_rand|q\(2) & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(2),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\);

-- Location: LCCOMB_X51_Y34_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\);

-- Location: LCCOMB_X50_Y33_N6
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ = \datapth|rand|reg_rand|q\(1) $ (VCC)
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\ = CARRY(\datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(1),
	datad => VCC,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\);

-- Location: LCCOMB_X50_Y33_N8
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\) # (GND)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\ = CARRY(((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\);

-- Location: LCCOMB_X50_Y33_N10
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\);

-- Location: LCCOMB_X50_Y33_N12
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\);

-- Location: LCCOMB_X50_Y33_N14
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~7\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~8_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\);

-- Location: LCCOMB_X50_Y33_N16
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~10_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~9\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~10_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\);

-- Location: LCCOMB_X50_Y33_N18
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~13\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~11\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~13\);

-- Location: LCCOMB_X50_Y33_N20
\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ = !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~13\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\);

-- Location: LCCOMB_X50_Y33_N2
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\);

-- Location: LCCOMB_X50_Y33_N26
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~10_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\);

-- Location: LCCOMB_X50_Y34_N6
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~8_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[44]~121_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\);

-- Location: LCCOMB_X50_Y33_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_5~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\);

-- Location: LCCOMB_X50_Y33_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~8_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~8_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\);

-- Location: LCCOMB_X51_Y34_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[43]~122_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~6_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\);

-- Location: LCCOMB_X49_Y33_N10
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\) # 
-- ((!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~4_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\);

-- Location: LCCOMB_X49_Y34_N6
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\);

-- Location: LCCOMB_X51_Y34_N20
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X51_Y32_N28
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~2_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\);

-- Location: LCCOMB_X51_Y34_N2
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\);

-- Location: LCCOMB_X51_Y34_N12
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & (\datapth|rand|reg_rand|q\(2))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~0_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\);

-- Location: LCCOMB_X49_Y34_N16
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\);

-- Location: LCCOMB_X51_Y34_N16
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\);

-- Location: LCCOMB_X50_Y34_N12
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\)))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\) # (GND)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\ = CARRY(((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~103_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[48]~102_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~1\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\);

-- Location: LCCOMB_X50_Y34_N14
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\)))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~101_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[49]~134_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~3\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\);

-- Location: LCCOMB_X50_Y34_N16
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[50]~128_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~5\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\);

-- Location: LCCOMB_X50_Y34_N18
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~7\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\);

-- Location: LCCOMB_X50_Y34_N20
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~10_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~9\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~10_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\);

-- Location: LCCOMB_X50_Y34_N22
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~12_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\ & ((((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\))))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\) # (GND))))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\ = CARRY((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\) # ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~11\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~12_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\);

-- Location: LCCOMB_X50_Y34_N24
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\) # 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\)))
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~15\ = CARRY((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~13\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\,
	cout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~15\);

-- Location: LCCOMB_X50_Y34_N26
\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ = \datapth|rand|Mod2|auto_generated|divider|divider|op_6~15\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~15\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\);

-- Location: LCCOMB_X49_Y34_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|reg_rand|q\(0)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	datab => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\);

-- Location: LCCOMB_X46_Y33_N22
\datapth|rand|Mod1|auto_generated|divider|divider|op_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\ = \datapth|rand|reg_rand|q\(4) $ (VCC)
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\ = CARRY(\datapth|rand|reg_rand|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(4),
	datad => VCC,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\);

-- Location: LCCOMB_X46_Y33_N24
\datapth|rand|Mod1|auto_generated|divider|divider|op_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\ = (\datapth|rand|reg_rand|q\(5) & (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\ & VCC)) # (!\datapth|rand|reg_rand|q\(5) & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\ = CARRY((!\datapth|rand|reg_rand|q\(5) & !\datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(5),
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~1\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\);

-- Location: LCCOMB_X46_Y33_N26
\datapth|rand|Mod1|auto_generated|divider|divider|op_2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\ = (\datapth|rand|reg_rand|q\(6) & ((GND) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\))) # (!\datapth|rand|reg_rand|q\(6) & 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\ $ (GND)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\ = CARRY((\datapth|rand|reg_rand|q\(6)) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(6),
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~3\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\);

-- Location: LCCOMB_X46_Y33_N28
\datapth|rand|Mod1|auto_generated|divider|divider|op_2~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\ = (\datapth|rand|reg_rand|q\(7) & (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\)) # (!\datapth|rand|reg_rand|q\(7) & 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\) # (GND)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~7\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\) # (!\datapth|rand|reg_rand|q\(7)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(7),
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~5\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~7\);

-- Location: LCCOMB_X46_Y33_N30
\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|op_2~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~7\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\);

-- Location: LCCOMB_X46_Y33_N20
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \datapth|rand|reg_rand|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \datapth|rand|reg_rand|q\(7),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\);

-- Location: LCCOMB_X46_Y33_N18
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\);

-- Location: LCCOMB_X46_Y33_N12
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\);

-- Location: LCCOMB_X46_Y33_N14
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ = (\datapth|rand|reg_rand|q\(6) & \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(6),
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\);

-- Location: LCCOMB_X45_Y33_N0
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \datapth|rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \datapth|rand|reg_rand|q\(5),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\);

-- Location: LCCOMB_X45_Y33_N6
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\);

-- Location: LCCOMB_X45_Y33_N12
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\);

-- Location: LCCOMB_X46_Y33_N16
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ = (\datapth|rand|reg_rand|q\(4) & \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(4),
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\);

-- Location: LCCOMB_X46_Y33_N0
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\ = \datapth|rand|reg_rand|q\(3) $ (VCC)
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\ = CARRY(\datapth|rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(3),
	datad => VCC,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\);

-- Location: LCCOMB_X46_Y33_N2
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~73_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[24]~72_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~1\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\);

-- Location: LCCOMB_X46_Y33_N4
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~70_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[25]~71_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~3\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\);

-- Location: LCCOMB_X46_Y33_N6
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & (((!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\) # (GND)))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\ = CARRY(((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~69_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[26]~68_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~5\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\);

-- Location: LCCOMB_X46_Y33_N8
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~9\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[27]~67_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~7\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~9\);

-- Location: LCCOMB_X46_Y33_N10
\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ = !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~9\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\);

-- Location: LCCOMB_X44_Y33_N2
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|reg_rand|q\(7)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~6_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datac => \datapth|rand|reg_rand|q\(7),
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\);

-- Location: LCCOMB_X44_Y33_N28
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\);

-- Location: LCCOMB_X45_Y33_N4
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\datapth|rand|reg_rand|q\(6))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datab => \datapth|rand|reg_rand|q\(6),
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~4_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\);

-- Location: LCCOMB_X45_Y33_N18
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\);

-- Location: LCCOMB_X45_Y33_N2
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\datapth|rand|reg_rand|q\(5))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datab => \datapth|rand|reg_rand|q\(5),
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~2_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\);

-- Location: LCCOMB_X45_Y33_N8
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\);

-- Location: LCCOMB_X44_Y33_N10
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\);

-- Location: LCCOMB_X45_Y33_N24
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & (\datapth|rand|reg_rand|q\(4))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~8_combout\,
	datab => \datapth|rand|reg_rand|q\(4),
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_2~0_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\);

-- Location: LCCOMB_X45_Y33_N10
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\);

-- Location: LCCOMB_X44_Y33_N0
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ = (\datapth|rand|reg_rand|q\(3) & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(3),
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\);

-- Location: LCCOMB_X44_Y33_N14
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\ = \datapth|rand|reg_rand|q\(2) $ (VCC)
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\ = CARRY(\datapth|rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datad => VCC,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\);

-- Location: LCCOMB_X44_Y33_N16
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~79_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[32]~78_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~1\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\);

-- Location: LCCOMB_X44_Y33_N18
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~77_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~3\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\);

-- Location: LCCOMB_X44_Y33_N20
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ & (((!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\) # (GND)))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\ = CARRY(((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~76_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~5\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\);

-- Location: LCCOMB_X44_Y33_N22
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~75_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~7\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\);

-- Location: LCCOMB_X44_Y33_N24
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~11\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~74_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~9\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~11\);

-- Location: LCCOMB_X44_Y33_N26
\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|op_4~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~11\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\);

-- Location: LCCOMB_X44_Y33_N4
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~8_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[36]~112_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\);

-- Location: LCCOMB_X45_Y32_N28
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\);

-- Location: LCCOMB_X44_Y33_N6
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\);

-- Location: LCCOMB_X45_Y33_N28
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[35]~113_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~6_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\);

-- Location: LCCOMB_X45_Y33_N26
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~4_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[34]~114_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\);

-- Location: LCCOMB_X44_Y33_N12
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\);

-- Location: LCCOMB_X44_Y33_N8
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~2_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[33]~115_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\);

-- Location: LCCOMB_X44_Y33_N30
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\);

-- Location: LCCOMB_X45_Y33_N30
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & ((\datapth|rand|reg_rand|q\(3)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_3~10_combout\,
	datad => \datapth|rand|reg_rand|q\(3),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\);

-- Location: LCCOMB_X44_Y32_N20
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\);

-- Location: LCCOMB_X45_Y32_N26
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\);

-- Location: LCCOMB_X44_Y32_N18
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|reg_rand|q\(2),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\);

-- Location: LCCOMB_X45_Y32_N6
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~0_combout\ = \datapth|rand|reg_rand|q\(1) $ (VCC)
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\ = CARRY(\datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(1),
	datad => VCC,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~0_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\);

-- Location: LCCOMB_X45_Y32_N8
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~86_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[40]~85_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~1\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~2_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\);

-- Location: LCCOMB_X45_Y32_N10
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~84_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~3\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~4_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\);

-- Location: LCCOMB_X45_Y32_N12
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~6_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & (((!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\) # (GND)))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\ = CARRY(((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~83_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~5\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~6_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\);

-- Location: LCCOMB_X45_Y32_N14
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~82_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~7\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~8_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\);

-- Location: LCCOMB_X45_Y32_N16
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~10_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~81_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~9\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~10_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\);

-- Location: LCCOMB_X45_Y32_N18
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~12_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~13\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~80_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~11\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~12_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~13\);

-- Location: LCCOMB_X45_Y32_N20
\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ = !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~13\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\);

-- Location: LCCOMB_X45_Y33_N22
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~2_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[41]~116_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\);

-- Location: LCCOMB_X44_Y32_N24
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~4_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~4_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\);

-- Location: LCCOMB_X44_Y32_N14
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & ((\datapth|rand|reg_rand|q\(2)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|reg_rand|q\(2),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\);

-- Location: LCCOMB_X45_Y32_N4
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~2_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~2_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\);

-- Location: LCCOMB_X44_Y32_N28
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_5~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~0_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\);

-- Location: LCCOMB_X44_Y32_N6
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\);

-- Location: LCCOMB_X46_Y32_N10
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~0_combout\ = \datapth|rand|reg_rand|q\(0) $ (VCC)
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\ = CARRY(\datapth|rand|reg_rand|q\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(0),
	datad => VCC,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~0_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\);

-- Location: LCCOMB_X46_Y32_N12
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~1\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~2_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\);

-- Location: LCCOMB_X46_Y32_N14
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~4_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~3\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~4_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\);

-- Location: LCCOMB_X46_Y32_N16
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~6_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ & (((!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\) # (GND)))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\ = CARRY(((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\)) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~5\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~6_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\);

-- Location: LCCOMB_X45_Y32_N2
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[45]~103_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~10_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\);

-- Location: LCCOMB_X45_Y32_N24
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_5~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~12_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\);

-- Location: LCCOMB_X45_Y32_N22
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_5~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\);

-- Location: LCCOMB_X45_Y33_N16
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~8_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[44]~104_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\);

-- Location: LCCOMB_X45_Y32_N0
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~8_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~8_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\);

-- Location: LCCOMB_X45_Y33_N14
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[43]~105_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~6_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\);

-- Location: LCCOMB_X45_Y33_N20
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\) # 
-- ((!\datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\ & \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~12_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_4~4_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[42]~106_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\);

-- Location: LCCOMB_X45_Y32_N30
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_5~6_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~6_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\);

-- Location: LCCOMB_X46_Y32_N18
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~8_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~7\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~8_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\);

-- Location: LCCOMB_X46_Y32_N20
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~10_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~9\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~10_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\);

-- Location: LCCOMB_X46_Y32_N22
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~12_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\ & ((((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # (GND))))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\ = CARRY((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~11\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~12_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\);

-- Location: LCCOMB_X46_Y32_N24
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~14_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\) # 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~15\ = CARRY((!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~13\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~14_combout\,
	cout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~15\);

-- Location: LCCOMB_X46_Y32_N26
\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|op_6~15\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~15\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\);

-- Location: LCCOMB_X44_Y32_N12
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~111_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[50]~91_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~6_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\);

-- Location: LCCOMB_X46_Y32_N0
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~117_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[49]~92_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~4_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\);

-- Location: LCCOMB_X46_Y32_N30
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~89_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[52]~109_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~10_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\);

-- Location: LCCOMB_X46_Y32_N28
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~88_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~12_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[53]~108_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\);

-- Location: LCCOMB_X46_Y32_N6
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~107_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[54]~87_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~14_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\);

-- Location: LCCOMB_X46_Y32_N8
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~110_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[51]~90_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~8_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\);

-- Location: LCCOMB_X50_Y31_N0
\datapth|rand|Equal1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal1~0_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\ & !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\,
	combout => \datapth|rand|Equal1~0_combout\);

-- Location: LCCOMB_X44_Y32_N2
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\) # 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~93_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[48]~94_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~2_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\);

-- Location: LCCOMB_X49_Y34_N8
\datapth|rand|ShiftLeft1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft1~0_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|Equal1~0_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datac => \datapth|rand|Equal1~0_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	combout => \datapth|rand|ShiftLeft1~0_combout\);

-- Location: LCCOMB_X51_Y34_N6
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~95_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[40]~94_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~2_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\);

-- Location: LCCOMB_X51_Y34_N8
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010111110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\);

-- Location: LCCOMB_X49_Y34_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|reg_rand|q\(1)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~0_combout\,
	datac => \datapth|rand|reg_rand|q\(1),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\);

-- Location: LCCOMB_X49_Y34_N20
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\)) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\);

-- Location: LCCOMB_X50_Y32_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~133_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~4_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[41]~93_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\);

-- Location: LCCOMB_X50_Y32_N22
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\);

-- Location: LCCOMB_X50_Y34_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~125_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[53]~97_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~12_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\);

-- Location: LCCOMB_X50_Y34_N0
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~96_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[54]~124_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104_combout\);

-- Location: LCCOMB_X50_Y34_N8
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~98_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[52]~126_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~10_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\);

-- Location: LCCOMB_X50_Y34_N2
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~127_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[51]~99_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107_combout\);

-- Location: LCCOMB_X50_Y34_N28
\datapth|rand|Equal2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal2~0_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\ & !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~104_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~107_combout\,
	combout => \datapth|rand|Equal2~0_combout\);

-- Location: LCCOMB_X49_Y34_N10
\datapth|rand|ShiftLeft2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft2~0_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & \datapth|rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datad => \datapth|rand|Equal2~0_combout\,
	combout => \datapth|rand|ShiftLeft2~0_combout\);

-- Location: LCCOMB_X49_Y34_N4
\datapth|rand|S_3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~1_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|ShiftLeft1~0_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & 
-- \datapth|rand|ShiftLeft2~0_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & ((\datapth|rand|ShiftLeft2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datac => \datapth|rand|ShiftLeft1~0_combout\,
	datad => \datapth|rand|ShiftLeft2~0_combout\,
	combout => \datapth|rand|S_3~1_combout\);

-- Location: LCCOMB_X46_Y35_N10
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \datapth|rand|reg_rand|q\(5) $ (VCC)
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\datapth|rand|reg_rand|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(5),
	datad => VCC,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X46_Y35_N12
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\datapth|rand|reg_rand|q\(6) & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\datapth|rand|reg_rand|q\(6) & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\datapth|rand|reg_rand|q\(6) & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(6),
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X46_Y35_N14
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\datapth|rand|reg_rand|q\(7) & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # (!\datapth|rand|reg_rand|q\(7) & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\datapth|rand|reg_rand|q\(7) & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(7),
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X46_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X46_Y35_N2
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\);

-- Location: LCCOMB_X46_Y35_N8
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ = (\datapth|rand|reg_rand|q\(7) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(7),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\);

-- Location: LCCOMB_X46_Y35_N18
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\);

-- Location: LCCOMB_X46_Y35_N0
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\ = (\datapth|rand|reg_rand|q\(6) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(6),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\);

-- Location: LCCOMB_X46_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\);

-- Location: LCCOMB_X46_Y35_N4
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ = (\datapth|rand|reg_rand|q\(5) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(5),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\);

-- Location: LCCOMB_X45_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\ = (\datapth|rand|reg_rand|q\(4) & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(4),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\);

-- Location: LCCOMB_X46_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\ = (\datapth|rand|reg_rand|q\(4) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(4),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\);

-- Location: LCCOMB_X46_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~61_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[24]~60_combout\,
	datad => VCC,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X46_Y35_N24
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~59_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[25]~58_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X46_Y35_N26
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\)))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~57_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[26]~56_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X46_Y35_N28
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~55_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[27]~54_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\);

-- Location: LCCOMB_X46_Y35_N30
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~7\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X47_Y35_N12
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\);

-- Location: LCCOMB_X47_Y35_N14
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\datapth|rand|reg_rand|q\(7)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datab => \datapth|rand|reg_rand|q\(7),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\);

-- Location: LCCOMB_X47_Y35_N26
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\);

-- Location: LCCOMB_X47_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\datapth|rand|reg_rand|q\(6)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datab => \datapth|rand|reg_rand|q\(6),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\);

-- Location: LCCOMB_X47_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\datapth|rand|reg_rand|q\(5)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datab => \datapth|rand|reg_rand|q\(5),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\);

-- Location: LCCOMB_X47_Y35_N28
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\);

-- Location: LCCOMB_X47_Y35_N30
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\);

-- Location: LCCOMB_X45_Y35_N10
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ = (\datapth|rand|reg_rand|q\(4) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(4),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\);

-- Location: LCCOMB_X45_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|reg_rand|q\(3),
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\);

-- Location: LCCOMB_X45_Y35_N24
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|reg_rand|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|reg_rand|q\(3),
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X47_Y35_N0
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~68_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datad => VCC,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X47_Y35_N2
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~66_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[33]~65_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X47_Y35_N4
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\)))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~64_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X47_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~63_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\);

-- Location: LCCOMB_X47_Y35_N8
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\))))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # (GND))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~62_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~7\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\);

-- Location: LCCOMB_X47_Y35_N10
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ = !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~9\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\);

-- Location: LCCOMB_X47_Y35_N18
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X50_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\);

-- Location: LCCOMB_X47_Y35_N24
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X49_Y35_N28
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\);

-- Location: LCCOMB_X49_Y35_N0
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- ((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X49_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\);

-- Location: LCCOMB_X47_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\);

-- Location: LCCOMB_X49_Y35_N4
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|rand|reg_rand|q\(4)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	datab => \datapth|rand|reg_rand|q\(4),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\);

-- Location: LCCOMB_X49_Y35_N14
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\);

-- Location: LCCOMB_X49_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ = (\datapth|rand|reg_rand|q\(3) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(3),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\);

-- Location: LCCOMB_X49_Y35_N12
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\ = (\datapth|rand|reg_rand|q\(2) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(2),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\);

-- Location: LCCOMB_X49_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\ = (\datapth|rand|reg_rand|q\(2) & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(2),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\);

-- Location: LCCOMB_X50_Y35_N4
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~75_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[40]~76_combout\,
	datad => VCC,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X50_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~74_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[41]~73_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X50_Y35_N8
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\)))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~72_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X50_Y35_N10
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~71_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X50_Y35_N12
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\))))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\) # (GND))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~70_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X50_Y35_N14
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~69_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X50_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X52_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\ = (\datapth|rand|reg_rand|q\(2) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\);

-- Location: LCCOMB_X50_Y35_N2
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\);

-- Location: LCCOMB_X51_Y35_N26
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[45]~89_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\);

-- Location: LCCOMB_X52_Y35_N2
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\);

-- Location: LCCOMB_X50_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\);

-- Location: LCCOMB_X49_Y35_N18
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- ((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\);

-- Location: LCCOMB_X50_Y35_N28
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\);

-- Location: LCCOMB_X50_Y35_N0
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\);

-- Location: LCCOMB_X50_Y35_N18
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\);

-- Location: LCCOMB_X51_Y35_N30
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\);

-- Location: LCCOMB_X50_Y35_N30
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ 
-- & ((\datapth|rand|reg_rand|q\(3)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datab => \datapth|rand|reg_rand|q\(3),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X51_Y35_N0
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\);

-- Location: LCCOMB_X52_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\ = (\datapth|rand|reg_rand|q\(1) & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(1),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\);

-- Location: LCCOMB_X51_Y35_N4
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\ = (\datapth|rand|reg_rand|q\(1) & !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\);

-- Location: LCCOMB_X51_Y35_N8
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ = (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~77_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[48]~78_combout\,
	datad => VCC,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\);

-- Location: LCCOMB_X51_Y35_N10
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~1\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\);

-- Location: LCCOMB_X51_Y35_N12
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\)))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~3\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\);

-- Location: LCCOMB_X51_Y35_N14
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~82_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~5\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\);

-- Location: LCCOMB_X51_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\))))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\) # (GND))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~7\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\);

-- Location: LCCOMB_X51_Y35_N18
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ & (((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ & 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\)))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ = CARRY((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~9\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\);

-- Location: LCCOMB_X51_Y35_N20
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ & ((((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\))))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # (GND))))
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ = CARRY((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\,
	datad => VCC,
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~11\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\,
	cout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\);

-- Location: LCCOMB_X51_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ = !\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~13\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\);

-- Location: LCCOMB_X52_Y35_N22
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & 
-- (((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~84_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\);

-- Location: LCCOMB_X51_Y35_N6
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\)))) # (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & 
-- (((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\);

-- Location: LCCOMB_X50_Y35_N24
\datapth|rand|ShiftLeft0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~2_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~80_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~81_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~79_combout\,
	combout => \datapth|rand|ShiftLeft0~2_combout\);

-- Location: LCCOMB_X50_Y35_N26
\datapth|rand|ShiftLeft0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~3_combout\ = (\datapth|rand|ShiftLeft0~2_combout\) # ((!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \datapth|rand|ShiftLeft0~2_combout\,
	combout => \datapth|rand|ShiftLeft0~3_combout\);

-- Location: LCCOMB_X51_Y35_N2
\datapth|rand|ShiftLeft0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~1_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\) # 
-- (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[54]~92_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[52]~94_combout\,
	combout => \datapth|rand|ShiftLeft0~1_combout\);

-- Location: LCCOMB_X51_Y35_N28
\datapth|rand|ShiftLeft0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~0_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\) # 
-- ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\) # (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~12_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~6_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~10_combout\,
	combout => \datapth|rand|ShiftLeft0~0_combout\);

-- Location: LCCOMB_X51_Y35_N24
\datapth|rand|ShiftLeft0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~4_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|rand|ShiftLeft0~3_combout\) # ((\datapth|rand|ShiftLeft0~1_combout\)))) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\datapth|rand|ShiftLeft0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111111100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~3_combout\,
	datab => \datapth|rand|ShiftLeft0~1_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datad => \datapth|rand|ShiftLeft0~0_combout\,
	combout => \datapth|rand|ShiftLeft0~4_combout\);

-- Location: LCCOMB_X52_Y35_N30
\datapth|rand|ShiftLeft0~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~7_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\ & !\datapth|rand|ShiftLeft0~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \datapth|rand|ShiftLeft0~4_combout\,
	combout => \datapth|rand|ShiftLeft0~7_combout\);

-- Location: LCCOMB_X52_Y35_N16
\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (\datapth|rand|reg_rand|q\(1))) # 
-- (!\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\);

-- Location: LCCOMB_X52_Y35_N4
\datapth|rand|ShiftLeft0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~8_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|ShiftLeft0~7_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|ShiftLeft0~7_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~8_combout\);

-- Location: LCCOMB_X49_Y34_N26
\datapth|rand|S_2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_2~1_combout\ = \datapth|rand|ShiftLeft0~8_combout\ $ (((!\datapth|rand|reg_rand|q\(2) & (!\datapth|rand|reg_rand|q\(1) & \datapth|rand|reg_rand|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|ShiftLeft0~8_combout\,
	datad => \datapth|rand|reg_rand|q\(0),
	combout => \datapth|rand|S_2~1_combout\);

-- Location: LCCOMB_X52_Y32_N0
\datapth|rand|Mux9~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~2_combout\ = (!\controller|PS.P2~q\ & ((\controller|PS.P1~q\) # (\controller|PS.P3~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datac => \controller|PS.P1~q\,
	datad => \controller|PS.P3~q\,
	combout => \datapth|rand|Mux9~2_combout\);

-- Location: LCCOMB_X51_Y34_N18
\datapth|rand|Mux9~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~0_combout\ = (!\controller|PS.P2~q\ & !\controller|PS.P1~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.P2~q\,
	datad => \controller|PS.P1~q\,
	combout => \datapth|rand|Mux9~0_combout\);

-- Location: LCCOMB_X51_Y34_N26
\datapth|rand|Mux8~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux8~0_combout\ = ((!\datapth|rand|reg_rand|q\(2) & (\datapth|rand|reg_rand|q\(0) & !\datapth|rand|reg_rand|q\(1)))) # (!\datapth|rand|Mux9~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001101110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|Mux9~0_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mux8~0_combout\);

-- Location: LCCOMB_X49_Y32_N4
\datapth|rand|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~0_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\ & 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\ $ (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\)))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\ $ (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[62]~96_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[61]~97_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[62]~105_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[61]~106_combout\,
	combout => \datapth|rand|Equal0~0_combout\);

-- Location: LCCOMB_X49_Y33_N30
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011011000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~92_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[42]~123_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116_combout\);

-- Location: LCCOMB_X49_Y32_N8
\datapth|rand|Equal0~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~7_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116_combout\))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110001100110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~8_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[60]~98_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[60]~116_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal0~7_combout\);

-- Location: LCCOMB_X50_Y33_N24
\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\) # 
-- ((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\)))) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~120_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~12_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_5~14_combout\,
	combout => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115_combout\);

-- Location: LCCOMB_X50_Y34_N4
\datapth|rand|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~6_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115_combout\)) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110101111000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[63]~115_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[63]~95_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~14_combout\,
	combout => \datapth|rand|Equal0~6_combout\);

-- Location: LCCOMB_X49_Y32_N22
\datapth|rand|Mux9~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~3_combout\ = (\controller|PS.P2~q\ & (((\datapth|rand|Equal0~7_combout\) # (\datapth|rand|Equal0~6_combout\)))) # (!\controller|PS.P2~q\ & (\controller|PS.P3~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|PS.P3~q\,
	datac => \datapth|rand|Equal0~7_combout\,
	datad => \datapth|rand|Equal0~6_combout\,
	combout => \datapth|rand|Mux9~3_combout\);

-- Location: LCCOMB_X49_Y32_N26
\datapth|rand|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~1_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\)) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~112_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~6_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal0~1_combout\);

-- Location: LCCOMB_X49_Y32_N24
\datapth|rand|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~4_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\)) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011001011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal0~4_combout\);

-- Location: LCCOMB_X49_Y34_N24
\datapth|rand|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~2_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\)) # (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~110_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~4_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal0~2_combout\);

-- Location: LCCOMB_X51_Y32_N20
\datapth|rand|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~3_combout\ = \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|reg_rand|q\(0))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & ((\datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101000111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(0),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal0~3_combout\);

-- Location: LCCOMB_X49_Y32_N10
\datapth|rand|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~5_combout\ = (!\datapth|rand|Equal0~1_combout\ & (!\datapth|rand|Equal0~4_combout\ & (!\datapth|rand|Equal0~2_combout\ & !\datapth|rand|Equal0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Equal0~1_combout\,
	datab => \datapth|rand|Equal0~4_combout\,
	datac => \datapth|rand|Equal0~2_combout\,
	datad => \datapth|rand|Equal0~3_combout\,
	combout => \datapth|rand|Equal0~5_combout\);

-- Location: LCCOMB_X49_Y32_N0
\datapth|rand|Mux9~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~4_combout\ = (\datapth|rand|Mux9~3_combout\) # ((\controller|PS.P2~q\ & ((!\datapth|rand|Equal0~5_combout\) # (!\datapth|rand|Equal0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \datapth|rand|Equal0~0_combout\,
	datac => \datapth|rand|Mux9~3_combout\,
	datad => \datapth|rand|Equal0~5_combout\,
	combout => \datapth|rand|Mux9~4_combout\);

-- Location: LCCOMB_X49_Y34_N2
\datapth|rand|Mux8~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux8~1_combout\ = (\datapth|rand|Mux9~2_combout\ & ((\datapth|rand|Mux9~4_combout\ & (\datapth|rand|Mux8~0_combout\)) # (!\datapth|rand|Mux9~4_combout\ & ((\datapth|rand|ShiftLeft0~8_combout\))))) # (!\datapth|rand|Mux9~2_combout\ & 
-- (((!\datapth|rand|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~2_combout\,
	datab => \datapth|rand|Mux8~0_combout\,
	datac => \datapth|rand|ShiftLeft0~8_combout\,
	datad => \datapth|rand|Mux9~4_combout\,
	combout => \datapth|rand|Mux8~1_combout\);

-- Location: LCCOMB_X49_Y34_N12
\datapth|rand|Mux8~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux8~2_combout\ = (\controller|PS.P2~q\ & ((\datapth|rand|Mux8~1_combout\ & (\datapth|rand|S_2~1_combout\)) # (!\datapth|rand|Mux8~1_combout\ & ((\datapth|rand|S_3~1_combout\))))) # (!\controller|PS.P2~q\ & 
-- (((\datapth|rand|Mux8~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|S_2~1_combout\,
	datab => \controller|PS.P2~q\,
	datac => \datapth|rand|S_3~1_combout\,
	datad => \datapth|rand|Mux8~1_combout\,
	combout => \datapth|rand|Mux8~2_combout\);

-- Location: LCCOMB_X49_Y34_N14
\datapth|rand|Mux8~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux8~3_combout\ = (\datapth|rand|Mux9~8_combout\ & (\datapth|rand|ShiftLeft4~1_combout\ $ ((\datapth|rand|S_3~1_combout\)))) # (!\datapth|rand|Mux9~8_combout\ & (((\datapth|rand|Mux8~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110111101100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~1_combout\,
	datab => \datapth|rand|S_3~1_combout\,
	datac => \datapth|rand|Mux9~8_combout\,
	datad => \datapth|rand|Mux8~2_combout\,
	combout => \datapth|rand|Mux8~3_combout\);

-- Location: LCCOMB_X47_Y32_N18
\datapth|comparator_rand|comp_rand|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~0_combout\ = (\SW[0]~input_o\ & (\datapth|rand|Mux9~9_combout\ & (\SW[1]~input_o\ $ (!\datapth|rand|Mux8~3_combout\)))) # (!\SW[0]~input_o\ & (!\datapth|rand|Mux9~9_combout\ & (\SW[1]~input_o\ $ 
-- (!\datapth|rand|Mux8~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[0]~input_o\,
	datab => \SW[1]~input_o\,
	datac => \datapth|rand|Mux9~9_combout\,
	datad => \datapth|rand|Mux8~3_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~0_combout\);

-- Location: LCCOMB_X51_Y32_N8
\datapth|rand|ShiftLeft3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft3~0_combout\ = (\datapth|rand|reg_rand|q\(1) & !\datapth|rand|reg_rand|q\(0))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(1),
	datad => \datapth|rand|reg_rand|q\(0),
	combout => \datapth|rand|ShiftLeft3~0_combout\);

-- Location: LCCOMB_X51_Y32_N14
\datapth|rand|ShiftLeft1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft1~1_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & 
-- (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ & \datapth|rand|Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	datad => \datapth|rand|Equal1~0_combout\,
	combout => \datapth|rand|ShiftLeft1~1_combout\);

-- Location: LCCOMB_X51_Y32_N0
\datapth|rand|ShiftLeft2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft2~1_combout\ = (\datapth|rand|Equal2~0_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ & 
-- !\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Equal2~0_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	combout => \datapth|rand|ShiftLeft2~1_combout\);

-- Location: LCCOMB_X51_Y32_N30
\datapth|rand|S_3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & ((\datapth|rand|ShiftLeft2~1_combout\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|ShiftLeft1~1_combout\ $ (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \datapth|rand|ShiftLeft2~1_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \datapth|rand|ShiftLeft1~1_combout\,
	datad => \datapth|rand|ShiftLeft2~1_combout\,
	combout => \datapth|rand|S_3~2_combout\);

-- Location: LCCOMB_X52_Y35_N24
\datapth|rand|ShiftLeft0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~5_combout\ = (!\datapth|rand|reg_rand|q\(0) & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\ & !\datapth|rand|ShiftLeft0~4_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datad => \datapth|rand|ShiftLeft0~4_combout\,
	combout => \datapth|rand|ShiftLeft0~5_combout\);

-- Location: LCCOMB_X52_Y35_N18
\datapth|rand|ShiftLeft0~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~9_combout\ = ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\) # (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)) # (!\datapth|rand|ShiftLeft0~5_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|ShiftLeft0~5_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~9_combout\);

-- Location: LCCOMB_X52_Y35_N8
\datapth|rand|S_2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_2~2_combout\ = \datapth|rand|ShiftLeft0~9_combout\ $ (((\datapth|rand|reg_rand|q\(2)) # ((\datapth|rand|reg_rand|q\(0)) # (!\datapth|rand|reg_rand|q\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010011111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|ShiftLeft0~9_combout\,
	combout => \datapth|rand|S_2~2_combout\);

-- Location: LCCOMB_X51_Y34_N14
\datapth|rand|Mux7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux7~0_combout\ = (\datapth|rand|reg_rand|q\(2)) # (((\datapth|rand|reg_rand|q\(0)) # (!\datapth|rand|reg_rand|q\(1))) # (!\datapth|rand|Mux9~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|Mux9~0_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mux7~0_combout\);

-- Location: LCCOMB_X51_Y32_N24
\datapth|rand|Mux7~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux7~1_combout\ = (\datapth|rand|Mux9~2_combout\ & ((\datapth|rand|Mux9~4_combout\ & ((!\datapth|rand|Mux7~0_combout\))) # (!\datapth|rand|Mux9~4_combout\ & (!\datapth|rand|ShiftLeft0~9_combout\)))) # (!\datapth|rand|Mux9~2_combout\ & 
-- (((\datapth|rand|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~9_combout\,
	datab => \datapth|rand|Mux7~0_combout\,
	datac => \datapth|rand|Mux9~2_combout\,
	datad => \datapth|rand|Mux9~4_combout\,
	combout => \datapth|rand|Mux7~1_combout\);

-- Location: LCCOMB_X51_Y32_N6
\datapth|rand|Mux7~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux7~2_combout\ = (\controller|PS.P2~q\ & ((\datapth|rand|Mux7~1_combout\ & ((\datapth|rand|S_3~2_combout\))) # (!\datapth|rand|Mux7~1_combout\ & (\datapth|rand|S_2~2_combout\)))) # (!\controller|PS.P2~q\ & 
-- (((\datapth|rand|Mux7~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \datapth|rand|S_2~2_combout\,
	datac => \datapth|rand|S_3~2_combout\,
	datad => \datapth|rand|Mux7~1_combout\,
	combout => \datapth|rand|Mux7~2_combout\);

-- Location: LCCOMB_X51_Y32_N22
\datapth|rand|Mux7~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux7~3_combout\ = (\datapth|rand|Mux9~8_combout\ & (\datapth|rand|ShiftLeft3~0_combout\ $ ((\datapth|rand|S_3~2_combout\)))) # (!\datapth|rand|Mux9~8_combout\ & (((\datapth|rand|Mux7~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111110100101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~8_combout\,
	datab => \datapth|rand|ShiftLeft3~0_combout\,
	datac => \datapth|rand|S_3~2_combout\,
	datad => \datapth|rand|Mux7~2_combout\,
	combout => \datapth|rand|Mux7~3_combout\);

-- Location: LCCOMB_X44_Y32_N30
\datapth|rand|ShiftLeft3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft3~1_combout\ = (\datapth|rand|reg_rand|q\(0) & \datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft3~1_combout\);

-- Location: LCCOMB_X50_Y31_N26
\datapth|rand|ShiftLeft1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft1~2_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ & 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & \datapth|rand|Equal1~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datad => \datapth|rand|Equal1~0_combout\,
	combout => \datapth|rand|ShiftLeft1~2_combout\);

-- Location: LCCOMB_X50_Y32_N28
\datapth|rand|ShiftLeft2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft2~2_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & \datapth|rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datad => \datapth|rand|Equal2~0_combout\,
	combout => \datapth|rand|ShiftLeft2~2_combout\);

-- Location: LCCOMB_X49_Y32_N14
\datapth|rand|S_3~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~3_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \datapth|rand|ShiftLeft2~2_combout\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|ShiftLeft1~2_combout\ $ (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & \datapth|rand|ShiftLeft2~2_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100101101000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datab => \datapth|rand|ShiftLeft1~2_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datad => \datapth|rand|ShiftLeft2~2_combout\,
	combout => \datapth|rand|S_3~3_combout\);

-- Location: LCCOMB_X52_Y35_N10
\datapth|rand|ShiftLeft0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~10_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|ShiftLeft0~7_combout\ & 
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|ShiftLeft0~7_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~10_combout\);

-- Location: LCCOMB_X52_Y35_N12
\datapth|rand|S_2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_2~3_combout\ = \datapth|rand|ShiftLeft0~10_combout\ $ (((!\datapth|rand|reg_rand|q\(2) & (\datapth|rand|reg_rand|q\(1) & \datapth|rand|reg_rand|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111101000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|ShiftLeft0~10_combout\,
	combout => \datapth|rand|S_2~3_combout\);

-- Location: LCCOMB_X51_Y34_N4
\datapth|rand|Mux6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux6~0_combout\ = ((!\datapth|rand|reg_rand|q\(2) & (\datapth|rand|reg_rand|q\(0) & \datapth|rand|reg_rand|q\(1)))) # (!\datapth|rand|Mux9~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111001100110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|Mux9~0_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mux6~0_combout\);

-- Location: LCCOMB_X49_Y32_N16
\datapth|rand|Mux6~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux6~1_combout\ = (\datapth|rand|Mux9~2_combout\ & ((\datapth|rand|Mux9~4_combout\ & (\datapth|rand|Mux6~0_combout\)) # (!\datapth|rand|Mux9~4_combout\ & ((\datapth|rand|ShiftLeft0~10_combout\))))) # (!\datapth|rand|Mux9~2_combout\ & 
-- (((!\datapth|rand|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~2_combout\,
	datab => \datapth|rand|Mux6~0_combout\,
	datac => \datapth|rand|ShiftLeft0~10_combout\,
	datad => \datapth|rand|Mux9~4_combout\,
	combout => \datapth|rand|Mux6~1_combout\);

-- Location: LCCOMB_X49_Y32_N30
\datapth|rand|Mux6~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux6~2_combout\ = (\controller|PS.P2~q\ & ((\datapth|rand|Mux6~1_combout\ & (\datapth|rand|S_2~3_combout\)) # (!\datapth|rand|Mux6~1_combout\ & ((\datapth|rand|S_3~3_combout\))))) # (!\controller|PS.P2~q\ & 
-- (((\datapth|rand|Mux6~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110110100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \datapth|rand|S_2~3_combout\,
	datac => \datapth|rand|S_3~3_combout\,
	datad => \datapth|rand|Mux6~1_combout\,
	combout => \datapth|rand|Mux6~2_combout\);

-- Location: LCCOMB_X49_Y32_N12
\datapth|rand|Mux6~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux6~3_combout\ = (\datapth|rand|Mux9~8_combout\ & (\datapth|rand|ShiftLeft3~1_combout\ $ ((\datapth|rand|S_3~3_combout\)))) # (!\datapth|rand|Mux9~8_combout\ & (((\datapth|rand|Mux6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft3~1_combout\,
	datab => \datapth|rand|S_3~3_combout\,
	datac => \datapth|rand|Mux6~2_combout\,
	datad => \datapth|rand|Mux9~8_combout\,
	combout => \datapth|rand|Mux6~3_combout\);

-- Location: LCCOMB_X47_Y32_N20
\datapth|comparator_rand|comp_rand|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~1_combout\ = (\SW[3]~input_o\ & (\datapth|rand|Mux6~3_combout\ & (\SW[2]~input_o\ $ (!\datapth|rand|Mux7~3_combout\)))) # (!\SW[3]~input_o\ & (!\datapth|rand|Mux6~3_combout\ & (\SW[2]~input_o\ $ 
-- (!\datapth|rand|Mux7~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[3]~input_o\,
	datab => \SW[2]~input_o\,
	datac => \datapth|rand|Mux7~3_combout\,
	datad => \datapth|rand|Mux6~3_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~1_combout\);

-- Location: LCCOMB_X47_Y32_N8
\datapth|comparator_rand|comp_rand|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~2_combout\ = (\datapth|comparator_rand|comp_rand|Equal0~0_combout\ & \datapth|comparator_rand|comp_rand|Equal0~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|comparator_rand|comp_rand|Equal0~0_combout\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~1_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~2_combout\);

-- Location: LCCOMB_X47_Y32_N24
\controller|Selector3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector3~1_combout\ = (\controller|Selector3~0_combout\) # ((\controller|PS.P1~q\ & ((!\datapth|comparator_rand|comp_rand|Equal0~2_combout\) # (!\datapth|comparator_rand|comp_rand|Equal0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	datab => \controller|Selector3~0_combout\,
	datac => \controller|PS.P1~q\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	combout => \controller|Selector3~1_combout\);

-- Location: FF_X47_Y32_N25
\controller|PS.P1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector3~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.P1~q\);

-- Location: LCCOMB_X47_Y32_N0
\controller|Selector2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector2~2_combout\ = (\controller|Selector2~1_combout\) # ((\controller|PS.P1~q\ & (\datapth|comparator_rand|comp_rand|Equal0~2_combout\ & \datapth|comparator_rand|comp_rand|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|Selector2~1_combout\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	combout => \controller|Selector2~2_combout\);

-- Location: FF_X47_Y32_N1
\controller|PS.S1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector2~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S1~q\);

-- Location: LCCOMB_X47_Y47_N6
\controller|comb_proc~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|comb_proc~2_combout\ = (!\m[0]~input_o\ & (\m[1]~input_o\ & (\p~input_o\ & !\m[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m[0]~input_o\,
	datab => \m[1]~input_o\,
	datac => \p~input_o\,
	datad => \m[2]~input_o\,
	combout => \controller|comb_proc~2_combout\);

-- Location: LCCOMB_X47_Y36_N24
\controller|Selector4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector4~0_combout\ = (\controller|comb_proc~2_combout\ & (((\controller|PS.S2~q\ & \controller|Selector2~0_combout\)) # (!\controller|PS.S0~q\))) # (!\controller|comb_proc~2_combout\ & (\controller|PS.S2~q\ & 
-- ((\controller|Selector2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|comb_proc~2_combout\,
	datab => \controller|PS.S2~q\,
	datac => \controller|PS.S0~q\,
	datad => \controller|Selector2~0_combout\,
	combout => \controller|Selector4~0_combout\);

-- Location: LCCOMB_X47_Y32_N14
\controller|Selector4~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector4~1_combout\ = (\controller|Selector4~0_combout\) # ((\controller|PS.P2~q\ & (\datapth|comparator_rand|comp_rand|Equal0~2_combout\ & \datapth|comparator_rand|comp_rand|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|Selector4~0_combout\,
	datac => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	combout => \controller|Selector4~1_combout\);

-- Location: FF_X47_Y32_N15
\controller|PS.S2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector4~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S2~q\);

-- Location: LCCOMB_X47_Y36_N10
\controller|Selector6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector6~0_combout\ = (\controller|comb_proc~0_combout\ & (((\controller|PS.S3~q\ & \controller|Selector2~0_combout\)) # (!\controller|PS.S0~q\))) # (!\controller|comb_proc~0_combout\ & (((\controller|PS.S3~q\ & 
-- \controller|Selector2~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|comb_proc~0_combout\,
	datab => \controller|PS.S0~q\,
	datac => \controller|PS.S3~q\,
	datad => \controller|Selector2~0_combout\,
	combout => \controller|Selector6~0_combout\);

-- Location: LCCOMB_X47_Y32_N28
\controller|Selector6~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector6~1_combout\ = (\controller|Selector6~0_combout\) # ((\controller|PS.P3~q\ & (\datapth|comparator_rand|comp_rand|Equal0~2_combout\ & \datapth|comparator_rand|comp_rand|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110110011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P3~q\,
	datab => \controller|Selector6~0_combout\,
	datac => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	combout => \controller|Selector6~1_combout\);

-- Location: FF_X47_Y32_N29
\controller|PS.S3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector6~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S3~q\);

-- Location: LCCOMB_X47_Y36_N28
\controller|Selector10~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector10~0_combout\ = (\controller|PS.S1~q\) # ((\controller|PS.S2~q\) # (\controller|PS.S3~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S1~q\,
	datab => \controller|PS.S2~q\,
	datac => \controller|PS.S3~q\,
	combout => \controller|Selector10~0_combout\);

-- Location: LCCOMB_X47_Y36_N30
\datapth|total_level|reg_lev|q[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_level|reg_lev|q[0]~0_combout\ = \datapth|total_level|reg_lev|q\(0) $ (((\controller|Selector10~0_combout\ & (!\datapth|comparator_level|comp_lev|Equal0~0_combout\ & \datapth|comparator_zero|comp_lev|Equal0~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101001011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|Selector10~0_combout\,
	datab => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	datac => \datapth|total_level|reg_lev|q\(0),
	datad => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \datapth|total_level|reg_lev|q[0]~0_combout\);

-- Location: FF_X47_Y36_N31
\datapth|total_level|reg_lev|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_level|reg_lev|q[0]~0_combout\,
	clrn => \controller|PS.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_level|reg_lev|q\(0));

-- Location: LCCOMB_X47_Y36_N0
\datapth|comparator_level|comp_lev|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_level|comp_lev|Equal0~0_combout\ = (\datapth|total_level|reg_lev|q\(0) & (\datapth|total_level|reg_lev|q\(2) & !\datapth|total_level|reg_lev|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_level|reg_lev|q\(0),
	datab => \datapth|total_level|reg_lev|q\(2),
	datac => \datapth|total_level|reg_lev|q\(1),
	combout => \datapth|comparator_level|comp_lev|Equal0~0_combout\);

-- Location: LCCOMB_X47_Y36_N4
\controller|Selector5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector5~0_combout\ = (!\datapth|comparator_level|comp_lev|Equal0~0_combout\ & (\controller|PS.S2~q\ & \datapth|comparator_zero|comp_lev|Equal0~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	datac => \controller|PS.S2~q\,
	datad => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \controller|Selector5~0_combout\);

-- Location: LCCOMB_X47_Y32_N30
\controller|Selector5~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector5~1_combout\ = (\controller|Selector5~0_combout\) # ((\controller|PS.P2~q\ & ((!\datapth|comparator_rand|comp_rand|Equal0~2_combout\) # (!\datapth|comparator_rand|comp_rand|Equal0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	datab => \controller|Selector5~0_combout\,
	datac => \controller|PS.P2~q\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	combout => \controller|Selector5~1_combout\);

-- Location: FF_X47_Y32_N31
\controller|PS.P2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector5~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.P2~q\);

-- Location: LCCOMB_X47_Y34_N18
\controller|WideOr1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|WideOr1~combout\ = (\controller|PS.P2~q\) # ((\controller|PS.P3~q\) # (\controller|PS.P1~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datac => \controller|PS.P3~q\,
	datad => \controller|PS.P1~q\,
	combout => \controller|WideOr1~combout\);

-- Location: LCCOMB_X47_Y32_N2
\controller|Selector0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector0~0_combout\ = ((\controller|WideOr1~combout\ & (\datapth|comparator_rand|comp_rand|Equal0~2_combout\ & \datapth|comparator_rand|comp_rand|Equal0~6_combout\))) # (!\controller|PS.S0~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|WideOr1~combout\,
	datab => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	datac => \controller|PS.S0~q\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	combout => \controller|Selector0~0_combout\);

-- Location: FF_X46_Y32_N11
\datapth|rand|reg_rand|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	asdata => \datapth|total_Gtimer|reg_Gtim|q\(0),
	clrn => \controller|ALT_INV_Selector0~0_combout\,
	sload => VCC,
	ena => \controller|Selector10~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|rand|reg_rand|q\(0));

-- Location: LCCOMB_X46_Y32_N4
\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|reg_rand|q\(0))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\ & 
-- ((\datapth|rand|Mod1|auto_generated|divider|divider|op_6~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(0),
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~0_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\);

-- Location: LCCOMB_X50_Y31_N30
\datapth|rand|ShiftLeft1~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft1~4_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|Equal1~0_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datab => \datapth|rand|Equal1~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	combout => \datapth|rand|ShiftLeft1~4_combout\);

-- Location: LCCOMB_X49_Y34_N28
\datapth|rand|ShiftLeft2~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft2~4_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ & 
-- (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & \datapth|rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datad => \datapth|rand|Equal2~0_combout\,
	combout => \datapth|rand|ShiftLeft2~4_combout\);

-- Location: LCCOMB_X52_Y32_N12
\datapth|rand|S_3~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~8_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & ((\datapth|rand|ShiftLeft2~4_combout\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|ShiftLeft1~4_combout\ $ (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & \datapth|rand|ShiftLeft2~4_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datac => \datapth|rand|ShiftLeft1~4_combout\,
	datad => \datapth|rand|ShiftLeft2~4_combout\,
	combout => \datapth|rand|S_3~8_combout\);

-- Location: LCCOMB_X49_Y33_N8
\datapth|rand|Equal2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal2~1_combout\ = (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ & (\datapth|rand|reg_rand|q\(1) $ (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\)))) # 
-- (!\datapth|rand|reg_rand|q\(0) & (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\ & (\datapth|rand|reg_rand|q\(1) $ (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(0),
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~0_combout\,
	datac => \datapth|rand|reg_rand|q\(1),
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~2_combout\,
	combout => \datapth|rand|Equal2~1_combout\);

-- Location: LCCOMB_X49_Y33_N14
\datapth|rand|Equal2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal2~2_combout\ = (\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\ $ ((!\datapth|rand|reg_rand|q\(1))))) # 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\ & (((\datapth|rand|Equal2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001100111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~108_combout\,
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|Equal2~1_combout\,
	datad => \datapth|rand|Mod2|auto_generated|divider|divider|op_6~16_combout\,
	combout => \datapth|rand|Equal2~2_combout\);

-- Location: LCCOMB_X50_Y32_N8
\datapth|rand|Equal2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal2~3_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & (\datapth|rand|Equal2~2_combout\ & 
-- \datapth|rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \datapth|rand|Equal2~2_combout\,
	datad => \datapth|rand|Equal2~0_combout\,
	combout => \datapth|rand|Equal2~3_combout\);

-- Location: LCCOMB_X52_Y32_N8
\datapth|rand|Mux0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~2_combout\ = (\controller|PS.P2~q\ & (((\datapth|rand|Mux9~7_combout\ & !\datapth|rand|Equal2~3_combout\)) # (!\controller|PS.P3~q\))) # (!\controller|PS.P2~q\ & (((\datapth|rand|Mux9~7_combout\ & !\datapth|rand|Equal2~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|PS.P3~q\,
	datac => \datapth|rand|Mux9~7_combout\,
	datad => \datapth|rand|Equal2~3_combout\,
	combout => \datapth|rand|Mux0~2_combout\);

-- Location: LCCOMB_X49_Y32_N18
\datapth|rand|Equal0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal0~8_combout\ = (!\datapth|rand|Equal0~7_combout\ & (!\datapth|rand|Equal0~6_combout\ & (\datapth|rand|Equal0~0_combout\ & \datapth|rand|Equal0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Equal0~7_combout\,
	datab => \datapth|rand|Equal0~6_combout\,
	datac => \datapth|rand|Equal0~0_combout\,
	datad => \datapth|rand|Equal0~5_combout\,
	combout => \datapth|rand|Equal0~8_combout\);

-- Location: LCCOMB_X52_Y32_N14
\datapth|rand|Mux0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~3_combout\ = (!\controller|PS.P1~q\ & !\datapth|rand|Equal0~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.P1~q\,
	datad => \datapth|rand|Equal0~8_combout\,
	combout => \datapth|rand|Mux0~3_combout\);

-- Location: LCCOMB_X52_Y32_N22
\datapth|rand|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~0_combout\ = (!\datapth|rand|ShiftLeft0~4_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~4_combout\,
	datac => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\,
	combout => \datapth|rand|Mux0~0_combout\);

-- Location: LCCOMB_X52_Y32_N4
\datapth|rand|Mux0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~1_combout\ = (\datapth|rand|Mux0~0_combout\ & ((\controller|PS.P2~q\ & ((\datapth|rand|Equal0~8_combout\))) # (!\controller|PS.P2~q\ & (\controller|PS.P1~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|rand|Mux0~0_combout\,
	datad => \datapth|rand|Equal0~8_combout\,
	combout => \datapth|rand|Mux0~1_combout\);

-- Location: LCCOMB_X52_Y32_N10
\datapth|rand|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux1~0_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\ & (\datapth|rand|Mux0~1_combout\ & !\datapth|rand|reg_rand|q\(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	datac => \datapth|rand|Mux0~1_combout\,
	datad => \datapth|rand|reg_rand|q\(0),
	combout => \datapth|rand|Mux1~0_combout\);

-- Location: LCCOMB_X52_Y32_N24
\datapth|rand|Mux1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux1~1_combout\ = (\datapth|rand|Mux0~2_combout\ & ((\datapth|rand|Mux0~3_combout\ & (\datapth|rand|S_3~8_combout\)) # (!\datapth|rand|Mux0~3_combout\ & ((\datapth|rand|Mux1~0_combout\))))) # (!\datapth|rand|Mux0~2_combout\ & 
-- (((\datapth|rand|Mux1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|S_3~8_combout\,
	datab => \datapth|rand|Mux0~2_combout\,
	datac => \datapth|rand|Mux0~3_combout\,
	datad => \datapth|rand|Mux1~0_combout\,
	combout => \datapth|rand|Mux1~1_combout\);

-- Location: LCCOMB_X49_Y34_N22
\datapth|rand|S_3~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~9_combout\ = (\datapth|rand|ShiftLeft1~4_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & 
-- \datapth|rand|ShiftLeft2~4_combout\))))) # (!\datapth|rand|ShiftLeft1~4_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & ((\datapth|rand|ShiftLeft2~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft1~4_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datad => \datapth|rand|ShiftLeft2~4_combout\,
	combout => \datapth|rand|S_3~9_combout\);

-- Location: LCCOMB_X52_Y32_N2
\datapth|rand|ShiftLeft0~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~14_combout\ = (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|rand|reg_rand|q\(0) & !\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~14_combout\);

-- Location: LCCOMB_X52_Y32_N20
\datapth|rand|Mux0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~4_combout\ = (\controller|PS.P3~q\) # ((\controller|PS.P2~q\ & ((!\datapth|rand|Equal0~8_combout\))) # (!\controller|PS.P2~q\ & (!\controller|PS.P1~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|PS.P1~q\,
	datac => \controller|PS.P3~q\,
	datad => \datapth|rand|Equal0~8_combout\,
	combout => \datapth|rand|Mux0~4_combout\);

-- Location: LCCOMB_X52_Y32_N26
\datapth|rand|Mux0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~5_combout\ = (\datapth|rand|Mux0~1_combout\ & (\datapth|rand|ShiftLeft0~14_combout\)) # (!\datapth|rand|Mux0~1_combout\ & ((\datapth|rand|Mux0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|ShiftLeft0~14_combout\,
	datac => \datapth|rand|Mux0~1_combout\,
	datad => \datapth|rand|Mux0~4_combout\,
	combout => \datapth|rand|Mux0~5_combout\);

-- Location: LCCOMB_X47_Y32_N16
\datapth|rand|Mux0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux0~6_combout\ = (\datapth|rand|Mux0~3_combout\ & ((\datapth|rand|Mux0~2_combout\ & (\datapth|rand|S_3~9_combout\)) # (!\datapth|rand|Mux0~2_combout\ & ((\datapth|rand|Mux0~5_combout\))))) # (!\datapth|rand|Mux0~3_combout\ & 
-- (((\datapth|rand|Mux0~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101111110000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux0~3_combout\,
	datab => \datapth|rand|S_3~9_combout\,
	datac => \datapth|rand|Mux0~2_combout\,
	datad => \datapth|rand|Mux0~5_combout\,
	combout => \datapth|rand|Mux0~6_combout\);

-- Location: LCCOMB_X47_Y32_N26
\datapth|comparator_rand|comp_rand|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~3_combout\ = (\SW[8]~input_o\ & (\datapth|rand|Mux1~1_combout\ & (\SW[9]~input_o\ $ (!\datapth|rand|Mux0~6_combout\)))) # (!\SW[8]~input_o\ & (!\datapth|rand|Mux1~1_combout\ & (\SW[9]~input_o\ $ 
-- (!\datapth|rand|Mux0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[8]~input_o\,
	datab => \SW[9]~input_o\,
	datac => \datapth|rand|Mux1~1_combout\,
	datad => \datapth|rand|Mux0~6_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~3_combout\);

-- Location: LCCOMB_X52_Y32_N6
\datapth|rand|ShiftLeft4~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~4_combout\ = ((\datapth|rand|reg_rand|q\(0)) # (!\datapth|rand|reg_rand|q\(1))) # (!\datapth|rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft4~4_combout\);

-- Location: LCCOMB_X52_Y32_N30
\datapth|rand|ShiftLeft0~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~11_combout\ = (!\datapth|rand|ShiftLeft0~4_combout\ & (!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\ & (!\datapth|rand|reg_rand|q\(0) & 
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~4_combout\,
	datab => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	combout => \datapth|rand|ShiftLeft0~11_combout\);

-- Location: LCCOMB_X52_Y32_N28
\datapth|rand|Mux3~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux3~1_combout\ = (\datapth|rand|ShiftLeft4~4_combout\ & (((\datapth|rand|ShiftLeft0~11_combout\ & \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)))) # (!\datapth|rand|ShiftLeft4~4_combout\ & (\controller|PS.P1~q\ 
-- $ (((!\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\) # (!\datapth|rand|ShiftLeft0~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~4_combout\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|rand|ShiftLeft0~11_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|Mux3~1_combout\);

-- Location: LCCOMB_X49_Y32_N6
\datapth|rand|Mux5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux5~0_combout\ = (\controller|PS.P3~q\) # ((\controller|PS.P2~q\ & !\datapth|rand|Equal0~8_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \controller|PS.P3~q\,
	datad => \datapth|rand|Equal0~8_combout\,
	combout => \datapth|rand|Mux5~0_combout\);

-- Location: LCCOMB_X51_Y32_N16
\datapth|rand|S_3~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~6_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|ShiftLeft1~1_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & 
-- \datapth|rand|ShiftLeft2~1_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & ((\datapth|rand|ShiftLeft2~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \datapth|rand|ShiftLeft1~1_combout\,
	datad => \datapth|rand|ShiftLeft2~1_combout\,
	combout => \datapth|rand|S_3~6_combout\);

-- Location: LCCOMB_X50_Y32_N12
\datapth|rand|Mux5~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux5~1_combout\ = (\controller|PS.P2~q\ & (((!\controller|PS.P3~q\)) # (!\datapth|rand|Equal0~8_combout\))) # (!\controller|PS.P2~q\ & (((\datapth|rand|Mux9~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111100101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \datapth|rand|Equal0~8_combout\,
	datac => \controller|PS.P3~q\,
	datad => \datapth|rand|Mux9~8_combout\,
	combout => \datapth|rand|Mux5~1_combout\);

-- Location: LCCOMB_X51_Y32_N18
\datapth|rand|Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux3~0_combout\ = (\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux5~1_combout\ & ((\datapth|rand|S_3~6_combout\))) # (!\datapth|rand|Mux5~1_combout\ & (!\datapth|rand|ShiftLeft4~4_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & 
-- (((\datapth|rand|Mux5~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~4_combout\,
	datab => \datapth|rand|S_3~6_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux5~1_combout\,
	combout => \datapth|rand|Mux3~0_combout\);

-- Location: LCCOMB_X51_Y32_N12
\datapth|rand|Mux3~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux3~2_combout\ = (\datapth|rand|Mux5~0_combout\ & (((\datapth|rand|Mux3~0_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & (\datapth|rand|Mux3~1_combout\ & (\controller|PS.P1~q\ $ (\datapth|rand|Mux3~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P1~q\,
	datab => \datapth|rand|Mux3~1_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux3~0_combout\,
	combout => \datapth|rand|Mux3~2_combout\);

-- Location: LCCOMB_X50_Y32_N30
\datapth|rand|ShiftLeft4~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~5_combout\ = (\datapth|rand|reg_rand|q\(1) & (\datapth|rand|reg_rand|q\(0) & \datapth|rand|reg_rand|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(1),
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(2),
	combout => \datapth|rand|ShiftLeft4~5_combout\);

-- Location: LCCOMB_X50_Y32_N4
\datapth|rand|S_3~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~7_combout\ = (\datapth|rand|ShiftLeft1~2_combout\ & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & 
-- \datapth|rand|ShiftLeft2~2_combout\))))) # (!\datapth|rand|ShiftLeft1~2_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & ((\datapth|rand|ShiftLeft2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110110010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft1~2_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datad => \datapth|rand|ShiftLeft2~2_combout\,
	combout => \datapth|rand|S_3~7_combout\);

-- Location: LCCOMB_X50_Y32_N10
\datapth|rand|Mux2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux2~0_combout\ = (\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux5~1_combout\ & ((\datapth|rand|S_3~7_combout\))) # (!\datapth|rand|Mux5~1_combout\ & (\datapth|rand|ShiftLeft4~5_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & 
-- (((!\datapth|rand|Mux5~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~5_combout\,
	datab => \datapth|rand|S_3~7_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux5~1_combout\,
	combout => \datapth|rand|Mux2~0_combout\);

-- Location: LCCOMB_X52_Y35_N0
\datapth|rand|ShiftLeft0~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~13_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|ShiftLeft0~7_combout\ & 
-- \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|ShiftLeft0~7_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~13_combout\);

-- Location: LCCOMB_X50_Y32_N16
\datapth|rand|Mux2~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux2~1_combout\ = (\controller|PS.P1~q\ & ((\datapth|rand|ShiftLeft0~13_combout\) # ((!\datapth|rand|Mux2~0_combout\)))) # (!\controller|PS.P1~q\ & ((\datapth|rand|Mux2~0_combout\) # (\datapth|rand|ShiftLeft0~13_combout\ $ 
-- (\datapth|rand|ShiftLeft4~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~13_combout\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|rand|ShiftLeft4~5_combout\,
	datad => \datapth|rand|Mux2~0_combout\,
	combout => \datapth|rand|Mux2~1_combout\);

-- Location: LCCOMB_X47_Y32_N10
\datapth|rand|Mux2~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux2~2_combout\ = (\datapth|rand|Mux5~0_combout\ & (\datapth|rand|Mux2~0_combout\)) # (!\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux2~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mux5~0_combout\,
	datac => \datapth|rand|Mux2~0_combout\,
	datad => \datapth|rand|Mux2~1_combout\,
	combout => \datapth|rand|Mux2~2_combout\);

-- Location: LCCOMB_X47_Y32_N4
\datapth|comparator_rand|comp_rand|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~4_combout\ = (\SW[6]~input_o\ & (\datapth|rand|Mux3~2_combout\ & (\SW[7]~input_o\ $ (!\datapth|rand|Mux2~2_combout\)))) # (!\SW[6]~input_o\ & (!\datapth|rand|Mux3~2_combout\ & (\SW[7]~input_o\ $ 
-- (!\datapth|rand|Mux2~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[6]~input_o\,
	datab => \SW[7]~input_o\,
	datac => \datapth|rand|Mux3~2_combout\,
	datad => \datapth|rand|Mux2~2_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~4_combout\);

-- Location: LCCOMB_X52_Y32_N16
\datapth|rand|ShiftLeft4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~2_combout\ = ((\datapth|rand|reg_rand|q\(0)) # (\datapth|rand|reg_rand|q\(1))) # (!\datapth|rand|reg_rand|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft4~2_combout\);

-- Location: LCCOMB_X52_Y32_N18
\datapth|rand|Mux5~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux5~3_combout\ = (\datapth|rand|ShiftLeft0~11_combout\ & (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\ $ (((\controller|PS.P1~q\) # (\datapth|rand|ShiftLeft4~2_combout\))))) # 
-- (!\datapth|rand|ShiftLeft0~11_combout\ & (!\controller|PS.P1~q\ & (!\datapth|rand|ShiftLeft4~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001110101001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~11_combout\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|rand|ShiftLeft4~2_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|Mux5~3_combout\);

-- Location: LCCOMB_X50_Y32_N6
\datapth|rand|ShiftLeft2~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft2~3_combout\ = (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\ & (\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\ & 
-- (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\ & \datapth|rand|Equal2~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[59]~113_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[58]~111_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[57]~109_combout\,
	datad => \datapth|rand|Equal2~0_combout\,
	combout => \datapth|rand|ShiftLeft2~3_combout\);

-- Location: LCCOMB_X50_Y31_N8
\datapth|rand|ShiftLeft1~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft1~3_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\ & (\datapth|rand|Equal1~0_combout\ & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & 
-- !\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datab => \datapth|rand|Equal1~0_combout\,
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	combout => \datapth|rand|ShiftLeft1~3_combout\);

-- Location: LCCOMB_X51_Y32_N4
\datapth|rand|S_3~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~4_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & (\datapth|rand|ShiftLeft2~3_combout\))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|ShiftLeft1~3_combout\ $ (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & \datapth|rand|ShiftLeft2~3_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110010100110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datac => \datapth|rand|ShiftLeft2~3_combout\,
	datad => \datapth|rand|ShiftLeft1~3_combout\,
	combout => \datapth|rand|S_3~4_combout\);

-- Location: LCCOMB_X51_Y32_N10
\datapth|rand|Mux5~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux5~2_combout\ = (\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux5~1_combout\ & ((\datapth|rand|S_3~4_combout\))) # (!\datapth|rand|Mux5~1_combout\ & (!\datapth|rand|ShiftLeft4~2_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & 
-- (((\datapth|rand|Mux5~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~2_combout\,
	datab => \datapth|rand|S_3~4_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux5~1_combout\,
	combout => \datapth|rand|Mux5~2_combout\);

-- Location: LCCOMB_X51_Y32_N26
\datapth|rand|Mux5~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux5~4_combout\ = (\datapth|rand|Mux5~0_combout\ & (((\datapth|rand|Mux5~2_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & (\datapth|rand|Mux5~3_combout\ & (\controller|PS.P1~q\ $ (\datapth|rand|Mux5~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P1~q\,
	datab => \datapth|rand|Mux5~3_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux5~2_combout\,
	combout => \datapth|rand|Mux5~4_combout\);

-- Location: LCCOMB_X44_Y32_N16
\datapth|rand|ShiftLeft4~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~3_combout\ = (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|reg_rand|q\(2) & !\datapth|rand|reg_rand|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|reg_rand|q\(2),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft4~3_combout\);

-- Location: LCCOMB_X50_Y32_N14
\datapth|rand|S_3~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~5_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|ShiftLeft1~3_combout\ $ (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & 
-- \datapth|rand|ShiftLeft2~3_combout\))))) # (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (((\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & \datapth|rand|ShiftLeft2~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111100010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|ShiftLeft1~3_combout\,
	datac => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datad => \datapth|rand|ShiftLeft2~3_combout\,
	combout => \datapth|rand|S_3~5_combout\);

-- Location: LCCOMB_X50_Y32_N24
\datapth|rand|Mux4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux4~0_combout\ = (\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux5~1_combout\ & ((\datapth|rand|S_3~5_combout\))) # (!\datapth|rand|Mux5~1_combout\ & (\datapth|rand|ShiftLeft4~3_combout\)))) # (!\datapth|rand|Mux5~0_combout\ & 
-- (((!\datapth|rand|Mux5~1_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000010101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft4~3_combout\,
	datab => \datapth|rand|S_3~5_combout\,
	datac => \datapth|rand|Mux5~0_combout\,
	datad => \datapth|rand|Mux5~1_combout\,
	combout => \datapth|rand|Mux4~0_combout\);

-- Location: LCCOMB_X52_Y35_N26
\datapth|rand|ShiftLeft0~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~12_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|rand|reg_rand|q\(0) & (\datapth|rand|ShiftLeft0~7_combout\ & 
-- !\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|ShiftLeft0~7_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~12_combout\);

-- Location: LCCOMB_X50_Y32_N18
\datapth|rand|Mux4~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux4~1_combout\ = (\controller|PS.P1~q\ & ((\datapth|rand|ShiftLeft0~12_combout\) # ((!\datapth|rand|Mux4~0_combout\)))) # (!\controller|PS.P1~q\ & ((\datapth|rand|Mux4~0_combout\) # (\datapth|rand|ShiftLeft0~12_combout\ $ 
-- (\datapth|rand|ShiftLeft4~3_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011101111011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|ShiftLeft0~12_combout\,
	datab => \controller|PS.P1~q\,
	datac => \datapth|rand|ShiftLeft4~3_combout\,
	datad => \datapth|rand|Mux4~0_combout\,
	combout => \datapth|rand|Mux4~1_combout\);

-- Location: LCCOMB_X46_Y32_N2
\datapth|rand|Mux4~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux4~2_combout\ = (\datapth|rand|Mux5~0_combout\ & (\datapth|rand|Mux4~0_combout\)) # (!\datapth|rand|Mux5~0_combout\ & ((\datapth|rand|Mux4~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|rand|Mux5~0_combout\,
	datac => \datapth|rand|Mux4~0_combout\,
	datad => \datapth|rand|Mux4~1_combout\,
	combout => \datapth|rand|Mux4~2_combout\);

-- Location: LCCOMB_X47_Y32_N6
\datapth|comparator_rand|comp_rand|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~5_combout\ = (\SW[4]~input_o\ & (\datapth|rand|Mux5~4_combout\ & (\SW[5]~input_o\ $ (!\datapth|rand|Mux4~2_combout\)))) # (!\SW[4]~input_o\ & (!\datapth|rand|Mux5~4_combout\ & (\SW[5]~input_o\ $ 
-- (!\datapth|rand|Mux4~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000010000100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \SW[4]~input_o\,
	datab => \SW[5]~input_o\,
	datac => \datapth|rand|Mux5~4_combout\,
	datad => \datapth|rand|Mux4~2_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~5_combout\);

-- Location: LCCOMB_X47_Y32_N12
\datapth|comparator_rand|comp_rand|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|comparator_rand|comp_rand|Equal0~6_combout\ = (\datapth|comparator_rand|comp_rand|Equal0~3_combout\ & (\datapth|comparator_rand|comp_rand|Equal0~4_combout\ & \datapth|comparator_rand|comp_rand|Equal0~5_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|comparator_rand|comp_rand|Equal0~3_combout\,
	datac => \datapth|comparator_rand|comp_rand|Equal0~4_combout\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~5_combout\,
	combout => \datapth|comparator_rand|comp_rand|Equal0~6_combout\);

-- Location: LCCOMB_X47_Y36_N16
\controller|Selector7~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector7~0_combout\ = (!\datapth|comparator_level|comp_lev|Equal0~0_combout\ & (\controller|PS.S3~q\ & \datapth|comparator_zero|comp_lev|Equal0~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|comparator_level|comp_lev|Equal0~0_combout\,
	datac => \controller|PS.S3~q\,
	datad => \datapth|comparator_zero|comp_lev|Equal0~2_combout\,
	combout => \controller|Selector7~0_combout\);

-- Location: LCCOMB_X47_Y32_N22
\controller|Selector7~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector7~1_combout\ = (\controller|Selector7~0_combout\) # ((\controller|PS.P3~q\ & ((!\datapth|comparator_rand|comp_rand|Equal0~2_combout\) # (!\datapth|comparator_rand|comp_rand|Equal0~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|comparator_rand|comp_rand|Equal0~6_combout\,
	datab => \controller|Selector7~0_combout\,
	datac => \controller|PS.P3~q\,
	datad => \datapth|comparator_rand|comp_rand|Equal0~2_combout\,
	combout => \controller|Selector7~1_combout\);

-- Location: FF_X47_Y32_N23
\controller|PS.P3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector7~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.P3~q\);

-- Location: LCCOMB_X44_Y32_N10
\datapth|rand|Equal1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal1~2_combout\ = (\datapth|rand|reg_rand|q\(1) & (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ & (\datapth|rand|reg_rand|q\(0) $ 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\)))) # (!\datapth|rand|reg_rand|q\(1) & (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\ & (\datapth|rand|reg_rand|q\(0) $ 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(1),
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datad => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[57]~99_combout\,
	combout => \datapth|rand|Equal1~2_combout\);

-- Location: LCCOMB_X50_Y32_N20
\datapth|rand|Equal1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Equal1~1_combout\ = (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\ & \datapth|rand|Equal1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[59]~101_combout\,
	datad => \datapth|rand|Equal1~0_combout\,
	combout => \datapth|rand|Equal1~1_combout\);

-- Location: LCCOMB_X50_Y32_N26
\datapth|rand|Mux9~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~7_combout\ = (\controller|PS.P3~q\ & ((\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\) # ((!\datapth|rand|Equal1~1_combout\) # (!\datapth|rand|Equal1~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P3~q\,
	datab => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[58]~100_combout\,
	datac => \datapth|rand|Equal1~2_combout\,
	datad => \datapth|rand|Equal1~1_combout\,
	combout => \datapth|rand|Mux9~7_combout\);

-- Location: LCCOMB_X50_Y32_N2
\datapth|rand|Mux9~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~8_combout\ = (\datapth|rand|Mux9~7_combout\ & (!\datapth|rand|Equal2~3_combout\ & !\datapth|rand|Equal0~8_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~7_combout\,
	datac => \datapth|rand|Equal2~3_combout\,
	datad => \datapth|rand|Equal0~8_combout\,
	combout => \datapth|rand|Mux9~8_combout\);

-- Location: LCCOMB_X44_Y32_N4
\datapth|rand|ShiftLeft4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft4~0_combout\ = (!\datapth|rand|reg_rand|q\(0) & !\datapth|rand|reg_rand|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|ShiftLeft4~0_combout\);

-- Location: LCCOMB_X49_Y34_N18
\datapth|rand|S_3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_3~0_combout\ = (\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & ((\datapth|rand|ShiftLeft2~0_combout\)))) # 
-- (!\datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\ & (\datapth|rand|ShiftLeft1~0_combout\ $ (((!\datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\ & \datapth|rand|ShiftLeft2~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110001101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod1|auto_generated|divider|divider|StageOut[56]~102_combout\,
	datab => \datapth|rand|Mod2|auto_generated|divider|divider|StageOut[56]~114_combout\,
	datac => \datapth|rand|ShiftLeft1~0_combout\,
	datad => \datapth|rand|ShiftLeft2~0_combout\,
	combout => \datapth|rand|S_3~0_combout\);

-- Location: LCCOMB_X52_Y35_N14
\datapth|rand|ShiftLeft0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|ShiftLeft0~6_combout\ = (\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\) # ((\datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\) # (!\datapth|rand|ShiftLeft0~5_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \datapth|rand|ShiftLeft0~5_combout\,
	datad => \datapth|rand|Mod0|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|rand|ShiftLeft0~6_combout\);

-- Location: LCCOMB_X52_Y35_N28
\datapth|rand|S_2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|S_2~0_combout\ = \datapth|rand|ShiftLeft0~6_combout\ $ (((\datapth|rand|reg_rand|q\(2)) # ((\datapth|rand|reg_rand|q\(0)) # (\datapth|rand|reg_rand|q\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|reg_rand|q\(0),
	datac => \datapth|rand|ShiftLeft0~6_combout\,
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|S_2~0_combout\);

-- Location: LCCOMB_X51_Y34_N0
\datapth|rand|Mux9~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~1_combout\ = (\datapth|rand|Mux9~0_combout\ & ((\datapth|rand|reg_rand|q\(2)) # ((\datapth|rand|reg_rand|q\(0)) # (\datapth|rand|reg_rand|q\(1)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|reg_rand|q\(2),
	datab => \datapth|rand|Mux9~0_combout\,
	datac => \datapth|rand|reg_rand|q\(0),
	datad => \datapth|rand|reg_rand|q\(1),
	combout => \datapth|rand|Mux9~1_combout\);

-- Location: LCCOMB_X49_Y32_N2
\datapth|rand|Mux9~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~5_combout\ = (\datapth|rand|Mux9~2_combout\ & ((\datapth|rand|Mux9~4_combout\ & (\datapth|rand|Mux9~1_combout\)) # (!\datapth|rand|Mux9~4_combout\ & ((!\datapth|rand|ShiftLeft0~6_combout\))))) # (!\datapth|rand|Mux9~2_combout\ & 
-- (((\datapth|rand|Mux9~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110100001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~2_combout\,
	datab => \datapth|rand|Mux9~1_combout\,
	datac => \datapth|rand|ShiftLeft0~6_combout\,
	datad => \datapth|rand|Mux9~4_combout\,
	combout => \datapth|rand|Mux9~5_combout\);

-- Location: LCCOMB_X49_Y32_N20
\datapth|rand|Mux9~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~6_combout\ = (\controller|PS.P2~q\ & ((\datapth|rand|Mux9~5_combout\ & ((\datapth|rand|S_3~0_combout\))) # (!\datapth|rand|Mux9~5_combout\ & (!\datapth|rand|S_2~0_combout\)))) # (!\controller|PS.P2~q\ & 
-- (((\datapth|rand|Mux9~5_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111010100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P2~q\,
	datab => \datapth|rand|S_2~0_combout\,
	datac => \datapth|rand|S_3~0_combout\,
	datad => \datapth|rand|Mux9~5_combout\,
	combout => \datapth|rand|Mux9~6_combout\);

-- Location: LCCOMB_X49_Y32_N28
\datapth|rand|Mux9~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|rand|Mux9~9_combout\ = (\datapth|rand|Mux9~8_combout\ & (\datapth|rand|ShiftLeft4~0_combout\ $ ((\datapth|rand|S_3~0_combout\)))) # (!\datapth|rand|Mux9~8_combout\ & (((\datapth|rand|Mux9~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111110100101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|rand|Mux9~8_combout\,
	datab => \datapth|rand|ShiftLeft4~0_combout\,
	datac => \datapth|rand|S_3~0_combout\,
	datad => \datapth|rand|Mux9~6_combout\,
	combout => \datapth|rand|Mux9~9_combout\);

-- Location: LCCOMB_X47_Y34_N28
\datapth|total_timer|reg_tim|q[0]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[0]~7_combout\ = \datapth|total_timer|reg_tim|q\(0) $ (((\controller|PS.P1~q\) # ((\controller|PS.P3~q\) # (\controller|PS.P2~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100011110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.P1~q\,
	datab => \controller|PS.P3~q\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \controller|PS.P2~q\,
	combout => \datapth|total_timer|reg_tim|q[0]~7_combout\);

-- Location: FF_X47_Y34_N29
\datapth|total_timer|reg_tim|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[0]~7_combout\,
	clrn => \controller|PS.S0~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(0));

-- Location: LCCOMB_X45_Y34_N14
\datapth|total_timer|reg_tim|q[1]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[1]~8_combout\ = (\datapth|total_timer|reg_tim|q\(0) & (\datapth|total_timer|reg_tim|q\(1) $ (VCC))) # (!\datapth|total_timer|reg_tim|q\(0) & (\datapth|total_timer|reg_tim|q\(1) & VCC))
-- \datapth|total_timer|reg_tim|q[1]~9\ = CARRY((\datapth|total_timer|reg_tim|q\(0) & \datapth|total_timer|reg_tim|q\(1)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(0),
	datab => \datapth|total_timer|reg_tim|q\(1),
	datad => VCC,
	combout => \datapth|total_timer|reg_tim|q[1]~8_combout\,
	cout => \datapth|total_timer|reg_tim|q[1]~9\);

-- Location: FF_X45_Y34_N15
\datapth|total_timer|reg_tim|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[1]~8_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(1));

-- Location: LCCOMB_X45_Y34_N16
\datapth|total_timer|reg_tim|q[2]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[2]~10_combout\ = (\datapth|total_timer|reg_tim|q\(2) & (!\datapth|total_timer|reg_tim|q[1]~9\)) # (!\datapth|total_timer|reg_tim|q\(2) & ((\datapth|total_timer|reg_tim|q[1]~9\) # (GND)))
-- \datapth|total_timer|reg_tim|q[2]~11\ = CARRY((!\datapth|total_timer|reg_tim|q[1]~9\) # (!\datapth|total_timer|reg_tim|q\(2)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(2),
	datad => VCC,
	cin => \datapth|total_timer|reg_tim|q[1]~9\,
	combout => \datapth|total_timer|reg_tim|q[2]~10_combout\,
	cout => \datapth|total_timer|reg_tim|q[2]~11\);

-- Location: FF_X45_Y34_N17
\datapth|total_timer|reg_tim|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[2]~10_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(2));

-- Location: LCCOMB_X45_Y34_N18
\datapth|total_timer|reg_tim|q[3]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[3]~12_combout\ = (\datapth|total_timer|reg_tim|q\(3) & (\datapth|total_timer|reg_tim|q[2]~11\ $ (GND))) # (!\datapth|total_timer|reg_tim|q\(3) & (!\datapth|total_timer|reg_tim|q[2]~11\ & VCC))
-- \datapth|total_timer|reg_tim|q[3]~13\ = CARRY((\datapth|total_timer|reg_tim|q\(3) & !\datapth|total_timer|reg_tim|q[2]~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(3),
	datad => VCC,
	cin => \datapth|total_timer|reg_tim|q[2]~11\,
	combout => \datapth|total_timer|reg_tim|q[3]~12_combout\,
	cout => \datapth|total_timer|reg_tim|q[3]~13\);

-- Location: FF_X45_Y34_N19
\datapth|total_timer|reg_tim|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[3]~12_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(3));

-- Location: LCCOMB_X45_Y34_N20
\datapth|total_timer|reg_tim|q[4]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[4]~14_combout\ = (\datapth|total_timer|reg_tim|q\(4) & (!\datapth|total_timer|reg_tim|q[3]~13\)) # (!\datapth|total_timer|reg_tim|q\(4) & ((\datapth|total_timer|reg_tim|q[3]~13\) # (GND)))
-- \datapth|total_timer|reg_tim|q[4]~15\ = CARRY((!\datapth|total_timer|reg_tim|q[3]~13\) # (!\datapth|total_timer|reg_tim|q\(4)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(4),
	datad => VCC,
	cin => \datapth|total_timer|reg_tim|q[3]~13\,
	combout => \datapth|total_timer|reg_tim|q[4]~14_combout\,
	cout => \datapth|total_timer|reg_tim|q[4]~15\);

-- Location: FF_X45_Y34_N21
\datapth|total_timer|reg_tim|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[4]~14_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(4));

-- Location: LCCOMB_X45_Y34_N22
\datapth|total_timer|reg_tim|q[5]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[5]~16_combout\ = (\datapth|total_timer|reg_tim|q\(5) & (\datapth|total_timer|reg_tim|q[4]~15\ $ (GND))) # (!\datapth|total_timer|reg_tim|q\(5) & (!\datapth|total_timer|reg_tim|q[4]~15\ & VCC))
-- \datapth|total_timer|reg_tim|q[5]~17\ = CARRY((\datapth|total_timer|reg_tim|q\(5) & !\datapth|total_timer|reg_tim|q[4]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(5),
	datad => VCC,
	cin => \datapth|total_timer|reg_tim|q[4]~15\,
	combout => \datapth|total_timer|reg_tim|q[5]~16_combout\,
	cout => \datapth|total_timer|reg_tim|q[5]~17\);

-- Location: FF_X45_Y34_N23
\datapth|total_timer|reg_tim|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[5]~16_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(5));

-- Location: LCCOMB_X45_Y34_N24
\datapth|total_timer|reg_tim|q[6]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[6]~18_combout\ = (\datapth|total_timer|reg_tim|q\(6) & (!\datapth|total_timer|reg_tim|q[5]~17\)) # (!\datapth|total_timer|reg_tim|q\(6) & ((\datapth|total_timer|reg_tim|q[5]~17\) # (GND)))
-- \datapth|total_timer|reg_tim|q[6]~19\ = CARRY((!\datapth|total_timer|reg_tim|q[5]~17\) # (!\datapth|total_timer|reg_tim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \datapth|total_timer|reg_tim|q[5]~17\,
	combout => \datapth|total_timer|reg_tim|q[6]~18_combout\,
	cout => \datapth|total_timer|reg_tim|q[6]~19\);

-- Location: FF_X45_Y34_N25
\datapth|total_timer|reg_tim|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[6]~18_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(6));

-- Location: LCCOMB_X45_Y34_N26
\datapth|total_timer|reg_tim|q[7]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|total_timer|reg_tim|q[7]~20_combout\ = \datapth|total_timer|reg_tim|q\(7) $ (!\datapth|total_timer|reg_tim|q[6]~19\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010110100101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(7),
	cin => \datapth|total_timer|reg_tim|q[6]~19\,
	combout => \datapth|total_timer|reg_tim|q[7]~20_combout\);

-- Location: FF_X45_Y34_N27
\datapth|total_timer|reg_tim|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapth|total_timer|reg_tim|q[7]~20_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|WideOr1~combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapth|total_timer|reg_tim|q\(7));

-- Location: LCCOMB_X39_Y33_N8
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \datapth|total_timer|reg_tim|q\(5) $ (VCC)
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\datapth|total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(5),
	datad => VCC,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X39_Y33_N10
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\datapth|total_timer|reg_tim|q\(6) & (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\datapth|total_timer|reg_tim|q\(6) 
-- & (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\datapth|total_timer|reg_tim|q\(6) & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X39_Y33_N12
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\datapth|total_timer|reg_tim|q\(7) & (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # 
-- (!\datapth|total_timer|reg_tim|q\(7) & (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\datapth|total_timer|reg_tim|q\(7) & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X39_Y33_N14
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X39_Y33_N4
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(7),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\);

-- Location: LCCOMB_X38_Y33_N4
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\);

-- Location: LCCOMB_X39_Y33_N2
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\ = (\datapth|total_timer|reg_tim|q\(6) & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(6),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\);

-- Location: LCCOMB_X38_Y33_N18
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\);

-- Location: LCCOMB_X39_Y33_N20
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(5),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\);

-- Location: LCCOMB_X38_Y33_N24
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\);

-- Location: LCCOMB_X39_Y33_N24
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(4),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\);

-- Location: LCCOMB_X39_Y33_N26
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(4),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\);

-- Location: LCCOMB_X38_Y33_N6
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~61_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[24]~60_combout\,
	datad => VCC,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X38_Y33_N8
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~58_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[25]~59_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X38_Y33_N10
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\)))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~56_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[26]~57_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X38_Y33_N12
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~54_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[27]~55_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\);

-- Location: LCCOMB_X38_Y33_N14
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X38_Y33_N2
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\datapth|total_timer|reg_tim|q\(7)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(7),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\);

-- Location: LCCOMB_X37_Y33_N16
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\);

-- Location: LCCOMB_X38_Y33_N20
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\datapth|total_timer|reg_tim|q\(6)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(6),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\);

-- Location: LCCOMB_X38_Y33_N28
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\);

-- Location: LCCOMB_X37_Y33_N22
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\);

-- Location: LCCOMB_X38_Y33_N22
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & (\datapth|total_timer|reg_tim|q\(5))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(5),
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\);

-- Location: LCCOMB_X38_Y33_N30
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\);

-- Location: LCCOMB_X37_Y33_N28
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ = (\datapth|total_timer|reg_tim|q\(4) & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(4),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\);

-- Location: LCCOMB_X37_Y33_N30
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\datapth|total_timer|reg_tim|q\(3) & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(3),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X37_Y33_N20
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\ = (\datapth|total_timer|reg_tim|q\(3) & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(3),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\);

-- Location: LCCOMB_X37_Y33_N2
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[32]~68_combout\,
	datad => VCC,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X37_Y33_N4
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~66_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[33]~65_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X37_Y33_N6
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\)))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~64_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X37_Y33_N8
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~63_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\);

-- Location: LCCOMB_X37_Y33_N10
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\))))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\) # (GND))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~62_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\);

-- Location: LCCOMB_X37_Y33_N12
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ = !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~9\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\);

-- Location: LCCOMB_X38_Y33_N16
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\) # 
-- ((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[36]~96_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\);

-- Location: LCCOMB_X38_Y34_N8
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\);

-- Location: LCCOMB_X38_Y33_N26
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\) # 
-- ((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[35]~97_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\);

-- Location: LCCOMB_X38_Y34_N14
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\);

-- Location: LCCOMB_X38_Y34_N4
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\);

-- Location: LCCOMB_X38_Y33_N0
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\) # 
-- ((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[34]~98_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\);

-- Location: LCCOMB_X37_Y33_N14
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\);

-- Location: LCCOMB_X37_Y33_N0
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (\datapth|total_timer|reg_tim|q\(4))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000101010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|total_timer|reg_tim|q\(4),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\);

-- Location: LCCOMB_X38_Y34_N10
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & \datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \datapth|total_timer|reg_tim|q\(3),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\);

-- Location: LCCOMB_X37_Y33_N24
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\);

-- Location: LCCOMB_X39_Y34_N4
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\ = (\datapth|total_timer|reg_tim|q\(2) & \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(2),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\);

-- Location: LCCOMB_X39_Y34_N26
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\ = (\datapth|total_timer|reg_tim|q\(2) & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(2),
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\);

-- Location: LCCOMB_X38_Y34_N18
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~75_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[40]~76_combout\,
	datad => VCC,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X38_Y34_N20
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~73_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[41]~74_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X38_Y34_N22
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\)))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~72_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X38_Y34_N24
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~71_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X38_Y34_N26
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\))))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\) # (GND))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001111011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~70_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X38_Y34_N28
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~69_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X38_Y34_N30
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X38_Y34_N2
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\);

-- Location: LCCOMB_X37_Y33_N18
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & (\datapth|total_timer|reg_tim|q\(3))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datac => \datapth|total_timer|reg_tim|q\(3),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\);

-- Location: LCCOMB_X40_Y34_N24
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\);

-- Location: LCCOMB_X37_Y34_N24
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\);

-- Location: LCCOMB_X37_Y34_N26
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|total_timer|reg_tim|q\(1),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\);

-- Location: LCCOMB_X37_Y34_N20
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & \datapth|total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|total_timer|reg_tim|q\(1),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\);

-- Location: LCCOMB_X37_Y34_N4
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\ = (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\) # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~78_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[48]~77_combout\,
	datad => VCC,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\);

-- Location: LCCOMB_X37_Y34_N6
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ & 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\)))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\);

-- Location: LCCOMB_X37_Y34_N8
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\) 
-- # (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\)))))
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\);

-- Location: LCCOMB_X37_Y34_N0
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\);

-- Location: LCCOMB_X38_Y34_N16
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[45]~89_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\);

-- Location: LCCOMB_X38_Y34_N6
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\ & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[44]~90_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[4]~6_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\);

-- Location: LCCOMB_X38_Y34_N12
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\);

-- Location: LCCOMB_X37_Y34_N22
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\);

-- Location: LCCOMB_X38_Y34_N0
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[43]~91_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\);

-- Location: LCCOMB_X39_Y34_N28
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\);

-- Location: LCCOMB_X37_Y33_N26
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000011100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[42]~99_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_5_result_int[6]~10_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\);

-- Location: LCCOMB_X37_Y34_N10
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\ 
-- & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~82_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[51]~95_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\);

-- Location: LCCOMB_X37_Y34_N12
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\) # ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\) 
-- # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~81_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[52]~94_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\);

-- Location: LCCOMB_X37_Y34_N14
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\ = CARRY((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\ 
-- & !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~93_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[53]~80_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[5]~9_cout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\);

-- Location: LCCOMB_X37_Y34_N16
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\ = CARRY((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~79_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[54]~92_combout\,
	datad => VCC,
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[6]~11_cout\,
	cout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\);

-- Location: LCCOMB_X37_Y34_N18
\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ = !\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[7]~13_cout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\);

-- Location: LCCOMB_X37_Y34_N30
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\) # 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & 
-- (((\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~83_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[50]~100_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[3]~4_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\);

-- Location: LCCOMB_X37_Y34_N28
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & 
-- (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[2]~2_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~85_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[49]~84_combout\,
	datad => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\);

-- Location: LCCOMB_X37_Y34_N2
\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & ((\datapth|total_timer|reg_tim|q\(1)))) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\ & (\datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[8]~14_combout\,
	datac => \datapth|display|Mod1|auto_generated|divider|divider|add_sub_7_result_int[1]~0_combout\,
	datad => \datapth|total_timer|reg_tim|q\(1),
	combout => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\);

-- Location: LCCOMB_X32_Y36_N16
\datapth|display|Mux6~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux6~0_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\ & 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ $ (\datapth|total_timer|reg_tim|q\(0)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|Mux6~0_combout\);

-- Location: LCCOMB_X32_Y36_N30
\datapth|display|res:s_u[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[0]~0_combout\ = (\controller|PS.S4~q\ & !\datapth|display|Mux6~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Mux6~0_combout\,
	combout => \datapth|display|res:s_u[0]~0_combout\);

-- Location: LCCOMB_X32_Y36_N8
\datapth|display|res:s_u[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[1]~0_combout\ = (\controller|PS.S4~q\ & ((\datapth|total_timer|reg_tim|q\(0) $ (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\)) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100010001001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \controller|PS.S4~q\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|res:s_u[1]~0_combout\);

-- Location: LCCOMB_X32_Y36_N18
\datapth|display|res:s_u[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[2]~0_combout\ = (\controller|PS.S4~q\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\) # ((\datapth|total_timer|reg_tim|q\(0)) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \controller|PS.S4~q\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|res:s_u[2]~0_combout\);

-- Location: LCCOMB_X32_Y36_N20
\datapth|display|Mux3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux3~0_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|total_timer|reg_tim|q\(0) $ 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\))) # (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|total_timer|reg_tim|q\(0) & 
-- !\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|Mux3~0_combout\);

-- Location: LCCOMB_X32_Y36_N14
\datapth|display|res:s_u[3]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[3]~0_combout\ = (\controller|PS.S4~q\ & !\datapth|display|Mux3~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Mux3~0_combout\,
	combout => \datapth|display|res:s_u[3]~0_combout\);

-- Location: LCCOMB_X32_Y36_N28
\datapth|display|res:s_u[4]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[4]~0_combout\ = (\controller|PS.S4~q\ & (!\datapth|total_timer|reg_tim|q\(0) & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\) # 
-- (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datab => \controller|PS.S4~q\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|res:s_u[4]~0_combout\);

-- Location: LCCOMB_X32_Y36_N26
\datapth|display|Mux1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux1~0_combout\ = (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\ & ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & (\datapth|total_timer|reg_tim|q\(0) & 
-- \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\)) # (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & ((\datapth|total_timer|reg_tim|q\(0)) # 
-- (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|Mux1~0_combout\);

-- Location: LCCOMB_X32_Y36_N4
\datapth|display|res:s_u[5]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[5]~0_combout\ = (!\datapth|display|Mux1~0_combout\ & \controller|PS.S4~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mux1~0_combout\,
	datac => \controller|PS.S4~q\,
	combout => \datapth|display|res:s_u[5]~0_combout\);

-- Location: LCCOMB_X32_Y36_N10
\datapth|display|Mux0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux0~0_combout\ = (\datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\) # ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & 
-- ((!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\) # (!\datapth|total_timer|reg_tim|q\(0)))) # (!\datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\ & 
-- ((\datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1011111111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[59]~88_combout\,
	datab => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[58]~87_combout\,
	datac => \datapth|total_timer|reg_tim|q\(0),
	datad => \datapth|display|Mod1|auto_generated|divider|divider|StageOut[57]~86_combout\,
	combout => \datapth|display|Mux0~0_combout\);

-- Location: LCCOMB_X32_Y36_N12
\datapth|display|res:s_u[6]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_u[6]~0_combout\ = (\controller|PS.S4~q\ & \datapth|display|Mux0~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Mux0~0_combout\,
	combout => \datapth|display|res:s_u[6]~0_combout\);

-- Location: LCCOMB_X38_Y36_N0
\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ = \datapth|total_timer|reg_tim|q\(5) $ (VCC)
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ = CARRY(\datapth|total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(5),
	datad => VCC,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\);

-- Location: LCCOMB_X38_Y36_N2
\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ = (\datapth|total_timer|reg_tim|q\(6) & (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\ & VCC)) # (!\datapth|total_timer|reg_tim|q\(6) 
-- & (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ = CARRY((!\datapth|total_timer|reg_tim|q\(6) & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~1\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\);

-- Location: LCCOMB_X38_Y36_N4
\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ = (\datapth|total_timer|reg_tim|q\(7) & (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ $ (GND))) # 
-- (!\datapth|total_timer|reg_tim|q\(7) & (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\ & VCC))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\ = CARRY((\datapth|total_timer|reg_tim|q\(7) & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~3\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\);

-- Location: LCCOMB_X38_Y36_N6
\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ = !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~5\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\);

-- Location: LCCOMB_X38_Y36_N16
\datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[3]~4_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\);

-- Location: LCCOMB_X39_Y35_N18
\datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(7),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\);

-- Location: LCCOMB_X39_Y35_N12
\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(6),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\);

-- Location: LCCOMB_X38_Y36_N30
\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\);

-- Location: LCCOMB_X39_Y35_N10
\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & \datapth|total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(5),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\);

-- Location: LCCOMB_X39_Y35_N20
\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000101000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\);

-- Location: LCCOMB_X39_Y35_N22
\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\ = (\datapth|total_timer|reg_tim|q\(4) & \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(4),
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\);

-- Location: LCCOMB_X39_Y35_N28
\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\ = (\datapth|total_timer|reg_tim|q\(4) & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(4),
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\);

-- Location: LCCOMB_X39_Y35_N0
\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\ = (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ = CARRY((\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~42_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[15]~43_combout\,
	datad => VCC,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\);

-- Location: LCCOMB_X39_Y35_N2
\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ & 
-- (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~40_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[16]~41_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~1\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\);

-- Location: LCCOMB_X39_Y35_N4
\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((((\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\)))))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\ & ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~38_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[17]~39_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~3\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\);

-- Location: LCCOMB_X39_Y35_N6
\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\ 
-- & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~37_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[18]~36_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~5\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\);

-- Location: LCCOMB_X39_Y35_N8
\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ = \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[4]~7_cout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\);

-- Location: LCCOMB_X39_Y35_N26
\datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[3]~4_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\);

-- Location: LCCOMB_X38_Y36_N12
\datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\datapth|total_timer|reg_tim|q\(6)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[2]~2_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(6),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\);

-- Location: LCCOMB_X39_Y35_N16
\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\);

-- Location: LCCOMB_X39_Y35_N24
\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & ((\datapth|total_timer|reg_tim|q\(5)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100000001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[1]~0_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => \datapth|total_timer|reg_tim|q\(5),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\);

-- Location: LCCOMB_X39_Y36_N8
\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ = (\datapth|total_timer|reg_tim|q\(4) & \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(4),
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\);

-- Location: LCCOMB_X39_Y35_N30
\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\);

-- Location: LCCOMB_X40_Y35_N26
\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(3),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\);

-- Location: LCCOMB_X40_Y35_N10
\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(3),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\);

-- Location: LCCOMB_X40_Y35_N12
\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ = (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ = CARRY((\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~48_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[20]~49_combout\,
	datad => VCC,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\);

-- Location: LCCOMB_X40_Y35_N14
\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ & 
-- (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~46_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[21]~47_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~1\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\);

-- Location: LCCOMB_X40_Y35_N16
\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((((\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\)))))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\ & ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~45_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~3\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\);

-- Location: LCCOMB_X40_Y35_N18
\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\ 
-- & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~44_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[23]~64_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~5\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\);

-- Location: LCCOMB_X40_Y35_N20
\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ = \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[4]~7_cout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\);

-- Location: LCCOMB_X38_Y35_N12
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ $ (GND)
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY(!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => VCC,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X38_Y35_N14
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & VCC))
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X38_Y35_N16
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & VCC)) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ $ (GND)))
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000000011",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X38_Y35_N18
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ = !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ = CARRY(!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\);

-- Location: LCCOMB_X38_Y35_N20
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ $ (GND)
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\ = CARRY(!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~7\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\);

-- Location: LCCOMB_X38_Y35_N22
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ = !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\ = CARRY(!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~9\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\);

-- Location: LCCOMB_X38_Y35_N24
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ = \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~11\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\);

-- Location: LCCOMB_X38_Y35_N4
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\);

-- Location: LCCOMB_X38_Y35_N26
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\);

-- Location: LCCOMB_X41_Y35_N30
\datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[3]~4_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\);

-- Location: LCCOMB_X40_Y35_N24
\datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\) # 
-- ((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[22]~65_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[2]~2_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\);

-- Location: LCCOMB_X39_Y35_N14
\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & (\datapth|total_timer|reg_tim|q\(4))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010001010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datac => \datapth|total_timer|reg_tim|q\(4),
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[1]~0_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\);

-- Location: LCCOMB_X41_Y35_N28
\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\);

-- Location: LCCOMB_X40_Y35_N22
\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\);

-- Location: LCCOMB_X40_Y35_N28
\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(3),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\);

-- Location: LCCOMB_X41_Y35_N20
\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\);

-- Location: LCCOMB_X41_Y35_N14
\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\);

-- Location: LCCOMB_X40_Y35_N0
\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ = (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ = CARRY((\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~55_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[25]~54_combout\,
	datad => VCC,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\);

-- Location: LCCOMB_X40_Y35_N2
\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ & 
-- (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\)))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~53_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[26]~52_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~1\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\);

-- Location: LCCOMB_X40_Y35_N4
\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & (((\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\) 
-- # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\)))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((((\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\)))))
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\ & ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- (\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~51_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~3\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\);

-- Location: LCCOMB_X40_Y35_N6
\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\ 
-- & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~50_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[28]~62_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~5\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\);

-- Location: LCCOMB_X40_Y35_N8
\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ = \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[4]~7_cout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\);

-- Location: LCCOMB_X37_Y35_N30
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\ = !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\);

-- Location: LCCOMB_X37_Y35_N22
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[0]~14_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\);

-- Location: LCCOMB_X37_Y35_N16
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\);

-- Location: LCCOMB_X37_Y35_N0
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\ = (((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\)))
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ = CARRY((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000111101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\,
	datad => VCC,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\);

-- Location: LCCOMB_X37_Y35_N2
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ & (((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\) # 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\)))) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\ & (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ & 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\)))
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ = CARRY((!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\ & (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~3\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\);

-- Location: LCCOMB_X38_Y35_N28
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[6]~10_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\);

-- Location: LCCOMB_X38_Y35_N6
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\);

-- Location: LCCOMB_X38_Y35_N8
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[4]~6_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\);

-- Location: LCCOMB_X38_Y35_N2
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_3_result_int[4]~6_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\);

-- Location: LCCOMB_X38_Y35_N0
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\);

-- Location: LCCOMB_X38_Y35_N30
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\ & 
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_4_result_int[5]~8_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\);

-- Location: LCCOMB_X38_Y35_N10
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_6_result_int[7]~12_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\);

-- Location: LCCOMB_X37_Y35_N4
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & (((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\)))) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & ((((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\)))))
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\ = CARRY((!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000100001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~5\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\);

-- Location: LCCOMB_X37_Y35_N6
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\ = CARRY((!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\ & (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~3_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[51]~4_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~7\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\);

-- Location: LCCOMB_X37_Y35_N8
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\ = CARRY((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\) # 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[52]~2_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[4]~9_cout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\);

-- Location: LCCOMB_X37_Y35_N10
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\ = CARRY((!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[53]~1_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[5]~11_cout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\);

-- Location: LCCOMB_X37_Y35_N12
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\ = CARRY((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\) # 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[54]~0_combout\,
	datad => VCC,
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[6]~13_cout\,
	cout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\);

-- Location: LCCOMB_X37_Y35_N14
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ = !\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[7]~15_cout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\);

-- Location: LCCOMB_X37_Y35_N28
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\) # 
-- ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\)))) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & 
-- (((\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~7_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[2]~4_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[49]~8_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\);

-- Location: LCCOMB_X37_Y35_N18
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\) # 
-- ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\)))) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & 
-- (((\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110010101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~10_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[1]~2_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[48]~9_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\);

-- Location: LCCOMB_X37_Y35_N26
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\) # 
-- ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\)))) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & 
-- (((\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~5_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[3]~6_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[50]~6_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\);

-- Location: LCCOMB_X41_Y35_N22
\datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[3]~4_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\);

-- Location: LCCOMB_X40_Y35_N30
\datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\) # 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\ & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[27]~66_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[2]~2_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\);

-- Location: LCCOMB_X41_Y35_N26
\datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & (\datapth|total_timer|reg_tim|q\(3))) # (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datab => \datapth|total_timer|reg_tim|q\(3),
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[1]~0_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_5_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\);

-- Location: LCCOMB_X41_Y35_N24
\datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[2]~2_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\);

-- Location: LCCOMB_X41_Y35_N10
\datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\);

-- Location: LCCOMB_X41_Y35_N16
\datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\ & 
-- !\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[1]~0_combout\,
	datad => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\);

-- Location: LCCOMB_X41_Y35_N12
\datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\ = (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \datapth|total_timer|reg_tim|q\(1),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\);

-- Location: LCCOMB_X41_Y35_N18
\datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\ = (\datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\ & \datapth|total_timer|reg_tim|q\(1))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|add_sub_6_result_int[5]~8_combout\,
	datac => \datapth|total_timer|reg_tim|q\(1),
	combout => \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\);

-- Location: LCCOMB_X41_Y35_N0
\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\ = CARRY((\datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~61_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[30]~60_combout\,
	datad => VCC,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\);

-- Location: LCCOMB_X41_Y35_N2
\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\ 
-- & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~58_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[31]~59_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[1]~1_cout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\);

-- Location: LCCOMB_X41_Y35_N4
\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\ & 
-- ((\datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\) # (\datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~67_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[32]~57_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[2]~3_cout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\);

-- Location: LCCOMB_X41_Y35_N6
\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\ = CARRY((!\datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\ & (!\datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\ 
-- & !\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~56_combout\,
	datab => \datapth|display|Div1|auto_generated|divider|divider|StageOut[33]~63_combout\,
	datad => VCC,
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[3]~5_cout\,
	cout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\);

-- Location: LCCOMB_X41_Y35_N8
\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\ = \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[4]~7_cout\,
	combout => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\);

-- Location: LCCOMB_X37_Y35_N24
\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\ = !\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\);

-- Location: LCCOMB_X37_Y35_N20
\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & 
-- (!\datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\)) # (!\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\ & 
-- ((\datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[8]~16_combout\,
	datac => \datapth|display|Div1|auto_generated|divider|divider|add_sub_7_result_int[5]~8_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|add_sub_7_result_int[0]~0_combout\,
	combout => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\);

-- Location: LCCOMB_X37_Y37_N12
\datapth|display|Mux20~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux20~0_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ $ (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux20~0_combout\);

-- Location: LCCOMB_X38_Y37_N8
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\ = \datapth|total_timer|reg_tim|q\(3) $ (VCC)
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ = CARRY(\datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(3),
	datad => VCC,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\);

-- Location: LCCOMB_X38_Y37_N10
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\ = (\datapth|total_timer|reg_tim|q\(4) & (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\ & VCC)) # (!\datapth|total_timer|reg_tim|q\(4) 
-- & (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\))
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ = CARRY((!\datapth|total_timer|reg_tim|q\(4) & !\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100000101",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(4),
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~1\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\);

-- Location: LCCOMB_X38_Y37_N12
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\ = (\datapth|total_timer|reg_tim|q\(5) & ((GND) # (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\))) # 
-- (!\datapth|total_timer|reg_tim|q\(5) & (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\ $ (GND)))
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\ = CARRY((\datapth|total_timer|reg_tim|q\(5)) # (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110011001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(5),
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~3\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\);

-- Location: LCCOMB_X38_Y37_N14
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ = (\datapth|total_timer|reg_tim|q\(6) & (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\)) # (!\datapth|total_timer|reg_tim|q\(6) & 
-- ((\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\) # (GND)))
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ = CARRY((!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\) # (!\datapth|total_timer|reg_tim|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|total_timer|reg_tim|q\(6),
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~5\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\);

-- Location: LCCOMB_X38_Y37_N16
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ = (\datapth|total_timer|reg_tim|q\(7) & (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ $ (GND))) # 
-- (!\datapth|total_timer|reg_tim|q\(7) & (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\ & VCC))
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\ = CARRY((\datapth|total_timer|reg_tim|q\(7) & !\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapth|total_timer|reg_tim|q\(7),
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~7\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\);

-- Location: LCCOMB_X38_Y37_N18
\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ = !\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111100001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~9\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\);

-- Location: LCCOMB_X38_Y37_N28
\datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(7))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|total_timer|reg_tim|q\(7),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\);

-- Location: LCCOMB_X39_Y37_N4
\datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\ & 
-- !\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[6]~8_combout\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\);

-- Location: LCCOMB_X39_Y37_N10
\datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\ & 
-- !\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[5]~6_combout\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\);

-- Location: LCCOMB_X38_Y37_N6
\datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(6))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \datapth|total_timer|reg_tim|q\(6),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\);

-- Location: LCCOMB_X38_Y37_N0
\datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(5))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|total_timer|reg_tim|q\(5),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\);

-- Location: LCCOMB_X39_Y37_N28
\datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & 
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[4]~4_combout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\);

-- Location: LCCOMB_X39_Y37_N30
\datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & 
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[3]~2_combout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\);

-- Location: LCCOMB_X38_Y37_N22
\datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(4))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \datapth|total_timer|reg_tim|q\(4),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\);

-- Location: LCCOMB_X39_Y37_N12
\datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & 
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[2]~0_combout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\);

-- Location: LCCOMB_X38_Y37_N20
\datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(3))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \datapth|total_timer|reg_tim|q\(3),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\);

-- Location: LCCOMB_X38_Y37_N26
\datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\ = (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\);

-- Location: LCCOMB_X38_Y37_N4
\datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \datapth|total_timer|reg_tim|q\(2))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datad => \datapth|total_timer|reg_tim|q\(2),
	combout => \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\);

-- Location: LCCOMB_X39_Y37_N14
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\ = CARRY((\datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\) # (\datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~10_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[49]~11_combout\,
	datad => VCC,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\);

-- Location: LCCOMB_X39_Y37_N16
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\ = CARRY((!\datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\ & (!\datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\ & 
-- !\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~9_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[50]~8_combout\,
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[2]~1_cout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\);

-- Location: LCCOMB_X39_Y37_N18
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\ = CARRY((\datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\) # ((\datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\) # 
-- (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011101111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~7_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[51]~6_combout\,
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[3]~3_cout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\);

-- Location: LCCOMB_X39_Y37_N20
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ = CARRY(((!\datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\ & !\datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\)) 
-- # (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~4_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[52]~5_combout\,
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[4]~5_cout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\);

-- Location: LCCOMB_X39_Y37_N22
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\ = CARRY((!\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\ & 
-- ((\datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\) # (\datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~3_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[53]~2_combout\,
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[5]~7_cout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\);

-- Location: LCCOMB_X39_Y37_N24
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\ = CARRY((!\datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\ & (!\datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\ & 
-- !\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~0_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|StageOut[54]~1_combout\,
	datad => VCC,
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[6]~9_cout\,
	cout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\);

-- Location: LCCOMB_X39_Y37_N26
\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ = \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	cin => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[7]~11_cout\,
	combout => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\);

-- Location: LCCOMB_X37_Y37_N18
\datapth|display|s_dz~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|s_dz~0_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\ & (\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & 
-- (\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\ & !\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	combout => \datapth|display|s_dz~0_combout\);

-- Location: LCCOMB_X37_Y37_N28
\datapth|display|s_dz~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|s_dz~1_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & \datapth|display|s_dz~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \datapth|display|s_dz~0_combout\,
	combout => \datapth|display|s_dz~1_combout\);

-- Location: LCCOMB_X37_Y37_N22
\datapth|display|Mux20~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux20~1_combout\ = (!\datapth|display|Mux20~0_combout\ & (\controller|PS.S4~q\ & !\datapth|display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mux20~0_combout\,
	datab => \controller|PS.S4~q\,
	datad => \datapth|display|s_dz~1_combout\,
	combout => \datapth|display|Mux20~1_combout\);

-- Location: LCCOMB_X37_Y37_N0
\datapth|display|Mux19~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux19~0_combout\ = (\datapth|display|s_dz~1_combout\) # ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ $ 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100111011101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|s_dz~1_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux19~0_combout\);

-- Location: LCCOMB_X37_Y37_N10
\datapth|display|Mux19~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux19~1_combout\ = (\controller|PS.S4~q\ & !\datapth|display|Mux19~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datad => \datapth|display|Mux19~0_combout\,
	combout => \datapth|display|Mux19~1_combout\);

-- Location: LCCOMB_X37_Y37_N4
\datapth|display|Mux18~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux18~0_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux18~0_combout\);

-- Location: LCCOMB_X37_Y37_N6
\datapth|display|res:s_dz[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_dz[2]~0_combout\ = ((\datapth|display|Mux18~0_combout\) # (\datapth|display|s_dz~1_combout\)) # (!\controller|PS.S4~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datac => \datapth|display|Mux18~0_combout\,
	datad => \datapth|display|s_dz~1_combout\,
	combout => \datapth|display|res:s_dz[2]~0_combout\);

-- Location: LCCOMB_X37_Y37_N24
\datapth|display|Mux17~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux17~0_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ $ (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))) # (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux17~0_combout\);

-- Location: LCCOMB_X37_Y37_N14
\datapth|display|Mux17~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux17~1_combout\ = (\controller|PS.S4~q\ & (!\datapth|display|s_dz~1_combout\ & !\datapth|display|Mux17~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datac => \datapth|display|s_dz~1_combout\,
	datad => \datapth|display|Mux17~0_combout\,
	combout => \datapth|display|Mux17~1_combout\);

-- Location: LCCOMB_X37_Y37_N20
\datapth|display|Mux16~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux16~0_combout\ = (\datapth|display|s_dz~1_combout\) # ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\) # ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- !\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|s_dz~1_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux16~0_combout\);

-- Location: LCCOMB_X37_Y37_N2
\datapth|display|Mux16~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux16~1_combout\ = (\controller|PS.S4~q\ & !\datapth|display|Mux16~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datad => \datapth|display|Mux16~0_combout\,
	combout => \datapth|display|Mux16~1_combout\);

-- Location: LCCOMB_X37_Y37_N16
\datapth|display|Mux15~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux15~0_combout\ = (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\ & ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\ & \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\)) # (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\) # (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux15~0_combout\);

-- Location: LCCOMB_X37_Y37_N30
\datapth|display|Mux15~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux15~1_combout\ = (\controller|PS.S4~q\ & (!\datapth|display|Mux15~0_combout\ & !\datapth|display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datac => \datapth|display|Mux15~0_combout\,
	datad => \datapth|display|s_dz~1_combout\,
	combout => \datapth|display|Mux15~1_combout\);

-- Location: LCCOMB_X37_Y37_N8
\datapth|display|Mux14~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux14~0_combout\ = (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\) # ((\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- ((!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\) # (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\))) # (!\datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\ & 
-- (\datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111011011111110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[58]~13_combout\,
	datab => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[57]~12_combout\,
	datac => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[59]~14_combout\,
	datad => \datapth|display|Mod0|auto_generated|divider|divider|StageOut[56]~11_combout\,
	combout => \datapth|display|Mux14~0_combout\);

-- Location: LCCOMB_X37_Y37_N26
\datapth|display|Mux14~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|Mux14~1_combout\ = (\controller|PS.S4~q\ & (\datapth|display|Mux14~0_combout\ & !\datapth|display|s_dz~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \controller|PS.S4~q\,
	datac => \datapth|display|Mux14~0_combout\,
	datad => \datapth|display|s_dz~1_combout\,
	combout => \datapth|display|Mux14~1_combout\);

-- Location: LCCOMB_X32_Y36_N22
\datapth|display|res:s_c[0]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_c[0]~0_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & \controller|PS.S4~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \controller|PS.S4~q\,
	combout => \datapth|display|res:s_c[0]~0_combout\);

-- Location: LCCOMB_X32_Y36_N24
\datapth|display|res:s_c[0]~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_c[0]~1_combout\ = (\controller|PS.S4~q\ & ((!\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\) # (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	combout => \datapth|display|res:s_c[0]~1_combout\);

-- Location: LCCOMB_X32_Y36_N2
\datapth|display|res:s_c[2]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_c[2]~0_combout\ = (\controller|PS.S4~q\ & !\datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	combout => \datapth|display|res:s_c[2]~0_combout\);

-- Location: LCCOMB_X32_Y36_N0
\datapth|display|res:s_c[4]~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapth|display|res:s_c[4]~0_combout\ = (!\datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\ & (\controller|PS.S4~q\ & \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapth|display|Div0|auto_generated|divider|divider|add_sub_6_result_int[7]~10_combout\,
	datac => \controller|PS.S4~q\,
	datad => \datapth|display|Div0|auto_generated|divider|divider|add_sub_7_result_int[8]~12_combout\,
	combout => \datapth|display|res:s_c[4]~0_combout\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_RS(0) <= \RS[0]~output_o\;

ww_RS(1) <= \RS[1]~output_o\;

ww_RS(2) <= \RS[2]~output_o\;

ww_RS(3) <= \RS[3]~output_o\;

ww_RS(4) <= \RS[4]~output_o\;

ww_RS(5) <= \RS[5]~output_o\;

ww_RS(6) <= \RS[6]~output_o\;

ww_RS(7) <= \RS[7]~output_o\;

ww_RS(8) <= \RS[8]~output_o\;

ww_RS(9) <= \RS[9]~output_o\;

ww_u(0) <= \u[0]~output_o\;

ww_u(1) <= \u[1]~output_o\;

ww_u(2) <= \u[2]~output_o\;

ww_u(3) <= \u[3]~output_o\;

ww_u(4) <= \u[4]~output_o\;

ww_u(5) <= \u[5]~output_o\;

ww_u(6) <= \u[6]~output_o\;

ww_dz(0) <= \dz[0]~output_o\;

ww_dz(1) <= \dz[1]~output_o\;

ww_dz(2) <= \dz[2]~output_o\;

ww_dz(3) <= \dz[3]~output_o\;

ww_dz(4) <= \dz[4]~output_o\;

ww_dz(5) <= \dz[5]~output_o\;

ww_dz(6) <= \dz[6]~output_o\;

ww_c(0) <= \c[0]~output_o\;

ww_c(1) <= \c[1]~output_o\;

ww_c(2) <= \c[2]~output_o\;

ww_c(3) <= \c[3]~output_o\;

ww_c(4) <= \c[4]~output_o\;

ww_c(5) <= \c[5]~output_o\;

ww_c(6) <= \c[6]~output_o\;
END structure;


