library IEEE;
use ieee.std_logic_1164.all;

entity flip_flop_d is
	port(
		i, ld, clr, clock : in std_logic;
		q : out std_logic 
		);
end flip_flop_d;

architecture arch of flip_flop_d is 
begin 
	process(clock, clr)
	begin 
	if clr = '1' then 
		q <= '0';
	elsif rising_edge(clock) and ld = '1' then 
		q <= i;
	end if; 
end process;
end arch;

		
