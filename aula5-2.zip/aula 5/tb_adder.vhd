library IEEE;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_adder is
end tb_adder;

architecture arch of tb_adder is

	component adder is
	generic(
		W : natural := 4
		);
	port(
		a, b : in std_logic_vector( W-1 downto 0 );
		sum : out std_logic_vector(W-1 downto 0);
		cout : out std_logic
		);
	end component;

	signal a_tb : std_logic_vector(3 downto 0) := "0000";
	signal b_tb : std_logic_vector(3 downto 0) := "0000";
	signal sum_tb : std_logic_vector(3 downto 0);
	signal cout_tb : std_logic;
	
begin 
	dut: adder
	generic map(
		W => 4
		)
	port map(
		a => a_tb,
		b => b_tb,
		sum => sum_tb,
		cout => cout_tb
		);
		
	stimulus: process
	begin
	
	a_tb <= "0000";
	b_tb <= "0000";
	
	wait for 10 ns;
	
	a_tb <= "0001";
	b_tb <= "0000";
	
	wait for 10 ns;
	
	a_tb <= "0001";
	b_tb <= "0001";
	
	wait for 10 ns;
	
	a_tb <= "0011";
	b_tb <= "0010";
	
	wait for 10 ns;
	
	a_tb <= "0011";
	b_tb <= "0110";
	
	wait for 10 ns;
	
	a_tb <= "1111";
	b_tb <= "0001";
	
	wait for 10 ns;
	
	a_tb <= "1111";
	b_tb <= "1111";
	
	wait for 10 ns;
	
	wait;
	end process;
end;
	
	
	
	