library IEEE;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity adder is
generic (W : positive := 4);
port(
	a, b : in std_logic_vector( W-1 downto 0 );
	sum : out std_logic_vector(W-1 downto 0);
	cout : out std_logic
	);
end adder;

architecture arch of adder is
	signal aux : std_logic_vector( W-1 downto 0);
begin
	aux <= std_logic_vector(
	(unsigned(a)) +
	(unsigned(b))
	);
	cout <= '1' when ((unsigned(a) + unsigned(b)) > unsigned(aux)) else '0';  
	sum <= aux;
end arch;


	