library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Entity declaration
entity tb_soda_selector is
end tb_soda_selector;

-- Architecture declaration
architecture test of tb_soda_selector is

	-- Component declaration
	component soda_selector is
		port(
			r : in std_logic_vector(1 downto 0);
			s : out std_logic_vector(7 downto 0)
		);
	end component;

	signal pin_r : std_logic_vector(1 downto 0);
	signal pin_s : std_logic_vector(7 downto 0);

begin

	-- Instantiate the design under test
	dut: soda_selector
		port map(
			r  => pin_r,
			s  => pin_s
			);

	-- Stimulus generation
	stim_proc: process
	begin
		pin_r <= "00";
		wait for 20 ns;
		pin_r <= "01";
		wait for 20 ns;
		pin_r <= "10";
		wait for 20 ns;
		pin_r <= "11";
		wait for 20 ns;
		pin_r <= "ZZ";
		wait for 20 ns;
		wait;
	end process;

end test;