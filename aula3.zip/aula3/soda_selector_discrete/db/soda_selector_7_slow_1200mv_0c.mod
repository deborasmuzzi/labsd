


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___6.972__delay:		DELAY  6.972 ;
___6.922__delay:		DELAY  6.922 ;
_7.332__delay:		DELAY 7.332  ;
_7.277__delay:		DELAY 7.277  ;
___6.416__delay:		DELAY  6.416 ;

ENDMODEL
