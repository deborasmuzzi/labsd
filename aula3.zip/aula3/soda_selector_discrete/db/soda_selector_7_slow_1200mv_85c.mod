


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___7.677__delay:		DELAY  7.677 ;
___7.623__delay:		DELAY  7.623 ;
_8.056__delay:		DELAY 8.056  ;
_8.003__delay:		DELAY 8.003  ;
___7.055__delay:		DELAY  7.055 ;

ENDMODEL
