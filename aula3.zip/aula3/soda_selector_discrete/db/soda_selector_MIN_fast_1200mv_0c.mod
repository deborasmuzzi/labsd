


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___3.830__delay:		DELAY  3.830 ;
___3.808__delay:		DELAY  3.808 ;
_3.941__delay:		DELAY 3.941  ;
_3.919__delay:		DELAY 3.919  ;
___3.608__delay:		DELAY  3.608 ;

ENDMODEL
