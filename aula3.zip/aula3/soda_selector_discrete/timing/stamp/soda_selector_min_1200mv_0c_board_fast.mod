/*
 Copyright (C) 2020  Intel Corporation. All rights reserved.
 Your use of Intel Corporation's design tools, logic functions 
 and other software and tools, and any partner logic 
 functions, and any output files from any of the foregoing 
 (including device programming or simulation files), and any 
 associated documentation or information are expressly subject 
 to the terms and conditions of the Intel Program License 
 Subscription Agreement, the Intel Quartus Prime License Agreement,
 the Intel FPGA IP License Agreement, or other applicable license
 agreement, including, without limitation, that your use is for
 the sole purpose of programming logic devices manufactured by
 Intel and sold by Intel or its authorized distributors.  Please
 refer to the applicable agreement for further details, at
 https://fpgasoftware.intel.com/eula.
*/
MODEL
/*MODEL HEADER*/
/*
 This file contains Fast Corner delays for the design using part 10M50DAF484C7G
 with speed grade M, core voltage 1.2V, and temperature 0 Celsius

*/
MODEL_VERSION "1.0";
DESIGN "soda_selector";
DATE "08/25/2026 18:27:07";
PROGRAM "Quartus Prime";



INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___3.830__delay:		DELAY  3.830 ;
___3.808__delay:		DELAY  3.808 ;
_3.941__delay:		DELAY 3.941  ;
_3.919__delay:		DELAY 3.919  ;
___3.608__delay:		DELAY  3.608 ;

ENDMODEL
