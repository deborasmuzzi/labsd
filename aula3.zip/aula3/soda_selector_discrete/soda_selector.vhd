library ieee;
use ieee.std_logic_1164.all;

entity soda_selector is
	port(
				r : in std_logic_vector(1 downto 0);
				s : out std_logic_vector(7 downto 0)
				);
end soda_selector;

architecture arch of soda_selector is
begin

		s(0) <= ((not r(1)) and r(0));
		s(1) <= (((not r(1)) and (not r(0))) or ((not r(1)) and r(0)) or (r(1) and r(0)));
		s(2) <= ((r(1) and (not r(0))) or (r(1) and r(0)));
		s(3) <= '1';
		s(7 downto 4) <= "0000";
		
end arch;