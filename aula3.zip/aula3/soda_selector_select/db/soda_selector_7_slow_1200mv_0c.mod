


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___7.089__delay:		DELAY  7.089 ;
___7.073__delay:		DELAY  7.073 ;
_7.398__delay:		DELAY 7.398  ;
_7.384__delay:		DELAY 7.384  ;
___6.547__delay:		DELAY  6.547 ;

ENDMODEL
