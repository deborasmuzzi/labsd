


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___7.809__delay:		DELAY  7.809 ;
___7.793__delay:		DELAY  7.793 ;
_8.153__delay:		DELAY 8.153  ;
_8.138__delay:		DELAY 8.138  ;
___7.207__delay:		DELAY  7.207 ;

ENDMODEL
