


INPUT r[0];
INPUT r[1];
OUTPUT s[0];
OUTPUT s[1];
OUTPUT s[2];
OUTPUT s[3];
OUTPUT s[4];
OUTPUT s[5];
OUTPUT s[6];
OUTPUT s[7];

/*Arc definitions start here*/
___3.933__delay:		DELAY  3.933 ;
___3.920__delay:		DELAY  3.920 ;
_4.004__delay:		DELAY 4.004  ;
_3.992__delay:		DELAY 3.992  ;
___3.643__delay:		DELAY  3.643 ;

ENDMODEL
