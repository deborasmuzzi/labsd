library ieee;
use ieee.std_logic_1164.all;

entity soda_selector is
	port(
				r : in std_logic_vector(1 downto 0);
				s : out std_logic_vector(7 downto 0)
				);
end soda_selector;

--architecture arch of soda_selector is
--begin
--
--		s(0) <= ((not a(1)) and a(0));
--		s(1) <= (((not a(1)) and (not a(0))) or ((not a(1)) and a(0)) or (a(1) and a(0)));
--		s(2) <= ((a(1) and (not a(0))) or (a(1) and a(0)));
--		s(3) <= '1';
--		s(7 downto 4) <= "0000";
--		
--end arch;

architecture arch of soda_selector is
begin

		with r select
		s <= "00001010" when "00",
			  "00001011" when "01",
			  "00001100" when "10",
			  "00001110" when "11",
			  "00000000" when others;
end arch;
