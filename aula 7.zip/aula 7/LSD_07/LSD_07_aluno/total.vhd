-- Laboratório de Sistemas Digitais
-- Universidade Federal de Minas Gerais
-- Julho de 2026
--
-- Arquivo: total.vhd
-- Registrador

-- Inclusão de bibliotecas
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

-- declaração da interface da entity
entity total is
	PORT(	clk, ld, clr	: in 	STD_LOGIC;
			I					: in 	STD_LOGIC_VECTOR(7 downto 0); 
			Q					: out	STD_LOGIC_VECTOR(7 downto 0)
	);
end;


architecture bhv of total is
	
	
	component clock_div is
		port (
			clock : in std_logic;
			clock_mod : out std_logic
			);
	end component clock_div;
	
	signal sig_clk : std_logic;
	signal sig_clock_div : std_logic;

begin
dut: clock_div
		
		port map(
			clock  => sig_clk,
			clock_mod  => sig_clock_div
			);		
		
		
		sig_clk <= clk;

	process(sig_clock_div, clr)
	begin
	
		if clr = '0' then	Q <= (others => '0');
		elsif rising_edge(sig_clock_div) then
			if ld  = '0' then Q <= I;
			end if;
		end if;	
		
	end process;
end;