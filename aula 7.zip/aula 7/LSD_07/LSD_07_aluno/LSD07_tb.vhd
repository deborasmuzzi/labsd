library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity LSD07_tb is
end LSD07_tb;

architecture arch of LSD07_tb is 
	component LSD07 is
		PORT( clk, tot_ld, tot_clr	: in  STD_LOGIC;
			A 									: in  STD_LOGIC_VECTOR(2 downto 0);
			tot_coins						: out STD_LOGIC_VECTOR(9 downto 0)
	);	
	end component; 
		
	signal ld_tb, clr_tb  : std_logic;
	signal A_tb : std_logic_vector(2 downto 0);
	signal Tot_coins_tb : std_logic_vector(9 downto 0);
	signal my_clock: std_logic := '0';
	
begin
	dut: LSD07
	port map (
		tot_ld =>ld_tb,
		tot_clr => clr_tb,
		clk => my_clock,
		A => A_tb,
		tot_coins => Tot_coins_tb
	);

	
	my_clock <= not my_clock after 5 ns;

	stimulus : process
	begin
--		clr_tb <= '0';
--		i_tb <= "000";
--		ld_tb <= '1';
--		wait for 6 ns;
--		clr_tb <= '1';
--		wait for 10 ns;
--		clr_tb <= '0';
--		ld_tb <= '1';
--		i_tb <= x"A5";
--		wait for 10 ns;
--		ld_tb <= '0';
--		i_tb <= x"3C";
--		wait for 10 ns;
--		ld_tb<= '1';
--		wait for 10 ns;
--		clr_tb <= '1';
--		wait for 10 ns;
--		i_tb <= x"4B";
--		wait for 10 ns;
--		
		wait;
		end process;
end;
	