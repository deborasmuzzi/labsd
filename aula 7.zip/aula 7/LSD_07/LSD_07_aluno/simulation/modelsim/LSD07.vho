-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.0 Build 711 06/05/2020 SJ Lite Edition"

-- DATE "09/22/2026 18:37:55"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	LSD07 IS
    PORT (
	clk : IN std_logic;
	tot_ld : IN std_logic;
	tot_clr : IN std_logic;
	A : IN std_logic_vector(2 DOWNTO 0);
	tot_coins : BUFFER std_logic_vector(9 DOWNTO 0)
	);
END LSD07;

-- Design Ports Information
-- tot_coins[0]	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[1]	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[2]	=>  Location: PIN_D14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[3]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[4]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[5]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[6]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[7]	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[8]	=>  Location: PIN_A9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[9]	=>  Location: PIN_A8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[0]	=>  Location: PIN_C10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_clr	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_ld	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[1]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[2]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_P11,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF LSD07 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_tot_ld : std_logic;
SIGNAL ww_tot_clr : std_logic;
SIGNAL ww_A : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_tot_coins : std_logic_vector(9 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \total|dut|clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \tot_coins[0]~output_o\ : std_logic;
SIGNAL \tot_coins[1]~output_o\ : std_logic;
SIGNAL \tot_coins[2]~output_o\ : std_logic;
SIGNAL \tot_coins[3]~output_o\ : std_logic;
SIGNAL \tot_coins[4]~output_o\ : std_logic;
SIGNAL \tot_coins[5]~output_o\ : std_logic;
SIGNAL \tot_coins[6]~output_o\ : std_logic;
SIGNAL \tot_coins[7]~output_o\ : std_logic;
SIGNAL \tot_coins[8]~output_o\ : std_logic;
SIGNAL \tot_coins[9]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \total|dut|Add0~0_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[0]~q\ : std_logic;
SIGNAL \total|dut|Add0~1\ : std_logic;
SIGNAL \total|dut|Add0~2_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[1]~q\ : std_logic;
SIGNAL \total|dut|Add0~3\ : std_logic;
SIGNAL \total|dut|Add0~4_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[2]~q\ : std_logic;
SIGNAL \total|dut|Add0~5\ : std_logic;
SIGNAL \total|dut|Add0~6_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[3]~q\ : std_logic;
SIGNAL \total|dut|Add0~7\ : std_logic;
SIGNAL \total|dut|Add0~8_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[4]~q\ : std_logic;
SIGNAL \total|dut|Add0~9\ : std_logic;
SIGNAL \total|dut|Add0~10_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[5]~q\ : std_logic;
SIGNAL \total|dut|Add0~11\ : std_logic;
SIGNAL \total|dut|Add0~12_combout\ : std_logic;
SIGNAL \total|dut|count_var~1_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[6]~q\ : std_logic;
SIGNAL \total|dut|Add0~13\ : std_logic;
SIGNAL \total|dut|Add0~14_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[7]~q\ : std_logic;
SIGNAL \total|dut|Add0~15\ : std_logic;
SIGNAL \total|dut|Add0~16_combout\ : std_logic;
SIGNAL \total|dut|count_var~0_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[8]~q\ : std_logic;
SIGNAL \total|dut|Add0~17\ : std_logic;
SIGNAL \total|dut|Add0~18_combout\ : std_logic;
SIGNAL \total|dut|count_var~2_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[9]~q\ : std_logic;
SIGNAL \total|dut|Add0~19\ : std_logic;
SIGNAL \total|dut|Add0~20_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[10]~q\ : std_logic;
SIGNAL \total|dut|Add0~21\ : std_logic;
SIGNAL \total|dut|Add0~22_combout\ : std_logic;
SIGNAL \total|dut|count_var~3_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[11]~q\ : std_logic;
SIGNAL \total|dut|Add0~23\ : std_logic;
SIGNAL \total|dut|Add0~24_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[12]~q\ : std_logic;
SIGNAL \total|dut|Add0~25\ : std_logic;
SIGNAL \total|dut|Add0~26_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[13]~q\ : std_logic;
SIGNAL \total|dut|Add0~27\ : std_logic;
SIGNAL \total|dut|Add0~28_combout\ : std_logic;
SIGNAL \total|dut|count_var~4_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[14]~q\ : std_logic;
SIGNAL \total|dut|Add0~29\ : std_logic;
SIGNAL \total|dut|Add0~30_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[15]~q\ : std_logic;
SIGNAL \total|dut|Equal0~3_combout\ : std_logic;
SIGNAL \total|dut|Equal0~1_combout\ : std_logic;
SIGNAL \total|dut|Equal0~2_combout\ : std_logic;
SIGNAL \total|dut|Equal0~0_combout\ : std_logic;
SIGNAL \total|dut|Equal0~4_combout\ : std_logic;
SIGNAL \total|dut|Add0~31\ : std_logic;
SIGNAL \total|dut|Add0~32_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[16]~q\ : std_logic;
SIGNAL \total|dut|Add0~33\ : std_logic;
SIGNAL \total|dut|Add0~34_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[17]~q\ : std_logic;
SIGNAL \total|dut|Add0~35\ : std_logic;
SIGNAL \total|dut|Add0~36_combout\ : std_logic;
SIGNAL \total|dut|count_var~5_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[18]~q\ : std_logic;
SIGNAL \total|dut|Add0~37\ : std_logic;
SIGNAL \total|dut|Add0~38_combout\ : std_logic;
SIGNAL \total|dut|count_var~6_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[19]~q\ : std_logic;
SIGNAL \total|dut|Add0~39\ : std_logic;
SIGNAL \total|dut|Add0~40_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[20]~q\ : std_logic;
SIGNAL \total|dut|Add0~41\ : std_logic;
SIGNAL \total|dut|Add0~42_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[21]~q\ : std_logic;
SIGNAL \total|dut|Add0~43\ : std_logic;
SIGNAL \total|dut|Add0~44_combout\ : std_logic;
SIGNAL \total|dut|count_var~7_combout\ : std_logic;
SIGNAL \total|dut|clock_div_process:count_var[22]~q\ : std_logic;
SIGNAL \total|dut|Equal0~5_combout\ : std_logic;
SIGNAL \total|dut|Equal0~6_combout\ : std_logic;
SIGNAL \total|dut|clk~0_combout\ : std_logic;
SIGNAL \total|dut|clk~feeder_combout\ : std_logic;
SIGNAL \total|dut|clk~q\ : std_logic;
SIGNAL \total|dut|clk~clkctrl_outclk\ : std_logic;
SIGNAL \A[0]~input_o\ : std_logic;
SIGNAL \total|Q[0]~8_combout\ : std_logic;
SIGNAL \tot_clr~input_o\ : std_logic;
SIGNAL \tot_ld~input_o\ : std_logic;
SIGNAL \A[1]~input_o\ : std_logic;
SIGNAL \total|Q[0]~9\ : std_logic;
SIGNAL \total|Q[1]~10_combout\ : std_logic;
SIGNAL \A[2]~input_o\ : std_logic;
SIGNAL \total|Q[1]~11\ : std_logic;
SIGNAL \total|Q[2]~12_combout\ : std_logic;
SIGNAL \total|Q[2]~13\ : std_logic;
SIGNAL \total|Q[3]~14_combout\ : std_logic;
SIGNAL \total|Q[3]~15\ : std_logic;
SIGNAL \total|Q[4]~16_combout\ : std_logic;
SIGNAL \total|Q[4]~17\ : std_logic;
SIGNAL \total|Q[5]~18_combout\ : std_logic;
SIGNAL \total|Q[5]~19\ : std_logic;
SIGNAL \total|Q[6]~20_combout\ : std_logic;
SIGNAL \total|Q[6]~21\ : std_logic;
SIGNAL \total|Q[7]~22_combout\ : std_logic;
SIGNAL \total|Q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \ALT_INV_tot_ld~input_o\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_clk <= clk;
ww_tot_ld <= tot_ld;
ww_tot_clr <= tot_clr;
ww_A <= A;
tot_coins <= ww_tot_coins;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\total|dut|clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \total|dut|clk~q\);

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\ALT_INV_tot_ld~input_o\ <= NOT \tot_ld~input_o\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y52_N4
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X49_Y54_N9
\tot_coins[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(0),
	devoe => ww_devoe,
	o => \tot_coins[0]~output_o\);

-- Location: IOOBUF_X51_Y54_N9
\tot_coins[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(1),
	devoe => ww_devoe,
	o => \tot_coins[1]~output_o\);

-- Location: IOOBUF_X56_Y54_N9
\tot_coins[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(2),
	devoe => ww_devoe,
	o => \tot_coins[2]~output_o\);

-- Location: IOOBUF_X66_Y54_N23
\tot_coins[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(3),
	devoe => ww_devoe,
	o => \tot_coins[3]~output_o\);

-- Location: IOOBUF_X58_Y54_N23
\tot_coins[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(4),
	devoe => ww_devoe,
	o => \tot_coins[4]~output_o\);

-- Location: IOOBUF_X56_Y54_N30
\tot_coins[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(5),
	devoe => ww_devoe,
	o => \tot_coins[5]~output_o\);

-- Location: IOOBUF_X46_Y54_N9
\tot_coins[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(6),
	devoe => ww_devoe,
	o => \tot_coins[6]~output_o\);

-- Location: IOOBUF_X51_Y54_N16
\tot_coins[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|Q\(7),
	devoe => ww_devoe,
	o => \tot_coins[7]~output_o\);

-- Location: IOOBUF_X46_Y54_N23
\tot_coins[8]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \tot_coins[8]~output_o\);

-- Location: IOOBUF_X46_Y54_N2
\tot_coins[9]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => GND,
	devoe => ww_devoe,
	o => \tot_coins[9]~output_o\);

-- Location: IOIBUF_X34_Y0_N29
\clk~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G19
\clk~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X46_Y2_N10
\total|dut|Add0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~0_combout\ = \total|dut|clock_div_process:count_var[0]~q\ $ (VCC)
-- \total|dut|Add0~1\ = CARRY(\total|dut|clock_div_process:count_var[0]~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[0]~q\,
	datad => VCC,
	combout => \total|dut|Add0~0_combout\,
	cout => \total|dut|Add0~1\);

-- Location: FF_X46_Y2_N11
\total|dut|clock_div_process:count_var[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[0]~q\);

-- Location: LCCOMB_X46_Y2_N12
\total|dut|Add0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~2_combout\ = (\total|dut|clock_div_process:count_var[1]~q\ & (!\total|dut|Add0~1\)) # (!\total|dut|clock_div_process:count_var[1]~q\ & ((\total|dut|Add0~1\) # (GND)))
-- \total|dut|Add0~3\ = CARRY((!\total|dut|Add0~1\) # (!\total|dut|clock_div_process:count_var[1]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[1]~q\,
	datad => VCC,
	cin => \total|dut|Add0~1\,
	combout => \total|dut|Add0~2_combout\,
	cout => \total|dut|Add0~3\);

-- Location: FF_X46_Y2_N13
\total|dut|clock_div_process:count_var[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[1]~q\);

-- Location: LCCOMB_X46_Y2_N14
\total|dut|Add0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~4_combout\ = (\total|dut|clock_div_process:count_var[2]~q\ & (\total|dut|Add0~3\ $ (GND))) # (!\total|dut|clock_div_process:count_var[2]~q\ & (!\total|dut|Add0~3\ & VCC))
-- \total|dut|Add0~5\ = CARRY((\total|dut|clock_div_process:count_var[2]~q\ & !\total|dut|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[2]~q\,
	datad => VCC,
	cin => \total|dut|Add0~3\,
	combout => \total|dut|Add0~4_combout\,
	cout => \total|dut|Add0~5\);

-- Location: FF_X46_Y2_N15
\total|dut|clock_div_process:count_var[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[2]~q\);

-- Location: LCCOMB_X46_Y2_N16
\total|dut|Add0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~6_combout\ = (\total|dut|clock_div_process:count_var[3]~q\ & (!\total|dut|Add0~5\)) # (!\total|dut|clock_div_process:count_var[3]~q\ & ((\total|dut|Add0~5\) # (GND)))
-- \total|dut|Add0~7\ = CARRY((!\total|dut|Add0~5\) # (!\total|dut|clock_div_process:count_var[3]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[3]~q\,
	datad => VCC,
	cin => \total|dut|Add0~5\,
	combout => \total|dut|Add0~6_combout\,
	cout => \total|dut|Add0~7\);

-- Location: FF_X46_Y2_N17
\total|dut|clock_div_process:count_var[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[3]~q\);

-- Location: LCCOMB_X46_Y2_N18
\total|dut|Add0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~8_combout\ = (\total|dut|clock_div_process:count_var[4]~q\ & (\total|dut|Add0~7\ $ (GND))) # (!\total|dut|clock_div_process:count_var[4]~q\ & (!\total|dut|Add0~7\ & VCC))
-- \total|dut|Add0~9\ = CARRY((\total|dut|clock_div_process:count_var[4]~q\ & !\total|dut|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[4]~q\,
	datad => VCC,
	cin => \total|dut|Add0~7\,
	combout => \total|dut|Add0~8_combout\,
	cout => \total|dut|Add0~9\);

-- Location: FF_X46_Y2_N19
\total|dut|clock_div_process:count_var[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[4]~q\);

-- Location: LCCOMB_X46_Y2_N20
\total|dut|Add0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~10_combout\ = (\total|dut|clock_div_process:count_var[5]~q\ & (!\total|dut|Add0~9\)) # (!\total|dut|clock_div_process:count_var[5]~q\ & ((\total|dut|Add0~9\) # (GND)))
-- \total|dut|Add0~11\ = CARRY((!\total|dut|Add0~9\) # (!\total|dut|clock_div_process:count_var[5]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[5]~q\,
	datad => VCC,
	cin => \total|dut|Add0~9\,
	combout => \total|dut|Add0~10_combout\,
	cout => \total|dut|Add0~11\);

-- Location: FF_X46_Y2_N21
\total|dut|clock_div_process:count_var[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[5]~q\);

-- Location: LCCOMB_X46_Y2_N22
\total|dut|Add0~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~12_combout\ = (\total|dut|clock_div_process:count_var[6]~q\ & (\total|dut|Add0~11\ $ (GND))) # (!\total|dut|clock_div_process:count_var[6]~q\ & (!\total|dut|Add0~11\ & VCC))
-- \total|dut|Add0~13\ = CARRY((\total|dut|clock_div_process:count_var[6]~q\ & !\total|dut|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[6]~q\,
	datad => VCC,
	cin => \total|dut|Add0~11\,
	combout => \total|dut|Add0~12_combout\,
	cout => \total|dut|Add0~13\);

-- Location: LCCOMB_X46_Y2_N6
\total|dut|count_var~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~1_combout\ = (\total|dut|Add0~12_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001010101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Add0~12_combout\,
	datab => \total|dut|Equal0~6_combout\,
	datad => \total|dut|Equal0~4_combout\,
	combout => \total|dut|count_var~1_combout\);

-- Location: FF_X46_Y2_N7
\total|dut|clock_div_process:count_var[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[6]~q\);

-- Location: LCCOMB_X46_Y2_N24
\total|dut|Add0~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~14_combout\ = (\total|dut|clock_div_process:count_var[7]~q\ & (!\total|dut|Add0~13\)) # (!\total|dut|clock_div_process:count_var[7]~q\ & ((\total|dut|Add0~13\) # (GND)))
-- \total|dut|Add0~15\ = CARRY((!\total|dut|Add0~13\) # (!\total|dut|clock_div_process:count_var[7]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[7]~q\,
	datad => VCC,
	cin => \total|dut|Add0~13\,
	combout => \total|dut|Add0~14_combout\,
	cout => \total|dut|Add0~15\);

-- Location: FF_X46_Y2_N25
\total|dut|clock_div_process:count_var[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[7]~q\);

-- Location: LCCOMB_X46_Y2_N26
\total|dut|Add0~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~16_combout\ = (\total|dut|clock_div_process:count_var[8]~q\ & (\total|dut|Add0~15\ $ (GND))) # (!\total|dut|clock_div_process:count_var[8]~q\ & (!\total|dut|Add0~15\ & VCC))
-- \total|dut|Add0~17\ = CARRY((\total|dut|clock_div_process:count_var[8]~q\ & !\total|dut|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[8]~q\,
	datad => VCC,
	cin => \total|dut|Add0~15\,
	combout => \total|dut|Add0~16_combout\,
	cout => \total|dut|Add0~17\);

-- Location: LCCOMB_X46_Y2_N4
\total|dut|count_var~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~0_combout\ = (\total|dut|Add0~16_combout\ & ((!\total|dut|Equal0~6_combout\) # (!\total|dut|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~4_combout\,
	datab => \total|dut|Equal0~6_combout\,
	datad => \total|dut|Add0~16_combout\,
	combout => \total|dut|count_var~0_combout\);

-- Location: FF_X46_Y2_N5
\total|dut|clock_div_process:count_var[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[8]~q\);

-- Location: LCCOMB_X46_Y2_N28
\total|dut|Add0~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~18_combout\ = (\total|dut|clock_div_process:count_var[9]~q\ & (!\total|dut|Add0~17\)) # (!\total|dut|clock_div_process:count_var[9]~q\ & ((\total|dut|Add0~17\) # (GND)))
-- \total|dut|Add0~19\ = CARRY((!\total|dut|Add0~17\) # (!\total|dut|clock_div_process:count_var[9]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[9]~q\,
	datad => VCC,
	cin => \total|dut|Add0~17\,
	combout => \total|dut|Add0~18_combout\,
	cout => \total|dut|Add0~19\);

-- Location: LCCOMB_X46_Y2_N0
\total|dut|count_var~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~2_combout\ = (\total|dut|Add0~18_combout\ & ((!\total|dut|Equal0~6_combout\) # (!\total|dut|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~4_combout\,
	datab => \total|dut|Equal0~6_combout\,
	datad => \total|dut|Add0~18_combout\,
	combout => \total|dut|count_var~2_combout\);

-- Location: FF_X46_Y2_N1
\total|dut|clock_div_process:count_var[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[9]~q\);

-- Location: LCCOMB_X46_Y2_N30
\total|dut|Add0~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~20_combout\ = (\total|dut|clock_div_process:count_var[10]~q\ & (\total|dut|Add0~19\ $ (GND))) # (!\total|dut|clock_div_process:count_var[10]~q\ & (!\total|dut|Add0~19\ & VCC))
-- \total|dut|Add0~21\ = CARRY((\total|dut|clock_div_process:count_var[10]~q\ & !\total|dut|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[10]~q\,
	datad => VCC,
	cin => \total|dut|Add0~19\,
	combout => \total|dut|Add0~20_combout\,
	cout => \total|dut|Add0~21\);

-- Location: FF_X46_Y2_N31
\total|dut|clock_div_process:count_var[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[10]~q\);

-- Location: LCCOMB_X46_Y1_N0
\total|dut|Add0~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~22_combout\ = (\total|dut|clock_div_process:count_var[11]~q\ & (!\total|dut|Add0~21\)) # (!\total|dut|clock_div_process:count_var[11]~q\ & ((\total|dut|Add0~21\) # (GND)))
-- \total|dut|Add0~23\ = CARRY((!\total|dut|Add0~21\) # (!\total|dut|clock_div_process:count_var[11]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[11]~q\,
	datad => VCC,
	cin => \total|dut|Add0~21\,
	combout => \total|dut|Add0~22_combout\,
	cout => \total|dut|Add0~23\);

-- Location: LCCOMB_X45_Y1_N26
\total|dut|count_var~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~3_combout\ = (\total|dut|Add0~22_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|Add0~22_combout\,
	datad => \total|dut|Equal0~4_combout\,
	combout => \total|dut|count_var~3_combout\);

-- Location: FF_X45_Y1_N27
\total|dut|clock_div_process:count_var[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[11]~q\);

-- Location: LCCOMB_X46_Y1_N2
\total|dut|Add0~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~24_combout\ = (\total|dut|clock_div_process:count_var[12]~q\ & (\total|dut|Add0~23\ $ (GND))) # (!\total|dut|clock_div_process:count_var[12]~q\ & (!\total|dut|Add0~23\ & VCC))
-- \total|dut|Add0~25\ = CARRY((\total|dut|clock_div_process:count_var[12]~q\ & !\total|dut|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[12]~q\,
	datad => VCC,
	cin => \total|dut|Add0~23\,
	combout => \total|dut|Add0~24_combout\,
	cout => \total|dut|Add0~25\);

-- Location: FF_X46_Y1_N3
\total|dut|clock_div_process:count_var[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~24_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[12]~q\);

-- Location: LCCOMB_X46_Y1_N4
\total|dut|Add0~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~26_combout\ = (\total|dut|clock_div_process:count_var[13]~q\ & (!\total|dut|Add0~25\)) # (!\total|dut|clock_div_process:count_var[13]~q\ & ((\total|dut|Add0~25\) # (GND)))
-- \total|dut|Add0~27\ = CARRY((!\total|dut|Add0~25\) # (!\total|dut|clock_div_process:count_var[13]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[13]~q\,
	datad => VCC,
	cin => \total|dut|Add0~25\,
	combout => \total|dut|Add0~26_combout\,
	cout => \total|dut|Add0~27\);

-- Location: FF_X46_Y1_N5
\total|dut|clock_div_process:count_var[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~26_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[13]~q\);

-- Location: LCCOMB_X46_Y1_N6
\total|dut|Add0~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~28_combout\ = (\total|dut|clock_div_process:count_var[14]~q\ & (\total|dut|Add0~27\ $ (GND))) # (!\total|dut|clock_div_process:count_var[14]~q\ & (!\total|dut|Add0~27\ & VCC))
-- \total|dut|Add0~29\ = CARRY((\total|dut|clock_div_process:count_var[14]~q\ & !\total|dut|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[14]~q\,
	datad => VCC,
	cin => \total|dut|Add0~27\,
	combout => \total|dut|Add0~28_combout\,
	cout => \total|dut|Add0~29\);

-- Location: LCCOMB_X46_Y1_N24
\total|dut|count_var~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~4_combout\ = (\total|dut|Add0~28_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|Equal0~4_combout\,
	datad => \total|dut|Add0~28_combout\,
	combout => \total|dut|count_var~4_combout\);

-- Location: FF_X46_Y1_N25
\total|dut|clock_div_process:count_var[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[14]~q\);

-- Location: LCCOMB_X46_Y1_N8
\total|dut|Add0~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~30_combout\ = (\total|dut|clock_div_process:count_var[15]~q\ & (!\total|dut|Add0~29\)) # (!\total|dut|clock_div_process:count_var[15]~q\ & ((\total|dut|Add0~29\) # (GND)))
-- \total|dut|Add0~31\ = CARRY((!\total|dut|Add0~29\) # (!\total|dut|clock_div_process:count_var[15]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[15]~q\,
	datad => VCC,
	cin => \total|dut|Add0~29\,
	combout => \total|dut|Add0~30_combout\,
	cout => \total|dut|Add0~31\);

-- Location: FF_X46_Y1_N9
\total|dut|clock_div_process:count_var[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~30_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[15]~q\);

-- Location: LCCOMB_X45_Y1_N22
\total|dut|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~3_combout\ = (!\total|dut|clock_div_process:count_var[13]~q\ & (\total|dut|clock_div_process:count_var[14]~q\ & (!\total|dut|clock_div_process:count_var[15]~q\ & !\total|dut|clock_div_process:count_var[12]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[13]~q\,
	datab => \total|dut|clock_div_process:count_var[14]~q\,
	datac => \total|dut|clock_div_process:count_var[15]~q\,
	datad => \total|dut|clock_div_process:count_var[12]~q\,
	combout => \total|dut|Equal0~3_combout\);

-- Location: LCCOMB_X46_Y2_N2
\total|dut|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~1_combout\ = (\total|dut|clock_div_process:count_var[1]~q\ & (\total|dut|clock_div_process:count_var[3]~q\ & (\total|dut|clock_div_process:count_var[2]~q\ & \total|dut|clock_div_process:count_var[4]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[1]~q\,
	datab => \total|dut|clock_div_process:count_var[3]~q\,
	datac => \total|dut|clock_div_process:count_var[2]~q\,
	datad => \total|dut|clock_div_process:count_var[4]~q\,
	combout => \total|dut|Equal0~1_combout\);

-- Location: LCCOMB_X45_Y1_N30
\total|dut|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~2_combout\ = (\total|dut|clock_div_process:count_var[11]~q\ & (!\total|dut|clock_div_process:count_var[10]~q\ & (\total|dut|clock_div_process:count_var[9]~q\ & \total|dut|clock_div_process:count_var[0]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[11]~q\,
	datab => \total|dut|clock_div_process:count_var[10]~q\,
	datac => \total|dut|clock_div_process:count_var[9]~q\,
	datad => \total|dut|clock_div_process:count_var[0]~q\,
	combout => \total|dut|Equal0~2_combout\);

-- Location: LCCOMB_X46_Y2_N8
\total|dut|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~0_combout\ = (!\total|dut|clock_div_process:count_var[6]~q\ & (!\total|dut|clock_div_process:count_var[7]~q\ & (\total|dut|clock_div_process:count_var[8]~q\ & \total|dut|clock_div_process:count_var[5]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[6]~q\,
	datab => \total|dut|clock_div_process:count_var[7]~q\,
	datac => \total|dut|clock_div_process:count_var[8]~q\,
	datad => \total|dut|clock_div_process:count_var[5]~q\,
	combout => \total|dut|Equal0~0_combout\);

-- Location: LCCOMB_X45_Y1_N12
\total|dut|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~4_combout\ = (\total|dut|Equal0~3_combout\ & (\total|dut|Equal0~1_combout\ & (\total|dut|Equal0~2_combout\ & \total|dut|Equal0~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~3_combout\,
	datab => \total|dut|Equal0~1_combout\,
	datac => \total|dut|Equal0~2_combout\,
	datad => \total|dut|Equal0~0_combout\,
	combout => \total|dut|Equal0~4_combout\);

-- Location: LCCOMB_X46_Y1_N10
\total|dut|Add0~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~32_combout\ = (\total|dut|clock_div_process:count_var[16]~q\ & (\total|dut|Add0~31\ $ (GND))) # (!\total|dut|clock_div_process:count_var[16]~q\ & (!\total|dut|Add0~31\ & VCC))
-- \total|dut|Add0~33\ = CARRY((\total|dut|clock_div_process:count_var[16]~q\ & !\total|dut|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[16]~q\,
	datad => VCC,
	cin => \total|dut|Add0~31\,
	combout => \total|dut|Add0~32_combout\,
	cout => \total|dut|Add0~33\);

-- Location: FF_X46_Y1_N11
\total|dut|clock_div_process:count_var[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[16]~q\);

-- Location: LCCOMB_X46_Y1_N12
\total|dut|Add0~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~34_combout\ = (\total|dut|clock_div_process:count_var[17]~q\ & (!\total|dut|Add0~33\)) # (!\total|dut|clock_div_process:count_var[17]~q\ & ((\total|dut|Add0~33\) # (GND)))
-- \total|dut|Add0~35\ = CARRY((!\total|dut|Add0~33\) # (!\total|dut|clock_div_process:count_var[17]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[17]~q\,
	datad => VCC,
	cin => \total|dut|Add0~33\,
	combout => \total|dut|Add0~34_combout\,
	cout => \total|dut|Add0~35\);

-- Location: FF_X46_Y1_N13
\total|dut|clock_div_process:count_var[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~34_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[17]~q\);

-- Location: LCCOMB_X46_Y1_N14
\total|dut|Add0~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~36_combout\ = (\total|dut|clock_div_process:count_var[18]~q\ & (\total|dut|Add0~35\ $ (GND))) # (!\total|dut|clock_div_process:count_var[18]~q\ & (!\total|dut|Add0~35\ & VCC))
-- \total|dut|Add0~37\ = CARRY((\total|dut|clock_div_process:count_var[18]~q\ & !\total|dut|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[18]~q\,
	datad => VCC,
	cin => \total|dut|Add0~35\,
	combout => \total|dut|Add0~36_combout\,
	cout => \total|dut|Add0~37\);

-- Location: LCCOMB_X46_Y1_N30
\total|dut|count_var~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~5_combout\ = (\total|dut|Add0~36_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|Add0~36_combout\,
	datad => \total|dut|Equal0~4_combout\,
	combout => \total|dut|count_var~5_combout\);

-- Location: FF_X46_Y1_N31
\total|dut|clock_div_process:count_var[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[18]~q\);

-- Location: LCCOMB_X46_Y1_N16
\total|dut|Add0~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~38_combout\ = (\total|dut|clock_div_process:count_var[19]~q\ & (!\total|dut|Add0~37\)) # (!\total|dut|clock_div_process:count_var[19]~q\ & ((\total|dut|Add0~37\) # (GND)))
-- \total|dut|Add0~39\ = CARRY((!\total|dut|Add0~37\) # (!\total|dut|clock_div_process:count_var[19]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[19]~q\,
	datad => VCC,
	cin => \total|dut|Add0~37\,
	combout => \total|dut|Add0~38_combout\,
	cout => \total|dut|Add0~39\);

-- Location: LCCOMB_X46_Y1_N28
\total|dut|count_var~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~6_combout\ = (\total|dut|Add0~38_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|Equal0~4_combout\,
	datad => \total|dut|Add0~38_combout\,
	combout => \total|dut|count_var~6_combout\);

-- Location: FF_X46_Y1_N29
\total|dut|clock_div_process:count_var[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[19]~q\);

-- Location: LCCOMB_X46_Y1_N18
\total|dut|Add0~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~40_combout\ = (\total|dut|clock_div_process:count_var[20]~q\ & (\total|dut|Add0~39\ $ (GND))) # (!\total|dut|clock_div_process:count_var[20]~q\ & (!\total|dut|Add0~39\ & VCC))
-- \total|dut|Add0~41\ = CARRY((\total|dut|clock_div_process:count_var[20]~q\ & !\total|dut|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[20]~q\,
	datad => VCC,
	cin => \total|dut|Add0~39\,
	combout => \total|dut|Add0~40_combout\,
	cout => \total|dut|Add0~41\);

-- Location: FF_X46_Y1_N19
\total|dut|clock_div_process:count_var[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~40_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[20]~q\);

-- Location: LCCOMB_X46_Y1_N20
\total|dut|Add0~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~42_combout\ = (\total|dut|clock_div_process:count_var[21]~q\ & (!\total|dut|Add0~41\)) # (!\total|dut|clock_div_process:count_var[21]~q\ & ((\total|dut|Add0~41\) # (GND)))
-- \total|dut|Add0~43\ = CARRY((!\total|dut|Add0~41\) # (!\total|dut|clock_div_process:count_var[21]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|dut|clock_div_process:count_var[21]~q\,
	datad => VCC,
	cin => \total|dut|Add0~41\,
	combout => \total|dut|Add0~42_combout\,
	cout => \total|dut|Add0~43\);

-- Location: FF_X46_Y1_N21
\total|dut|clock_div_process:count_var[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|Add0~42_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[21]~q\);

-- Location: LCCOMB_X46_Y1_N22
\total|dut|Add0~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Add0~44_combout\ = \total|dut|Add0~43\ $ (!\total|dut|clock_div_process:count_var[22]~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \total|dut|clock_div_process:count_var[22]~q\,
	cin => \total|dut|Add0~43\,
	combout => \total|dut|Add0~44_combout\);

-- Location: LCCOMB_X46_Y1_N26
\total|dut|count_var~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|count_var~7_combout\ = (\total|dut|Add0~44_combout\ & ((!\total|dut|Equal0~4_combout\) # (!\total|dut|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|Add0~44_combout\,
	datad => \total|dut|Equal0~4_combout\,
	combout => \total|dut|count_var~7_combout\);

-- Location: FF_X46_Y1_N27
\total|dut|clock_div_process:count_var[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|count_var~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clock_div_process:count_var[22]~q\);

-- Location: LCCOMB_X45_Y1_N20
\total|dut|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~5_combout\ = (\total|dut|clock_div_process:count_var[18]~q\ & (!\total|dut|clock_div_process:count_var[17]~q\ & (!\total|dut|clock_div_process:count_var[16]~q\ & \total|dut|clock_div_process:count_var[19]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000001000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[18]~q\,
	datab => \total|dut|clock_div_process:count_var[17]~q\,
	datac => \total|dut|clock_div_process:count_var[16]~q\,
	datad => \total|dut|clock_div_process:count_var[19]~q\,
	combout => \total|dut|Equal0~5_combout\);

-- Location: LCCOMB_X45_Y1_N10
\total|dut|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|Equal0~6_combout\ = (!\total|dut|clock_div_process:count_var[20]~q\ & (\total|dut|clock_div_process:count_var[22]~q\ & (!\total|dut|clock_div_process:count_var[21]~q\ & \total|dut|Equal0~5_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|clock_div_process:count_var[20]~q\,
	datab => \total|dut|clock_div_process:count_var[22]~q\,
	datac => \total|dut|clock_div_process:count_var[21]~q\,
	datad => \total|dut|Equal0~5_combout\,
	combout => \total|dut|Equal0~6_combout\);

-- Location: LCCOMB_X45_Y1_N18
\total|dut|clk~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|clk~0_combout\ = \total|dut|clk~q\ $ (((\total|dut|Equal0~6_combout\ & \total|dut|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|dut|Equal0~6_combout\,
	datac => \total|dut|clk~q\,
	datad => \total|dut|Equal0~4_combout\,
	combout => \total|dut|clk~0_combout\);

-- Location: LCCOMB_X45_Y1_N24
\total|dut|clk~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|dut|clk~feeder_combout\ = \total|dut|clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \total|dut|clk~0_combout\,
	combout => \total|dut|clk~feeder_combout\);

-- Location: FF_X45_Y1_N25
\total|dut|clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \total|dut|clk~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|dut|clk~q\);

-- Location: CLKCTRL_G15
\total|dut|clk~clkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \total|dut|clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \total|dut|clk~clkctrl_outclk\);

-- Location: IOIBUF_X51_Y54_N29
\A[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(0),
	o => \A[0]~input_o\);

-- Location: LCCOMB_X51_Y53_N8
\total|Q[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[0]~8_combout\ = (\A[0]~input_o\ & (\total|Q\(0) $ (VCC))) # (!\A[0]~input_o\ & (\total|Q\(0) & VCC))
-- \total|Q[0]~9\ = CARRY((\A[0]~input_o\ & \total|Q\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A[0]~input_o\,
	datab => \total|Q\(0),
	datad => VCC,
	combout => \total|Q[0]~8_combout\,
	cout => \total|Q[0]~9\);

-- Location: IOIBUF_X46_Y54_N29
\tot_clr~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tot_clr,
	o => \tot_clr~input_o\);

-- Location: IOIBUF_X69_Y54_N1
\tot_ld~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tot_ld,
	o => \tot_ld~input_o\);

-- Location: FF_X51_Y53_N9
\total|Q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[0]~8_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(0));

-- Location: IOIBUF_X51_Y54_N22
\A[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(1),
	o => \A[1]~input_o\);

-- Location: LCCOMB_X51_Y53_N10
\total|Q[1]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[1]~10_combout\ = (\total|Q\(1) & ((\A[1]~input_o\ & (\total|Q[0]~9\ & VCC)) # (!\A[1]~input_o\ & (!\total|Q[0]~9\)))) # (!\total|Q\(1) & ((\A[1]~input_o\ & (!\total|Q[0]~9\)) # (!\A[1]~input_o\ & ((\total|Q[0]~9\) # (GND)))))
-- \total|Q[1]~11\ = CARRY((\total|Q\(1) & (!\A[1]~input_o\ & !\total|Q[0]~9\)) # (!\total|Q\(1) & ((!\total|Q[0]~9\) # (!\A[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|Q\(1),
	datab => \A[1]~input_o\,
	datad => VCC,
	cin => \total|Q[0]~9\,
	combout => \total|Q[1]~10_combout\,
	cout => \total|Q[1]~11\);

-- Location: FF_X51_Y53_N11
\total|Q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[1]~10_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(1));

-- Location: IOIBUF_X51_Y54_N1
\A[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(2),
	o => \A[2]~input_o\);

-- Location: LCCOMB_X51_Y53_N12
\total|Q[2]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[2]~12_combout\ = ((\total|Q\(2) $ (\A[2]~input_o\ $ (!\total|Q[1]~11\)))) # (GND)
-- \total|Q[2]~13\ = CARRY((\total|Q\(2) & ((\A[2]~input_o\) # (!\total|Q[1]~11\))) # (!\total|Q\(2) & (\A[2]~input_o\ & !\total|Q[1]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|Q\(2),
	datab => \A[2]~input_o\,
	datad => VCC,
	cin => \total|Q[1]~11\,
	combout => \total|Q[2]~12_combout\,
	cout => \total|Q[2]~13\);

-- Location: FF_X51_Y53_N13
\total|Q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[2]~12_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(2));

-- Location: LCCOMB_X51_Y53_N14
\total|Q[3]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[3]~14_combout\ = (\total|Q\(3) & (!\total|Q[2]~13\)) # (!\total|Q\(3) & ((\total|Q[2]~13\) # (GND)))
-- \total|Q[3]~15\ = CARRY((!\total|Q[2]~13\) # (!\total|Q\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|Q\(3),
	datad => VCC,
	cin => \total|Q[2]~13\,
	combout => \total|Q[3]~14_combout\,
	cout => \total|Q[3]~15\);

-- Location: FF_X51_Y53_N15
\total|Q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[3]~14_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(3));

-- Location: LCCOMB_X51_Y53_N16
\total|Q[4]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[4]~16_combout\ = (\total|Q\(4) & (\total|Q[3]~15\ $ (GND))) # (!\total|Q\(4) & (!\total|Q[3]~15\ & VCC))
-- \total|Q[4]~17\ = CARRY((\total|Q\(4) & !\total|Q[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|Q\(4),
	datad => VCC,
	cin => \total|Q[3]~15\,
	combout => \total|Q[4]~16_combout\,
	cout => \total|Q[4]~17\);

-- Location: FF_X51_Y53_N17
\total|Q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[4]~16_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(4));

-- Location: LCCOMB_X51_Y53_N18
\total|Q[5]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[5]~18_combout\ = (\total|Q\(5) & (!\total|Q[4]~17\)) # (!\total|Q\(5) & ((\total|Q[4]~17\) # (GND)))
-- \total|Q[5]~19\ = CARRY((!\total|Q[4]~17\) # (!\total|Q\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|Q\(5),
	datad => VCC,
	cin => \total|Q[4]~17\,
	combout => \total|Q[5]~18_combout\,
	cout => \total|Q[5]~19\);

-- Location: FF_X51_Y53_N19
\total|Q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[5]~18_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(5));

-- Location: LCCOMB_X51_Y53_N20
\total|Q[6]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[6]~20_combout\ = (\total|Q\(6) & (\total|Q[5]~19\ $ (GND))) # (!\total|Q\(6) & (!\total|Q[5]~19\ & VCC))
-- \total|Q[6]~21\ = CARRY((\total|Q\(6) & !\total|Q[5]~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|Q\(6),
	datad => VCC,
	cin => \total|Q[5]~19\,
	combout => \total|Q[6]~20_combout\,
	cout => \total|Q[6]~21\);

-- Location: FF_X51_Y53_N21
\total|Q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[6]~20_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(6));

-- Location: LCCOMB_X51_Y53_N22
\total|Q[7]~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|Q[7]~22_combout\ = \total|Q\(7) $ (\total|Q[6]~21\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|Q\(7),
	cin => \total|Q[6]~21\,
	combout => \total|Q[7]~22_combout\);

-- Location: FF_X51_Y53_N23
\total|Q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \total|dut|clk~clkctrl_outclk\,
	d => \total|Q[7]~22_combout\,
	clrn => \tot_clr~input_o\,
	ena => \ALT_INV_tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|Q\(7));

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_end_addr => -1,
	addr_range2_offset => -1,
	addr_range3_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_tot_coins(0) <= \tot_coins[0]~output_o\;

ww_tot_coins(1) <= \tot_coins[1]~output_o\;

ww_tot_coins(2) <= \tot_coins[2]~output_o\;

ww_tot_coins(3) <= \tot_coins[3]~output_o\;

ww_tot_coins(4) <= \tot_coins[4]~output_o\;

ww_tot_coins(5) <= \tot_coins[5]~output_o\;

ww_tot_coins(6) <= \tot_coins[6]~output_o\;

ww_tot_coins(7) <= \tot_coins[7]~output_o\;

ww_tot_coins(8) <= \tot_coins[8]~output_o\;

ww_tot_coins(9) <= \tot_coins[9]~output_o\;
END structure;


