library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity total_tb is
end total_tb;

architecture arch of total_tb is 
	component total is
		PORT(	clk, ld, clr	: in 	STD_LOGIC;
			I					: in 	STD_LOGIC_VECTOR(7 downto 0); 
			Q					: out	STD_LOGIC_VECTOR(7 downto 0)
	);
	end component; 
		
	signal ld_tb, clr_tb  : std_logic;
	signal i_tb, q_tb : std_logic_vector(7 downto 0);
	signal my_clock: std_logic := '0';
	
begin
	dut: total
	port map (
		ld =>ld_tb,
		clr => clr_tb,
		clk => my_clock,
		I => i_tb,
		Q => q_tb
	);

	
	my_clock <= not my_clock after 5 ns;

	stimulus : process
	begin
		clr_tb <= '0';
		i_tb <= x"00";
		ld_tb <= '0';
		wait for 6 ns;
		clr_tb <= '1';
		wait for 10 ns;
		clr_tb <= '0';
		ld_tb <= '1';
		i_tb <= x"A5";
		wait for 10 ns;
		ld_tb <= '0';
		i_tb <= x"3C";
		wait for 10 ns;
		ld_tb<= '1';
		wait for 10 ns;
		clr_tb <= '1';
		wait for 10 ns;
		i_tb <= x"4B";
		wait for 10 ns;
		
		wait;
		end process;
end;
	
	
	