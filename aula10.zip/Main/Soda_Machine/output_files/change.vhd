library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity change is
	port(
		s : in std_logic_vector( 7 downto 0);
		t : in std_logic_vector(7 downto 0);
		CH : out std_logic_vector(7 downto 0)
	);
end change;

architecture arch of change is:
begin 
	CH <= std_logic_vector(unsigned(t) - unsigned(s));
end arch;