-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.0 Build 711 06/05/2020 SJ Lite Edition"

-- DATE "10/13/2026 17:49:17"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	soda_machine IS
    PORT (
	m : IN std_logic;
	e : IN std_logic;
	a : IN std_logic_vector(2 DOWNTO 0);
	r : IN std_logic_vector(1 DOWNTO 0);
	sys_on : BUFFER std_logic;
	d : BUFFER std_logic;
	tot_coins : BUFFER std_logic_vector(7 DOWNTO 0);
	clk : IN std_logic
	);
END soda_machine;

-- Design Ports Information
-- sys_on	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- d	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[0]	=>  Location: PIN_A8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[1]	=>  Location: PIN_A9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[2]	=>  Location: PIN_A10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[3]	=>  Location: PIN_B10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[4]	=>  Location: PIN_D13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[5]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[6]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[7]	=>  Location: PIN_D14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- m	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r[0]	=>  Location: PIN_C10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- r[1]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- e	=>  Location: PIN_B8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[2]	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[0]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a[1]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_N14,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF soda_machine IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_m : std_logic;
SIGNAL ww_e : std_logic;
SIGNAL ww_a : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_r : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_sys_on : std_logic;
SIGNAL ww_d : std_logic;
SIGNAL ww_tot_coins : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_clk : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \clock_div|clk~clkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \sys_on~output_o\ : std_logic;
SIGNAL \d~output_o\ : std_logic;
SIGNAL \tot_coins[0]~output_o\ : std_logic;
SIGNAL \tot_coins[1]~output_o\ : std_logic;
SIGNAL \tot_coins[2]~output_o\ : std_logic;
SIGNAL \tot_coins[3]~output_o\ : std_logic;
SIGNAL \tot_coins[4]~output_o\ : std_logic;
SIGNAL \tot_coins[5]~output_o\ : std_logic;
SIGNAL \tot_coins[6]~output_o\ : std_logic;
SIGNAL \tot_coins[7]~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \clock_div|Add0~15\ : std_logic;
SIGNAL \clock_div|Add0~16_combout\ : std_logic;
SIGNAL \clock_div|count_var~0_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[8]~q\ : std_logic;
SIGNAL \clock_div|Add0~17\ : std_logic;
SIGNAL \clock_div|Add0~18_combout\ : std_logic;
SIGNAL \clock_div|count_var~2_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[9]~q\ : std_logic;
SIGNAL \clock_div|Add0~19\ : std_logic;
SIGNAL \clock_div|Add0~20_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[10]~q\ : std_logic;
SIGNAL \clock_div|Add0~21\ : std_logic;
SIGNAL \clock_div|Add0~22_combout\ : std_logic;
SIGNAL \clock_div|count_var~3_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[11]~q\ : std_logic;
SIGNAL \clock_div|Add0~23\ : std_logic;
SIGNAL \clock_div|Add0~24_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[12]~q\ : std_logic;
SIGNAL \clock_div|Add0~25\ : std_logic;
SIGNAL \clock_div|Add0~26_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[13]~q\ : std_logic;
SIGNAL \clock_div|Add0~27\ : std_logic;
SIGNAL \clock_div|Add0~28_combout\ : std_logic;
SIGNAL \clock_div|count_var~4_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[14]~q\ : std_logic;
SIGNAL \clock_div|Add0~29\ : std_logic;
SIGNAL \clock_div|Add0~30_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[15]~q\ : std_logic;
SIGNAL \clock_div|Add0~31\ : std_logic;
SIGNAL \clock_div|Add0~32_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[16]~q\ : std_logic;
SIGNAL \clock_div|Add0~33\ : std_logic;
SIGNAL \clock_div|Add0~34_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[17]~q\ : std_logic;
SIGNAL \clock_div|Add0~35\ : std_logic;
SIGNAL \clock_div|Add0~36_combout\ : std_logic;
SIGNAL \clock_div|count_var~5_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[18]~q\ : std_logic;
SIGNAL \clock_div|Add0~37\ : std_logic;
SIGNAL \clock_div|Add0~38_combout\ : std_logic;
SIGNAL \clock_div|count_var~6_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[19]~q\ : std_logic;
SIGNAL \clock_div|Equal0~5_combout\ : std_logic;
SIGNAL \clock_div|Add0~39\ : std_logic;
SIGNAL \clock_div|Add0~40_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[20]~q\ : std_logic;
SIGNAL \clock_div|Add0~41\ : std_logic;
SIGNAL \clock_div|Add0~42_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[21]~q\ : std_logic;
SIGNAL \clock_div|Add0~43\ : std_logic;
SIGNAL \clock_div|Add0~44_combout\ : std_logic;
SIGNAL \clock_div|count_var~7_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[22]~q\ : std_logic;
SIGNAL \clock_div|Equal0~6_combout\ : std_logic;
SIGNAL \clock_div|Add0~0_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[0]~q\ : std_logic;
SIGNAL \clock_div|Add0~1\ : std_logic;
SIGNAL \clock_div|Add0~2_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[1]~q\ : std_logic;
SIGNAL \clock_div|Add0~3\ : std_logic;
SIGNAL \clock_div|Add0~4_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[2]~q\ : std_logic;
SIGNAL \clock_div|Add0~5\ : std_logic;
SIGNAL \clock_div|Add0~6_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[3]~q\ : std_logic;
SIGNAL \clock_div|Add0~7\ : std_logic;
SIGNAL \clock_div|Add0~8_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[4]~q\ : std_logic;
SIGNAL \clock_div|Add0~9\ : std_logic;
SIGNAL \clock_div|Add0~10_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[5]~q\ : std_logic;
SIGNAL \clock_div|Add0~11\ : std_logic;
SIGNAL \clock_div|Add0~12_combout\ : std_logic;
SIGNAL \clock_div|count_var~1_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[6]~q\ : std_logic;
SIGNAL \clock_div|Add0~13\ : std_logic;
SIGNAL \clock_div|Add0~14_combout\ : std_logic;
SIGNAL \clock_div|clock_div_process:count_var[7]~q\ : std_logic;
SIGNAL \clock_div|Equal0~0_combout\ : std_logic;
SIGNAL \clock_div|Equal0~1_combout\ : std_logic;
SIGNAL \clock_div|Equal0~2_combout\ : std_logic;
SIGNAL \clock_div|Equal0~3_combout\ : std_logic;
SIGNAL \clock_div|Equal0~4_combout\ : std_logic;
SIGNAL \clock_div|clk~0_combout\ : std_logic;
SIGNAL \clock_div|clk~feeder_combout\ : std_logic;
SIGNAL \clock_div|clk~q\ : std_logic;
SIGNAL \clock_div|clk~clkctrl_outclk\ : std_logic;
SIGNAL \a[1]~input_o\ : std_logic;
SIGNAL \a[2]~input_o\ : std_logic;
SIGNAL \a[0]~input_o\ : std_logic;
SIGNAL \datapath|coin_detector|c~0_combout\ : std_logic;
SIGNAL \e~input_o\ : std_logic;
SIGNAL \m~input_o\ : std_logic;
SIGNAL \controller|comb_proc~1_combout\ : std_logic;
SIGNAL \datapath|total|q[0]~8_combout\ : std_logic;
SIGNAL \r[0]~input_o\ : std_logic;
SIGNAL \r[1]~input_o\ : std_logic;
SIGNAL \datapath|comparator|LessThan1~0_combout\ : std_logic;
SIGNAL \datapath|comparator|LessThan1~1_combout\ : std_logic;
SIGNAL \datapath|comparator|LessThan1~2_combout\ : std_logic;
SIGNAL \controller|comb_proc~0_combout\ : std_logic;
SIGNAL \controller|Selector4~0_combout\ : std_logic;
SIGNAL \controller|PS.S4~q\ : std_logic;
SIGNAL \controller|PS.S0~0_combout\ : std_logic;
SIGNAL \controller|PS.S0~feeder_combout\ : std_logic;
SIGNAL \controller|PS.S0~q\ : std_logic;
SIGNAL \datapath|total|q[0]~9\ : std_logic;
SIGNAL \datapath|total|q[1]~10_combout\ : std_logic;
SIGNAL \datapath|total|q[1]~11\ : std_logic;
SIGNAL \datapath|total|q[2]~12_combout\ : std_logic;
SIGNAL \datapath|total|q[2]~13\ : std_logic;
SIGNAL \datapath|total|q[3]~14_combout\ : std_logic;
SIGNAL \datapath|total|q[3]~15\ : std_logic;
SIGNAL \datapath|total|q[4]~16_combout\ : std_logic;
SIGNAL \datapath|total|q[4]~17\ : std_logic;
SIGNAL \datapath|total|q[5]~18_combout\ : std_logic;
SIGNAL \datapath|total|q[5]~19\ : std_logic;
SIGNAL \datapath|total|q[6]~20_combout\ : std_logic;
SIGNAL \datapath|total|q[6]~21\ : std_logic;
SIGNAL \datapath|total|q[7]~22_combout\ : std_logic;
SIGNAL \controller|NS~5_combout\ : std_logic;
SIGNAL \controller|NS~6_combout\ : std_logic;
SIGNAL \controller|Selector2~0_combout\ : std_logic;
SIGNAL \controller|PS.S2~q\ : std_logic;
SIGNAL \controller|Selector3~0_combout\ : std_logic;
SIGNAL \controller|PS.S3~q\ : std_logic;
SIGNAL \controller|Selector1~0_combout\ : std_logic;
SIGNAL \controller|Selector1~1_combout\ : std_logic;
SIGNAL \controller|Selector1~2_combout\ : std_logic;
SIGNAL \controller|PS.S1~q\ : std_logic;
SIGNAL \controller|Selector5~0_combout\ : std_logic;
SIGNAL \controller|PS.S5~q\ : std_logic;
SIGNAL \datapath|total|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \controller|ALT_INV_PS.S5~q\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_m <= m;
ww_e <= e;
ww_a <= a;
ww_r <= r;
sys_on <= ww_sys_on;
d <= ww_d;
tot_coins <= ww_tot_coins;
ww_clk <= clk;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\clock_div|clk~clkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clock_div|clk~q\);

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\controller|ALT_INV_PS.S5~q\ <= NOT \controller|PS.S5~q\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y41_N24
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X51_Y54_N9
\sys_on~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \controller|ALT_INV_PS.S5~q\,
	devoe => ww_devoe,
	o => \sys_on~output_o\);

-- Location: IOOBUF_X49_Y54_N9
\d~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \controller|PS.S4~q\,
	devoe => ww_devoe,
	o => \d~output_o\);

-- Location: IOOBUF_X46_Y54_N2
\tot_coins[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(0),
	devoe => ww_devoe,
	o => \tot_coins[0]~output_o\);

-- Location: IOOBUF_X46_Y54_N23
\tot_coins[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(1),
	devoe => ww_devoe,
	o => \tot_coins[1]~output_o\);

-- Location: IOOBUF_X51_Y54_N16
\tot_coins[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(2),
	devoe => ww_devoe,
	o => \tot_coins[2]~output_o\);

-- Location: IOOBUF_X46_Y54_N9
\tot_coins[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(3),
	devoe => ww_devoe,
	o => \tot_coins[3]~output_o\);

-- Location: IOOBUF_X56_Y54_N30
\tot_coins[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(4),
	devoe => ww_devoe,
	o => \tot_coins[4]~output_o\);

-- Location: IOOBUF_X58_Y54_N23
\tot_coins[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(5),
	devoe => ww_devoe,
	o => \tot_coins[5]~output_o\);

-- Location: IOOBUF_X66_Y54_N23
\tot_coins[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(6),
	devoe => ww_devoe,
	o => \tot_coins[6]~output_o\);

-- Location: IOOBUF_X56_Y54_N9
\tot_coins[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \datapath|total|q\(7),
	devoe => ww_devoe,
	o => \tot_coins[7]~output_o\);

-- Location: IOIBUF_X78_Y29_N22
\clk~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G9
\clk~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: LCCOMB_X26_Y3_N24
\clock_div|Add0~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~14_combout\ = (\clock_div|clock_div_process:count_var[7]~q\ & (!\clock_div|Add0~13\)) # (!\clock_div|clock_div_process:count_var[7]~q\ & ((\clock_div|Add0~13\) # (GND)))
-- \clock_div|Add0~15\ = CARRY((!\clock_div|Add0~13\) # (!\clock_div|clock_div_process:count_var[7]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[7]~q\,
	datad => VCC,
	cin => \clock_div|Add0~13\,
	combout => \clock_div|Add0~14_combout\,
	cout => \clock_div|Add0~15\);

-- Location: LCCOMB_X26_Y3_N26
\clock_div|Add0~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~16_combout\ = (\clock_div|clock_div_process:count_var[8]~q\ & (\clock_div|Add0~15\ $ (GND))) # (!\clock_div|clock_div_process:count_var[8]~q\ & (!\clock_div|Add0~15\ & VCC))
-- \clock_div|Add0~17\ = CARRY((\clock_div|clock_div_process:count_var[8]~q\ & !\clock_div|Add0~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[8]~q\,
	datad => VCC,
	cin => \clock_div|Add0~15\,
	combout => \clock_div|Add0~16_combout\,
	cout => \clock_div|Add0~17\);

-- Location: LCCOMB_X26_Y3_N8
\clock_div|count_var~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~0_combout\ = (\clock_div|Add0~16_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~4_combout\,
	datab => \clock_div|Equal0~6_combout\,
	datad => \clock_div|Add0~16_combout\,
	combout => \clock_div|count_var~0_combout\);

-- Location: FF_X26_Y3_N9
\clock_div|clock_div_process:count_var[8]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[8]~q\);

-- Location: LCCOMB_X26_Y3_N28
\clock_div|Add0~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~18_combout\ = (\clock_div|clock_div_process:count_var[9]~q\ & (!\clock_div|Add0~17\)) # (!\clock_div|clock_div_process:count_var[9]~q\ & ((\clock_div|Add0~17\) # (GND)))
-- \clock_div|Add0~19\ = CARRY((!\clock_div|Add0~17\) # (!\clock_div|clock_div_process:count_var[9]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[9]~q\,
	datad => VCC,
	cin => \clock_div|Add0~17\,
	combout => \clock_div|Add0~18_combout\,
	cout => \clock_div|Add0~19\);

-- Location: LCCOMB_X26_Y3_N4
\clock_div|count_var~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~2_combout\ = (\clock_div|Add0~18_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~18_combout\,
	combout => \clock_div|count_var~2_combout\);

-- Location: FF_X26_Y3_N5
\clock_div|clock_div_process:count_var[9]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[9]~q\);

-- Location: LCCOMB_X26_Y3_N30
\clock_div|Add0~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~20_combout\ = (\clock_div|clock_div_process:count_var[10]~q\ & (\clock_div|Add0~19\ $ (GND))) # (!\clock_div|clock_div_process:count_var[10]~q\ & (!\clock_div|Add0~19\ & VCC))
-- \clock_div|Add0~21\ = CARRY((\clock_div|clock_div_process:count_var[10]~q\ & !\clock_div|Add0~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[10]~q\,
	datad => VCC,
	cin => \clock_div|Add0~19\,
	combout => \clock_div|Add0~20_combout\,
	cout => \clock_div|Add0~21\);

-- Location: FF_X26_Y3_N31
\clock_div|clock_div_process:count_var[10]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~20_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[10]~q\);

-- Location: LCCOMB_X26_Y2_N0
\clock_div|Add0~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~22_combout\ = (\clock_div|clock_div_process:count_var[11]~q\ & (!\clock_div|Add0~21\)) # (!\clock_div|clock_div_process:count_var[11]~q\ & ((\clock_div|Add0~21\) # (GND)))
-- \clock_div|Add0~23\ = CARRY((!\clock_div|Add0~21\) # (!\clock_div|clock_div_process:count_var[11]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[11]~q\,
	datad => VCC,
	cin => \clock_div|Add0~21\,
	combout => \clock_div|Add0~22_combout\,
	cout => \clock_div|Add0~23\);

-- Location: LCCOMB_X26_Y2_N24
\clock_div|count_var~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~3_combout\ = (\clock_div|Add0~22_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~22_combout\,
	combout => \clock_div|count_var~3_combout\);

-- Location: FF_X26_Y2_N25
\clock_div|clock_div_process:count_var[11]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~3_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[11]~q\);

-- Location: LCCOMB_X26_Y2_N2
\clock_div|Add0~24\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~24_combout\ = (\clock_div|clock_div_process:count_var[12]~q\ & (\clock_div|Add0~23\ $ (GND))) # (!\clock_div|clock_div_process:count_var[12]~q\ & (!\clock_div|Add0~23\ & VCC))
-- \clock_div|Add0~25\ = CARRY((\clock_div|clock_div_process:count_var[12]~q\ & !\clock_div|Add0~23\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[12]~q\,
	datad => VCC,
	cin => \clock_div|Add0~23\,
	combout => \clock_div|Add0~24_combout\,
	cout => \clock_div|Add0~25\);

-- Location: FF_X26_Y2_N3
\clock_div|clock_div_process:count_var[12]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~24_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[12]~q\);

-- Location: LCCOMB_X26_Y2_N4
\clock_div|Add0~26\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~26_combout\ = (\clock_div|clock_div_process:count_var[13]~q\ & (!\clock_div|Add0~25\)) # (!\clock_div|clock_div_process:count_var[13]~q\ & ((\clock_div|Add0~25\) # (GND)))
-- \clock_div|Add0~27\ = CARRY((!\clock_div|Add0~25\) # (!\clock_div|clock_div_process:count_var[13]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[13]~q\,
	datad => VCC,
	cin => \clock_div|Add0~25\,
	combout => \clock_div|Add0~26_combout\,
	cout => \clock_div|Add0~27\);

-- Location: FF_X26_Y2_N5
\clock_div|clock_div_process:count_var[13]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~26_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[13]~q\);

-- Location: LCCOMB_X26_Y2_N6
\clock_div|Add0~28\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~28_combout\ = (\clock_div|clock_div_process:count_var[14]~q\ & (\clock_div|Add0~27\ $ (GND))) # (!\clock_div|clock_div_process:count_var[14]~q\ & (!\clock_div|Add0~27\ & VCC))
-- \clock_div|Add0~29\ = CARRY((\clock_div|clock_div_process:count_var[14]~q\ & !\clock_div|Add0~27\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[14]~q\,
	datad => VCC,
	cin => \clock_div|Add0~27\,
	combout => \clock_div|Add0~28_combout\,
	cout => \clock_div|Add0~29\);

-- Location: LCCOMB_X26_Y2_N30
\clock_div|count_var~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~4_combout\ = (\clock_div|Add0~28_combout\ & ((!\clock_div|Equal0~4_combout\) # (!\clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~6_combout\,
	datac => \clock_div|Equal0~4_combout\,
	datad => \clock_div|Add0~28_combout\,
	combout => \clock_div|count_var~4_combout\);

-- Location: FF_X26_Y2_N31
\clock_div|clock_div_process:count_var[14]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[14]~q\);

-- Location: LCCOMB_X26_Y2_N8
\clock_div|Add0~30\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~30_combout\ = (\clock_div|clock_div_process:count_var[15]~q\ & (!\clock_div|Add0~29\)) # (!\clock_div|clock_div_process:count_var[15]~q\ & ((\clock_div|Add0~29\) # (GND)))
-- \clock_div|Add0~31\ = CARRY((!\clock_div|Add0~29\) # (!\clock_div|clock_div_process:count_var[15]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[15]~q\,
	datad => VCC,
	cin => \clock_div|Add0~29\,
	combout => \clock_div|Add0~30_combout\,
	cout => \clock_div|Add0~31\);

-- Location: FF_X26_Y2_N9
\clock_div|clock_div_process:count_var[15]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~30_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[15]~q\);

-- Location: LCCOMB_X26_Y2_N10
\clock_div|Add0~32\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~32_combout\ = (\clock_div|clock_div_process:count_var[16]~q\ & (\clock_div|Add0~31\ $ (GND))) # (!\clock_div|clock_div_process:count_var[16]~q\ & (!\clock_div|Add0~31\ & VCC))
-- \clock_div|Add0~33\ = CARRY((\clock_div|clock_div_process:count_var[16]~q\ & !\clock_div|Add0~31\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010010100001010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[16]~q\,
	datad => VCC,
	cin => \clock_div|Add0~31\,
	combout => \clock_div|Add0~32_combout\,
	cout => \clock_div|Add0~33\);

-- Location: FF_X26_Y2_N11
\clock_div|clock_div_process:count_var[16]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~32_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[16]~q\);

-- Location: LCCOMB_X26_Y2_N12
\clock_div|Add0~34\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~34_combout\ = (\clock_div|clock_div_process:count_var[17]~q\ & (!\clock_div|Add0~33\)) # (!\clock_div|clock_div_process:count_var[17]~q\ & ((\clock_div|Add0~33\) # (GND)))
-- \clock_div|Add0~35\ = CARRY((!\clock_div|Add0~33\) # (!\clock_div|clock_div_process:count_var[17]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[17]~q\,
	datad => VCC,
	cin => \clock_div|Add0~33\,
	combout => \clock_div|Add0~34_combout\,
	cout => \clock_div|Add0~35\);

-- Location: FF_X26_Y2_N13
\clock_div|clock_div_process:count_var[17]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~34_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[17]~q\);

-- Location: LCCOMB_X26_Y2_N14
\clock_div|Add0~36\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~36_combout\ = (\clock_div|clock_div_process:count_var[18]~q\ & (\clock_div|Add0~35\ $ (GND))) # (!\clock_div|clock_div_process:count_var[18]~q\ & (!\clock_div|Add0~35\ & VCC))
-- \clock_div|Add0~37\ = CARRY((\clock_div|clock_div_process:count_var[18]~q\ & !\clock_div|Add0~35\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[18]~q\,
	datad => VCC,
	cin => \clock_div|Add0~35\,
	combout => \clock_div|Add0~36_combout\,
	cout => \clock_div|Add0~37\);

-- Location: LCCOMB_X26_Y2_N28
\clock_div|count_var~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~5_combout\ = (\clock_div|Add0~36_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~36_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~5_combout\);

-- Location: FF_X26_Y2_N29
\clock_div|clock_div_process:count_var[18]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~5_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[18]~q\);

-- Location: LCCOMB_X26_Y2_N16
\clock_div|Add0~38\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~38_combout\ = (\clock_div|clock_div_process:count_var[19]~q\ & (!\clock_div|Add0~37\)) # (!\clock_div|clock_div_process:count_var[19]~q\ & ((\clock_div|Add0~37\) # (GND)))
-- \clock_div|Add0~39\ = CARRY((!\clock_div|Add0~37\) # (!\clock_div|clock_div_process:count_var[19]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[19]~q\,
	datad => VCC,
	cin => \clock_div|Add0~37\,
	combout => \clock_div|Add0~38_combout\,
	cout => \clock_div|Add0~39\);

-- Location: LCCOMB_X27_Y2_N2
\clock_div|count_var~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~6_combout\ = (\clock_div|Add0~38_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~38_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~6_combout\);

-- Location: FF_X27_Y2_N3
\clock_div|clock_div_process:count_var[19]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[19]~q\);

-- Location: LCCOMB_X27_Y2_N12
\clock_div|Equal0~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~5_combout\ = (!\clock_div|clock_div_process:count_var[16]~q\ & (\clock_div|clock_div_process:count_var[18]~q\ & (\clock_div|clock_div_process:count_var[19]~q\ & !\clock_div|clock_div_process:count_var[17]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[16]~q\,
	datab => \clock_div|clock_div_process:count_var[18]~q\,
	datac => \clock_div|clock_div_process:count_var[19]~q\,
	datad => \clock_div|clock_div_process:count_var[17]~q\,
	combout => \clock_div|Equal0~5_combout\);

-- Location: LCCOMB_X26_Y2_N18
\clock_div|Add0~40\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~40_combout\ = (\clock_div|clock_div_process:count_var[20]~q\ & (\clock_div|Add0~39\ $ (GND))) # (!\clock_div|clock_div_process:count_var[20]~q\ & (!\clock_div|Add0~39\ & VCC))
-- \clock_div|Add0~41\ = CARRY((\clock_div|clock_div_process:count_var[20]~q\ & !\clock_div|Add0~39\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[20]~q\,
	datad => VCC,
	cin => \clock_div|Add0~39\,
	combout => \clock_div|Add0~40_combout\,
	cout => \clock_div|Add0~41\);

-- Location: FF_X26_Y2_N19
\clock_div|clock_div_process:count_var[20]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~40_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[20]~q\);

-- Location: LCCOMB_X26_Y2_N20
\clock_div|Add0~42\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~42_combout\ = (\clock_div|clock_div_process:count_var[21]~q\ & (!\clock_div|Add0~41\)) # (!\clock_div|clock_div_process:count_var[21]~q\ & ((\clock_div|Add0~41\) # (GND)))
-- \clock_div|Add0~43\ = CARRY((!\clock_div|Add0~41\) # (!\clock_div|clock_div_process:count_var[21]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[21]~q\,
	datad => VCC,
	cin => \clock_div|Add0~41\,
	combout => \clock_div|Add0~42_combout\,
	cout => \clock_div|Add0~43\);

-- Location: FF_X26_Y2_N21
\clock_div|clock_div_process:count_var[21]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~42_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[21]~q\);

-- Location: LCCOMB_X26_Y2_N22
\clock_div|Add0~44\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~44_combout\ = \clock_div|Add0~43\ $ (!\clock_div|clock_div_process:count_var[22]~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000000001111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datad => \clock_div|clock_div_process:count_var[22]~q\,
	cin => \clock_div|Add0~43\,
	combout => \clock_div|Add0~44_combout\);

-- Location: LCCOMB_X26_Y2_N26
\clock_div|count_var~7\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~7_combout\ = (\clock_div|Add0~44_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|Equal0~4_combout\,
	datac => \clock_div|Add0~44_combout\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|count_var~7_combout\);

-- Location: FF_X26_Y2_N27
\clock_div|clock_div_process:count_var[22]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~7_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[22]~q\);

-- Location: LCCOMB_X27_Y2_N6
\clock_div|Equal0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~6_combout\ = (\clock_div|Equal0~5_combout\ & (!\clock_div|clock_div_process:count_var[21]~q\ & (\clock_div|clock_div_process:count_var[22]~q\ & !\clock_div|clock_div_process:count_var[20]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~5_combout\,
	datab => \clock_div|clock_div_process:count_var[21]~q\,
	datac => \clock_div|clock_div_process:count_var[22]~q\,
	datad => \clock_div|clock_div_process:count_var[20]~q\,
	combout => \clock_div|Equal0~6_combout\);

-- Location: LCCOMB_X26_Y3_N10
\clock_div|Add0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~0_combout\ = \clock_div|clock_div_process:count_var[0]~q\ $ (VCC)
-- \clock_div|Add0~1\ = CARRY(\clock_div|clock_div_process:count_var[0]~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101010110101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[0]~q\,
	datad => VCC,
	combout => \clock_div|Add0~0_combout\,
	cout => \clock_div|Add0~1\);

-- Location: FF_X26_Y3_N11
\clock_div|clock_div_process:count_var[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[0]~q\);

-- Location: LCCOMB_X26_Y3_N12
\clock_div|Add0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~2_combout\ = (\clock_div|clock_div_process:count_var[1]~q\ & (!\clock_div|Add0~1\)) # (!\clock_div|clock_div_process:count_var[1]~q\ & ((\clock_div|Add0~1\) # (GND)))
-- \clock_div|Add0~3\ = CARRY((!\clock_div|Add0~1\) # (!\clock_div|clock_div_process:count_var[1]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[1]~q\,
	datad => VCC,
	cin => \clock_div|Add0~1\,
	combout => \clock_div|Add0~2_combout\,
	cout => \clock_div|Add0~3\);

-- Location: FF_X26_Y3_N13
\clock_div|clock_div_process:count_var[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[1]~q\);

-- Location: LCCOMB_X26_Y3_N14
\clock_div|Add0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~4_combout\ = (\clock_div|clock_div_process:count_var[2]~q\ & (\clock_div|Add0~3\ $ (GND))) # (!\clock_div|clock_div_process:count_var[2]~q\ & (!\clock_div|Add0~3\ & VCC))
-- \clock_div|Add0~5\ = CARRY((\clock_div|clock_div_process:count_var[2]~q\ & !\clock_div|Add0~3\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[2]~q\,
	datad => VCC,
	cin => \clock_div|Add0~3\,
	combout => \clock_div|Add0~4_combout\,
	cout => \clock_div|Add0~5\);

-- Location: FF_X26_Y3_N15
\clock_div|clock_div_process:count_var[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~4_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[2]~q\);

-- Location: LCCOMB_X26_Y3_N16
\clock_div|Add0~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~6_combout\ = (\clock_div|clock_div_process:count_var[3]~q\ & (!\clock_div|Add0~5\)) # (!\clock_div|clock_div_process:count_var[3]~q\ & ((\clock_div|Add0~5\) # (GND)))
-- \clock_div|Add0~7\ = CARRY((!\clock_div|Add0~5\) # (!\clock_div|clock_div_process:count_var[3]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[3]~q\,
	datad => VCC,
	cin => \clock_div|Add0~5\,
	combout => \clock_div|Add0~6_combout\,
	cout => \clock_div|Add0~7\);

-- Location: FF_X26_Y3_N17
\clock_div|clock_div_process:count_var[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~6_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[3]~q\);

-- Location: LCCOMB_X26_Y3_N18
\clock_div|Add0~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~8_combout\ = (\clock_div|clock_div_process:count_var[4]~q\ & (\clock_div|Add0~7\ $ (GND))) # (!\clock_div|clock_div_process:count_var[4]~q\ & (!\clock_div|Add0~7\ & VCC))
-- \clock_div|Add0~9\ = CARRY((\clock_div|clock_div_process:count_var[4]~q\ & !\clock_div|Add0~7\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[4]~q\,
	datad => VCC,
	cin => \clock_div|Add0~7\,
	combout => \clock_div|Add0~8_combout\,
	cout => \clock_div|Add0~9\);

-- Location: FF_X26_Y3_N19
\clock_div|clock_div_process:count_var[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~8_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[4]~q\);

-- Location: LCCOMB_X26_Y3_N20
\clock_div|Add0~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~10_combout\ = (\clock_div|clock_div_process:count_var[5]~q\ & (!\clock_div|Add0~9\)) # (!\clock_div|clock_div_process:count_var[5]~q\ & ((\clock_div|Add0~9\) # (GND)))
-- \clock_div|Add0~11\ = CARRY((!\clock_div|Add0~9\) # (!\clock_div|clock_div_process:count_var[5]~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[5]~q\,
	datad => VCC,
	cin => \clock_div|Add0~9\,
	combout => \clock_div|Add0~10_combout\,
	cout => \clock_div|Add0~11\);

-- Location: FF_X26_Y3_N21
\clock_div|clock_div_process:count_var[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~10_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[5]~q\);

-- Location: LCCOMB_X26_Y3_N22
\clock_div|Add0~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Add0~12_combout\ = (\clock_div|clock_div_process:count_var[6]~q\ & (\clock_div|Add0~11\ $ (GND))) # (!\clock_div|clock_div_process:count_var[6]~q\ & (!\clock_div|Add0~11\ & VCC))
-- \clock_div|Add0~13\ = CARRY((\clock_div|clock_div_process:count_var[6]~q\ & !\clock_div|Add0~11\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \clock_div|clock_div_process:count_var[6]~q\,
	datad => VCC,
	cin => \clock_div|Add0~11\,
	combout => \clock_div|Add0~12_combout\,
	cout => \clock_div|Add0~13\);

-- Location: LCCOMB_X26_Y3_N2
\clock_div|count_var~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|count_var~1_combout\ = (\clock_div|Add0~12_combout\ & ((!\clock_div|Equal0~6_combout\) # (!\clock_div|Equal0~4_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~4_combout\,
	datab => \clock_div|Equal0~6_combout\,
	datad => \clock_div|Add0~12_combout\,
	combout => \clock_div|count_var~1_combout\);

-- Location: FF_X26_Y3_N3
\clock_div|clock_div_process:count_var[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|count_var~1_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[6]~q\);

-- Location: FF_X26_Y3_N25
\clock_div|clock_div_process:count_var[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|Add0~14_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clock_div_process:count_var[7]~q\);

-- Location: LCCOMB_X26_Y3_N0
\clock_div|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~0_combout\ = (!\clock_div|clock_div_process:count_var[7]~q\ & (!\clock_div|clock_div_process:count_var[6]~q\ & (\clock_div|clock_div_process:count_var[8]~q\ & \clock_div|clock_div_process:count_var[5]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0001000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[7]~q\,
	datab => \clock_div|clock_div_process:count_var[6]~q\,
	datac => \clock_div|clock_div_process:count_var[8]~q\,
	datad => \clock_div|clock_div_process:count_var[5]~q\,
	combout => \clock_div|Equal0~0_combout\);

-- Location: LCCOMB_X26_Y3_N6
\clock_div|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~1_combout\ = (\clock_div|clock_div_process:count_var[1]~q\ & (\clock_div|clock_div_process:count_var[3]~q\ & (\clock_div|clock_div_process:count_var[4]~q\ & \clock_div|clock_div_process:count_var[2]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[1]~q\,
	datab => \clock_div|clock_div_process:count_var[3]~q\,
	datac => \clock_div|clock_div_process:count_var[4]~q\,
	datad => \clock_div|clock_div_process:count_var[2]~q\,
	combout => \clock_div|Equal0~1_combout\);

-- Location: LCCOMB_X27_Y3_N8
\clock_div|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~2_combout\ = (\clock_div|clock_div_process:count_var[0]~q\ & (\clock_div|clock_div_process:count_var[9]~q\ & (\clock_div|clock_div_process:count_var[11]~q\ & !\clock_div|clock_div_process:count_var[10]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[0]~q\,
	datab => \clock_div|clock_div_process:count_var[9]~q\,
	datac => \clock_div|clock_div_process:count_var[11]~q\,
	datad => \clock_div|clock_div_process:count_var[10]~q\,
	combout => \clock_div|Equal0~2_combout\);

-- Location: LCCOMB_X27_Y2_N0
\clock_div|Equal0~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~3_combout\ = (!\clock_div|clock_div_process:count_var[15]~q\ & (\clock_div|clock_div_process:count_var[14]~q\ & (!\clock_div|clock_div_process:count_var[13]~q\ & !\clock_div|clock_div_process:count_var[12]~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|clock_div_process:count_var[15]~q\,
	datab => \clock_div|clock_div_process:count_var[14]~q\,
	datac => \clock_div|clock_div_process:count_var[13]~q\,
	datad => \clock_div|clock_div_process:count_var[12]~q\,
	combout => \clock_div|Equal0~3_combout\);

-- Location: LCCOMB_X27_Y3_N30
\clock_div|Equal0~4\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|Equal0~4_combout\ = (\clock_div|Equal0~0_combout\ & (\clock_div|Equal0~1_combout\ & (\clock_div|Equal0~2_combout\ & \clock_div|Equal0~3_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~0_combout\,
	datab => \clock_div|Equal0~1_combout\,
	datac => \clock_div|Equal0~2_combout\,
	datad => \clock_div|Equal0~3_combout\,
	combout => \clock_div|Equal0~4_combout\);

-- Location: LCCOMB_X27_Y2_N30
\clock_div|clk~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|clk~0_combout\ = \clock_div|clk~q\ $ (((\clock_div|Equal0~4_combout\ & \clock_div|Equal0~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \clock_div|Equal0~4_combout\,
	datac => \clock_div|clk~q\,
	datad => \clock_div|Equal0~6_combout\,
	combout => \clock_div|clk~0_combout\);

-- Location: LCCOMB_X27_Y2_N8
\clock_div|clk~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \clock_div|clk~feeder_combout\ = \clock_div|clk~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \clock_div|clk~0_combout\,
	combout => \clock_div|clk~feeder_combout\);

-- Location: FF_X27_Y2_N9
\clock_div|clk\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \clock_div|clk~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \clock_div|clk~q\);

-- Location: CLKCTRL_G16
\clock_div|clk~clkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clock_div|clk~clkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clock_div|clk~clkctrl_outclk\);

-- Location: IOIBUF_X54_Y54_N29
\a[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(1),
	o => \a[1]~input_o\);

-- Location: IOIBUF_X54_Y54_N22
\a[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(2),
	o => \a[2]~input_o\);

-- Location: IOIBUF_X51_Y54_N1
\a[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a(0),
	o => \a[0]~input_o\);

-- Location: LCCOMB_X55_Y50_N22
\datapath|coin_detector|c~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|coin_detector|c~0_combout\ = (\a[2]~input_o\ & ((\a[0]~input_o\) # (\a[1]~input_o\))) # (!\a[2]~input_o\ & (\a[0]~input_o\ $ (!\a[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111110011000011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \a[2]~input_o\,
	datac => \a[0]~input_o\,
	datad => \a[1]~input_o\,
	combout => \datapath|coin_detector|c~0_combout\);

-- Location: IOIBUF_X46_Y54_N29
\e~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_e,
	o => \e~input_o\);

-- Location: IOIBUF_X69_Y54_N1
\m~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_m,
	o => \m~input_o\);

-- Location: LCCOMB_X55_Y50_N28
\controller|comb_proc~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|comb_proc~1_combout\ = (!\datapath|coin_detector|c~0_combout\ & (\e~input_o\ & !\m~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|coin_detector|c~0_combout\,
	datac => \e~input_o\,
	datad => \m~input_o\,
	combout => \controller|comb_proc~1_combout\);

-- Location: LCCOMB_X54_Y50_N8
\datapath|total|q[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[0]~8_combout\ = (\datapath|total|q\(0) & (\a[0]~input_o\ $ (VCC))) # (!\datapath|total|q\(0) & (\a[0]~input_o\ & VCC))
-- \datapath|total|q[0]~9\ = CARRY((\datapath|total|q\(0) & \a[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(0),
	datab => \a[0]~input_o\,
	datad => VCC,
	combout => \datapath|total|q[0]~8_combout\,
	cout => \datapath|total|q[0]~9\);

-- Location: IOIBUF_X51_Y54_N29
\r[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_r(0),
	o => \r[0]~input_o\);

-- Location: IOIBUF_X51_Y54_N22
\r[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_r(1),
	o => \r[1]~input_o\);

-- Location: LCCOMB_X54_Y50_N0
\datapath|comparator|LessThan1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|comparator|LessThan1~0_combout\ = (\r[0]~input_o\ & ((\r[1]~input_o\) # ((!\datapath|total|q\(0) & !\datapath|total|q\(2))))) # (!\r[0]~input_o\ & (\r[1]~input_o\ & ((!\datapath|total|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000100011001110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \r[0]~input_o\,
	datab => \r[1]~input_o\,
	datac => \datapath|total|q\(0),
	datad => \datapath|total|q\(2),
	combout => \datapath|comparator|LessThan1~0_combout\);

-- Location: LCCOMB_X54_Y50_N2
\datapath|comparator|LessThan1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|comparator|LessThan1~1_combout\ = (\datapath|total|q\(3) & ((\datapath|total|q\(1) & ((\datapath|total|q\(2)) # (!\datapath|comparator|LessThan1~0_combout\))) # (!\datapath|total|q\(1) & (\datapath|total|q\(2) & 
-- !\datapath|comparator|LessThan1~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000011001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(1),
	datab => \datapath|total|q\(3),
	datac => \datapath|total|q\(2),
	datad => \datapath|comparator|LessThan1~0_combout\,
	combout => \datapath|comparator|LessThan1~1_combout\);

-- Location: LCCOMB_X54_Y50_N28
\datapath|comparator|LessThan1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|comparator|LessThan1~2_combout\ = (!\datapath|total|q\(5) & (!\datapath|total|q\(4) & (!\datapath|total|q\(6) & !\datapath|comparator|LessThan1~1_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(5),
	datab => \datapath|total|q\(4),
	datac => \datapath|total|q\(6),
	datad => \datapath|comparator|LessThan1~1_combout\,
	combout => \datapath|comparator|LessThan1~2_combout\);

-- Location: LCCOMB_X55_Y50_N24
\controller|comb_proc~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|comb_proc~0_combout\ = (\datapath|total|q\(7)) # ((\e~input_o\) # (\datapath|comparator|LessThan1~2_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \datapath|total|q\(7),
	datac => \e~input_o\,
	datad => \datapath|comparator|LessThan1~2_combout\,
	combout => \controller|comb_proc~0_combout\);

-- Location: LCCOMB_X55_Y50_N18
\controller|Selector4~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector4~0_combout\ = (\controller|PS.S1~q\ & (!\controller|comb_proc~1_combout\ & (!\controller|NS~6_combout\ & !\controller|comb_proc~0_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S1~q\,
	datab => \controller|comb_proc~1_combout\,
	datac => \controller|NS~6_combout\,
	datad => \controller|comb_proc~0_combout\,
	combout => \controller|Selector4~0_combout\);

-- Location: FF_X55_Y50_N19
\controller|PS.S4\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector4~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S4~q\);

-- Location: LCCOMB_X55_Y50_N16
\controller|PS.S0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|PS.S0~0_combout\ = !\controller|PS.S4~q\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \controller|PS.S4~q\,
	combout => \controller|PS.S0~0_combout\);

-- Location: LCCOMB_X54_Y50_N4
\controller|PS.S0~feeder\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|PS.S0~feeder_combout\ = \controller|PS.S0~0_combout\

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datad => \controller|PS.S0~0_combout\,
	combout => \controller|PS.S0~feeder_combout\);

-- Location: FF_X54_Y50_N5
\controller|PS.S0\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|PS.S0~feeder_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S0~q\);

-- Location: FF_X54_Y50_N9
\datapath|total|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[0]~8_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(0));

-- Location: LCCOMB_X54_Y50_N10
\datapath|total|q[1]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[1]~10_combout\ = (\datapath|total|q\(1) & ((\a[1]~input_o\ & (\datapath|total|q[0]~9\ & VCC)) # (!\a[1]~input_o\ & (!\datapath|total|q[0]~9\)))) # (!\datapath|total|q\(1) & ((\a[1]~input_o\ & (!\datapath|total|q[0]~9\)) # 
-- (!\a[1]~input_o\ & ((\datapath|total|q[0]~9\) # (GND)))))
-- \datapath|total|q[1]~11\ = CARRY((\datapath|total|q\(1) & (!\a[1]~input_o\ & !\datapath|total|q[0]~9\)) # (!\datapath|total|q\(1) & ((!\datapath|total|q[0]~9\) # (!\a[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(1),
	datab => \a[1]~input_o\,
	datad => VCC,
	cin => \datapath|total|q[0]~9\,
	combout => \datapath|total|q[1]~10_combout\,
	cout => \datapath|total|q[1]~11\);

-- Location: FF_X54_Y50_N11
\datapath|total|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[1]~10_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(1));

-- Location: LCCOMB_X54_Y50_N12
\datapath|total|q[2]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[2]~12_combout\ = ((\a[2]~input_o\ $ (\datapath|total|q\(2) $ (!\datapath|total|q[1]~11\)))) # (GND)
-- \datapath|total|q[2]~13\ = CARRY((\a[2]~input_o\ & ((\datapath|total|q\(2)) # (!\datapath|total|q[1]~11\))) # (!\a[2]~input_o\ & (\datapath|total|q\(2) & !\datapath|total|q[1]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \a[2]~input_o\,
	datab => \datapath|total|q\(2),
	datad => VCC,
	cin => \datapath|total|q[1]~11\,
	combout => \datapath|total|q[2]~12_combout\,
	cout => \datapath|total|q[2]~13\);

-- Location: FF_X54_Y50_N13
\datapath|total|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[2]~12_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(2));

-- Location: LCCOMB_X54_Y50_N14
\datapath|total|q[3]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[3]~14_combout\ = (\datapath|total|q\(3) & (!\datapath|total|q[2]~13\)) # (!\datapath|total|q\(3) & ((\datapath|total|q[2]~13\) # (GND)))
-- \datapath|total|q[3]~15\ = CARRY((!\datapath|total|q[2]~13\) # (!\datapath|total|q\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapath|total|q\(3),
	datad => VCC,
	cin => \datapath|total|q[2]~13\,
	combout => \datapath|total|q[3]~14_combout\,
	cout => \datapath|total|q[3]~15\);

-- Location: FF_X54_Y50_N15
\datapath|total|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[3]~14_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(3));

-- Location: LCCOMB_X54_Y50_N16
\datapath|total|q[4]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[4]~16_combout\ = (\datapath|total|q\(4) & (\datapath|total|q[3]~15\ $ (GND))) # (!\datapath|total|q\(4) & (!\datapath|total|q[3]~15\ & VCC))
-- \datapath|total|q[4]~17\ = CARRY((\datapath|total|q\(4) & !\datapath|total|q[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapath|total|q\(4),
	datad => VCC,
	cin => \datapath|total|q[3]~15\,
	combout => \datapath|total|q[4]~16_combout\,
	cout => \datapath|total|q[4]~17\);

-- Location: FF_X54_Y50_N17
\datapath|total|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[4]~16_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(4));

-- Location: LCCOMB_X54_Y50_N18
\datapath|total|q[5]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[5]~18_combout\ = (\datapath|total|q\(5) & (!\datapath|total|q[4]~17\)) # (!\datapath|total|q\(5) & ((\datapath|total|q[4]~17\) # (GND)))
-- \datapath|total|q[5]~19\ = CARRY((!\datapath|total|q[4]~17\) # (!\datapath|total|q\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(5),
	datad => VCC,
	cin => \datapath|total|q[4]~17\,
	combout => \datapath|total|q[5]~18_combout\,
	cout => \datapath|total|q[5]~19\);

-- Location: FF_X54_Y50_N19
\datapath|total|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[5]~18_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(5));

-- Location: LCCOMB_X54_Y50_N20
\datapath|total|q[6]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[6]~20_combout\ = (\datapath|total|q\(6) & (\datapath|total|q[5]~19\ $ (GND))) # (!\datapath|total|q\(6) & (!\datapath|total|q[5]~19\ & VCC))
-- \datapath|total|q[6]~21\ = CARRY((\datapath|total|q\(6) & !\datapath|total|q[5]~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \datapath|total|q\(6),
	datad => VCC,
	cin => \datapath|total|q[5]~19\,
	combout => \datapath|total|q[6]~20_combout\,
	cout => \datapath|total|q[6]~21\);

-- Location: FF_X54_Y50_N21
\datapath|total|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[6]~20_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(6));

-- Location: LCCOMB_X54_Y50_N22
\datapath|total|q[7]~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \datapath|total|q[7]~22_combout\ = \datapath|total|q\(7) $ (\datapath|total|q[6]~21\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|total|q\(7),
	cin => \datapath|total|q[6]~21\,
	combout => \datapath|total|q[7]~22_combout\);

-- Location: FF_X54_Y50_N23
\datapath|total|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \datapath|total|q[7]~22_combout\,
	clrn => \controller|PS.S0~q\,
	ena => \controller|PS.S2~q\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \datapath|total|q\(7));

-- Location: LCCOMB_X54_Y50_N24
\controller|NS~5\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|NS~5_combout\ = (!\m~input_o\ & ((\e~input_o\ & (\datapath|coin_detector|c~0_combout\)) # (!\e~input_o\ & ((\datapath|total|q\(7))))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010001010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m~input_o\,
	datab => \datapath|coin_detector|c~0_combout\,
	datac => \datapath|total|q\(7),
	datad => \e~input_o\,
	combout => \controller|NS~5_combout\);

-- Location: LCCOMB_X54_Y50_N6
\controller|NS~6\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|NS~6_combout\ = (\controller|NS~5_combout\) # ((!\m~input_o\ & (!\e~input_o\ & \datapath|comparator|LessThan1~2_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \m~input_o\,
	datab => \controller|NS~5_combout\,
	datac => \e~input_o\,
	datad => \datapath|comparator|LessThan1~2_combout\,
	combout => \controller|NS~6_combout\);

-- Location: LCCOMB_X54_Y50_N30
\controller|Selector2~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector2~0_combout\ = (\controller|PS.S1~q\ & (\controller|comb_proc~1_combout\ & !\controller|NS~6_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S1~q\,
	datab => \controller|comb_proc~1_combout\,
	datad => \controller|NS~6_combout\,
	combout => \controller|Selector2~0_combout\);

-- Location: FF_X54_Y50_N31
\controller|PS.S2\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector2~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S2~q\);

-- Location: LCCOMB_X55_Y50_N6
\controller|Selector3~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector3~0_combout\ = (\controller|PS.S2~q\) # ((!\datapath|coin_detector|c~0_combout\ & \controller|PS.S3~q\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111101010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \datapath|coin_detector|c~0_combout\,
	datac => \controller|PS.S3~q\,
	datad => \controller|PS.S2~q\,
	combout => \controller|Selector3~0_combout\);

-- Location: FF_X55_Y50_N7
\controller|PS.S3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S3~q\);

-- Location: LCCOMB_X55_Y50_N4
\controller|Selector1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~0_combout\ = (\controller|PS.S3~q\ & ((\a[1]~input_o\ & ((\a[2]~input_o\) # (\a[0]~input_o\))) # (!\a[1]~input_o\ & (\a[2]~input_o\ $ (!\a[0]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110100100000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \a[1]~input_o\,
	datab => \a[2]~input_o\,
	datac => \a[0]~input_o\,
	datad => \controller|PS.S3~q\,
	combout => \controller|Selector1~0_combout\);

-- Location: LCCOMB_X55_Y50_N14
\controller|Selector1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~1_combout\ = ((!\m~input_o\ & \controller|PS.S5~q\)) # (!\controller|PS.S0~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \m~input_o\,
	datac => \controller|PS.S0~q\,
	datad => \controller|PS.S5~q\,
	combout => \controller|Selector1~1_combout\);

-- Location: LCCOMB_X54_Y50_N26
\controller|Selector1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector1~2_combout\ = (\controller|Selector1~0_combout\) # ((\controller|Selector1~1_combout\) # ((\controller|PS.S1~q\ & \controller|NS~6_combout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|Selector1~0_combout\,
	datab => \controller|Selector1~1_combout\,
	datac => \controller|PS.S1~q\,
	datad => \controller|NS~6_combout\,
	combout => \controller|Selector1~2_combout\);

-- Location: FF_X54_Y50_N27
\controller|PS.S1\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector1~2_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S1~q\);

-- Location: LCCOMB_X55_Y50_N20
\controller|Selector5~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \controller|Selector5~0_combout\ = (\m~input_o\ & ((\controller|PS.S5~q\) # ((\controller|PS.S1~q\ & \controller|comb_proc~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100100011000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \controller|PS.S1~q\,
	datab => \m~input_o\,
	datac => \controller|PS.S5~q\,
	datad => \controller|comb_proc~0_combout\,
	combout => \controller|Selector5~0_combout\);

-- Location: FF_X55_Y50_N21
\controller|PS.S5\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clock_div|clk~clkctrl_outclk\,
	d => \controller|Selector5~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \controller|PS.S5~q\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_end_addr => -1,
	addr_range2_offset => -1,
	addr_range3_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_sys_on <= \sys_on~output_o\;

ww_d <= \d~output_o\;

ww_tot_coins(0) <= \tot_coins[0]~output_o\;

ww_tot_coins(1) <= \tot_coins[1]~output_o\;

ww_tot_coins(2) <= \tot_coins[2]~output_o\;

ww_tot_coins(3) <= \tot_coins[3]~output_o\;

ww_tot_coins(4) <= \tot_coins[4]~output_o\;

ww_tot_coins(5) <= \tot_coins[5]~output_o\;

ww_tot_coins(6) <= \tot_coins[6]~output_o\;

ww_tot_coins(7) <= \tot_coins[7]~output_o\;
END structure;


