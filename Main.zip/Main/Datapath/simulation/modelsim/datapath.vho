-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.0 Build 711 06/05/2020 SJ Lite Edition"

-- DATE "10/06/2026 18:19:55"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY ALTERA;
LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	datapath IS
    PORT (
	tot_ld : IN std_logic;
	tot_clr : IN std_logic;
	clk_sys : IN std_logic;
	A : IN std_logic_vector(2 DOWNTO 0);
	R : IN std_logic_vector(1 DOWNTO 0);
	tot_lt_s : OUT std_logic;
	c : OUT std_logic;
	tot_coins : OUT std_logic_vector(7 DOWNTO 0)
	);
END datapath;

-- Design Ports Information
-- tot_lt_s	=>  Location: PIN_B4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- c	=>  Location: PIN_C2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[0]	=>  Location: PIN_B2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[1]	=>  Location: PIN_E6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[2]	=>  Location: PIN_B3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[3]	=>  Location: PIN_A2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[4]	=>  Location: PIN_B5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[5]	=>  Location: PIN_A3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[6]	=>  Location: PIN_D5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_coins[7]	=>  Location: PIN_C3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- R[0]	=>  Location: PIN_D6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- R[1]	=>  Location: PIN_E8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[2]	=>  Location: PIN_F7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[0]	=>  Location: PIN_C4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- A[1]	=>  Location: PIN_C5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk_sys	=>  Location: PIN_M8,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_clr	=>  Location: PIN_M9,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- tot_ld	=>  Location: PIN_B1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF datapath IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_tot_ld : std_logic;
SIGNAL ww_tot_clr : std_logic;
SIGNAL ww_clk_sys : std_logic;
SIGNAL ww_A : std_logic_vector(2 DOWNTO 0);
SIGNAL ww_R : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_tot_lt_s : std_logic;
SIGNAL ww_c : std_logic;
SIGNAL ww_tot_coins : std_logic_vector(7 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \tot_clr~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \clk_sys~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \tot_lt_s~output_o\ : std_logic;
SIGNAL \c~output_o\ : std_logic;
SIGNAL \tot_coins[0]~output_o\ : std_logic;
SIGNAL \tot_coins[1]~output_o\ : std_logic;
SIGNAL \tot_coins[2]~output_o\ : std_logic;
SIGNAL \tot_coins[3]~output_o\ : std_logic;
SIGNAL \tot_coins[4]~output_o\ : std_logic;
SIGNAL \tot_coins[5]~output_o\ : std_logic;
SIGNAL \tot_coins[6]~output_o\ : std_logic;
SIGNAL \tot_coins[7]~output_o\ : std_logic;
SIGNAL \clk_sys~input_o\ : std_logic;
SIGNAL \clk_sys~inputclkctrl_outclk\ : std_logic;
SIGNAL \A[2]~input_o\ : std_logic;
SIGNAL \A[1]~input_o\ : std_logic;
SIGNAL \A[0]~input_o\ : std_logic;
SIGNAL \total|q[0]~8_combout\ : std_logic;
SIGNAL \tot_clr~input_o\ : std_logic;
SIGNAL \tot_clr~inputclkctrl_outclk\ : std_logic;
SIGNAL \tot_ld~input_o\ : std_logic;
SIGNAL \total|q[0]~9\ : std_logic;
SIGNAL \total|q[1]~10_combout\ : std_logic;
SIGNAL \total|q[1]~11\ : std_logic;
SIGNAL \total|q[2]~12_combout\ : std_logic;
SIGNAL \total|q[2]~13\ : std_logic;
SIGNAL \total|q[3]~14_combout\ : std_logic;
SIGNAL \total|q[3]~15\ : std_logic;
SIGNAL \total|q[4]~16_combout\ : std_logic;
SIGNAL \total|q[4]~17\ : std_logic;
SIGNAL \total|q[5]~18_combout\ : std_logic;
SIGNAL \total|q[5]~19\ : std_logic;
SIGNAL \total|q[6]~20_combout\ : std_logic;
SIGNAL \comparator|LessThan1~0_combout\ : std_logic;
SIGNAL \total|q[6]~21\ : std_logic;
SIGNAL \total|q[7]~22_combout\ : std_logic;
SIGNAL \R[1]~input_o\ : std_logic;
SIGNAL \comparator|LessThan1~1_combout\ : std_logic;
SIGNAL \R[0]~input_o\ : std_logic;
SIGNAL \comparator|LessThan1~2_combout\ : std_logic;
SIGNAL \comparator|LessThan1~3_combout\ : std_logic;
SIGNAL \coin_detector|c~combout\ : std_logic;
SIGNAL \total|q\ : std_logic_vector(7 DOWNTO 0);
SIGNAL \ALT_INV_tot_clr~inputclkctrl_outclk\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_tot_ld <= tot_ld;
ww_tot_clr <= tot_clr;
ww_clk_sys <= clk_sys;
ww_A <= A;
ww_R <= R;
tot_lt_s <= ww_tot_lt_s;
c <= ww_c;
tot_coins <= ww_tot_coins;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\tot_clr~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \tot_clr~input_o\);

\clk_sys~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk_sys~input_o\);
\ALT_INV_tot_clr~inputclkctrl_outclk\ <= NOT \tot_clr~inputclkctrl_outclk\;
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y41_N24
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X26_Y39_N23
\tot_lt_s~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \comparator|LessThan1~3_combout\,
	devoe => ww_devoe,
	o => \tot_lt_s~output_o\);

-- Location: IOOBUF_X20_Y39_N16
\c~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \coin_detector|c~combout\,
	devoe => ww_devoe,
	o => \c~output_o\);

-- Location: IOOBUF_X22_Y39_N16
\tot_coins[0]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(0),
	devoe => ww_devoe,
	o => \tot_coins[0]~output_o\);

-- Location: IOOBUF_X20_Y39_N2
\tot_coins[1]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(1),
	devoe => ww_devoe,
	o => \tot_coins[1]~output_o\);

-- Location: IOOBUF_X26_Y39_N16
\tot_coins[2]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(2),
	devoe => ww_devoe,
	o => \tot_coins[2]~output_o\);

-- Location: IOOBUF_X26_Y39_N2
\tot_coins[3]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(3),
	devoe => ww_devoe,
	o => \tot_coins[3]~output_o\);

-- Location: IOOBUF_X26_Y39_N30
\tot_coins[4]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(4),
	devoe => ww_devoe,
	o => \tot_coins[4]~output_o\);

-- Location: IOOBUF_X26_Y39_N9
\tot_coins[5]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(5),
	devoe => ww_devoe,
	o => \tot_coins[5]~output_o\);

-- Location: IOOBUF_X24_Y39_N30
\tot_coins[6]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(6),
	devoe => ww_devoe,
	o => \tot_coins[6]~output_o\);

-- Location: IOOBUF_X20_Y39_N9
\tot_coins[7]~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \total|q\(7),
	devoe => ww_devoe,
	o => \tot_coins[7]~output_o\);

-- Location: IOIBUF_X0_Y18_N15
\clk_sys~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk_sys,
	o => \clk_sys~input_o\);

-- Location: CLKCTRL_G3
\clk_sys~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk_sys~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk_sys~inputclkctrl_outclk\);

-- Location: IOIBUF_X24_Y39_N15
\A[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(2),
	o => \A[2]~input_o\);

-- Location: IOIBUF_X24_Y39_N22
\A[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(1),
	o => \A[1]~input_o\);

-- Location: IOIBUF_X24_Y39_N1
\A[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_A(0),
	o => \A[0]~input_o\);

-- Location: LCCOMB_X24_Y35_N8
\total|q[0]~8\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[0]~8_combout\ = (\A[0]~input_o\ & (\total|q\(0) $ (VCC))) # (!\A[0]~input_o\ & (\total|q\(0) & VCC))
-- \total|q[0]~9\ = CARRY((\A[0]~input_o\ & \total|q\(0)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011010001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A[0]~input_o\,
	datab => \total|q\(0),
	datad => VCC,
	combout => \total|q[0]~8_combout\,
	cout => \total|q[0]~9\);

-- Location: IOIBUF_X0_Y18_N22
\tot_clr~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tot_clr,
	o => \tot_clr~input_o\);

-- Location: CLKCTRL_G4
\tot_clr~inputclkctrl\ : fiftyfivenm_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \tot_clr~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \tot_clr~inputclkctrl_outclk\);

-- Location: IOIBUF_X22_Y39_N22
\tot_ld~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_tot_ld,
	o => \tot_ld~input_o\);

-- Location: FF_X24_Y35_N9
\total|q[0]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[0]~8_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(0));

-- Location: LCCOMB_X24_Y35_N10
\total|q[1]~10\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[1]~10_combout\ = (\total|q\(1) & ((\A[1]~input_o\ & (\total|q[0]~9\ & VCC)) # (!\A[1]~input_o\ & (!\total|q[0]~9\)))) # (!\total|q\(1) & ((\A[1]~input_o\ & (!\total|q[0]~9\)) # (!\A[1]~input_o\ & ((\total|q[0]~9\) # (GND)))))
-- \total|q[1]~11\ = CARRY((\total|q\(1) & (!\A[1]~input_o\ & !\total|q[0]~9\)) # (!\total|q\(1) & ((!\total|q[0]~9\) # (!\A[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001011000010111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(1),
	datab => \A[1]~input_o\,
	datad => VCC,
	cin => \total|q[0]~9\,
	combout => \total|q[1]~10_combout\,
	cout => \total|q[1]~11\);

-- Location: FF_X24_Y35_N11
\total|q[1]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[1]~10_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(1));

-- Location: LCCOMB_X24_Y35_N12
\total|q[2]~12\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[2]~12_combout\ = ((\total|q\(2) $ (\A[2]~input_o\ $ (!\total|q[1]~11\)))) # (GND)
-- \total|q[2]~13\ = CARRY((\total|q\(2) & ((\A[2]~input_o\) # (!\total|q[1]~11\))) # (!\total|q\(2) & (\A[2]~input_o\ & !\total|q[1]~11\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110100110001110",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(2),
	datab => \A[2]~input_o\,
	datad => VCC,
	cin => \total|q[1]~11\,
	combout => \total|q[2]~12_combout\,
	cout => \total|q[2]~13\);

-- Location: FF_X24_Y35_N13
\total|q[2]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[2]~12_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(2));

-- Location: LCCOMB_X24_Y35_N14
\total|q[3]~14\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[3]~14_combout\ = (\total|q\(3) & (!\total|q[2]~13\)) # (!\total|q\(3) & ((\total|q[2]~13\) # (GND)))
-- \total|q[3]~15\ = CARRY((!\total|q[2]~13\) # (!\total|q\(3)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|q\(3),
	datad => VCC,
	cin => \total|q[2]~13\,
	combout => \total|q[3]~14_combout\,
	cout => \total|q[3]~15\);

-- Location: FF_X24_Y35_N15
\total|q[3]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[3]~14_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(3));

-- Location: LCCOMB_X24_Y35_N16
\total|q[4]~16\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[4]~16_combout\ = (\total|q\(4) & (\total|q[3]~15\ $ (GND))) # (!\total|q\(4) & (!\total|q[3]~15\ & VCC))
-- \total|q[4]~17\ = CARRY((\total|q\(4) & !\total|q[3]~15\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|q\(4),
	datad => VCC,
	cin => \total|q[3]~15\,
	combout => \total|q[4]~16_combout\,
	cout => \total|q[4]~17\);

-- Location: FF_X24_Y35_N17
\total|q[4]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[4]~16_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(4));

-- Location: LCCOMB_X24_Y35_N18
\total|q[5]~18\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[5]~18_combout\ = (\total|q\(5) & (!\total|q[4]~17\)) # (!\total|q\(5) & ((\total|q[4]~17\) # (GND)))
-- \total|q[5]~19\ = CARRY((!\total|q[4]~17\) # (!\total|q\(5)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110000111111",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|q\(5),
	datad => VCC,
	cin => \total|q[4]~17\,
	combout => \total|q[5]~18_combout\,
	cout => \total|q[5]~19\);

-- Location: FF_X24_Y35_N19
\total|q[5]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[5]~18_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(5));

-- Location: LCCOMB_X24_Y35_N20
\total|q[6]~20\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[6]~20_combout\ = (\total|q\(6) & (\total|q[5]~19\ $ (GND))) # (!\total|q\(6) & (!\total|q[5]~19\ & VCC))
-- \total|q[6]~21\ = CARRY((\total|q\(6) & !\total|q[5]~19\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001100001100",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	datab => \total|q\(6),
	datad => VCC,
	cin => \total|q[5]~19\,
	combout => \total|q[6]~20_combout\,
	cout => \total|q[6]~21\);

-- Location: FF_X24_Y35_N21
\total|q[6]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[6]~20_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(6));

-- Location: LCCOMB_X24_Y35_N24
\comparator|LessThan1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator|LessThan1~0_combout\ = (\total|q\(4)) # ((\total|q\(5)) # (\total|q\(6)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \total|q\(4),
	datac => \total|q\(5),
	datad => \total|q\(6),
	combout => \comparator|LessThan1~0_combout\);

-- Location: LCCOMB_X24_Y35_N22
\total|q[7]~22\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \total|q[7]~22_combout\ = \total|q\(7) $ (\total|q[6]~21\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101101001011010",
	sum_lutc_input => "cin")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(7),
	cin => \total|q[6]~21\,
	combout => \total|q[7]~22_combout\);

-- Location: FF_X24_Y35_N23
\total|q[7]\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk_sys~inputclkctrl_outclk\,
	d => \total|q[7]~22_combout\,
	clrn => \ALT_INV_tot_clr~inputclkctrl_outclk\,
	ena => \tot_ld~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \total|q\(7));

-- Location: IOIBUF_X24_Y39_N8
\R[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_R(1),
	o => \R[1]~input_o\);

-- Location: LCCOMB_X24_Y35_N26
\comparator|LessThan1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator|LessThan1~1_combout\ = (\total|q\(1) & (!\total|q\(2) & !\R[1]~input_o\)) # (!\total|q\(1) & (\total|q\(2) & \R[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101000000001010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(1),
	datac => \total|q\(2),
	datad => \R[1]~input_o\,
	combout => \comparator|LessThan1~1_combout\);

-- Location: IOIBUF_X22_Y39_N29
\R[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_R(0),
	o => \R[0]~input_o\);

-- Location: LCCOMB_X24_Y35_N28
\comparator|LessThan1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator|LessThan1~2_combout\ = (\comparator|LessThan1~1_combout\ & (((\total|q\(0) & !\total|q\(2))) # (!\R[0]~input_o\))) # (!\comparator|LessThan1~1_combout\ & (((\total|q\(2)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(0),
	datab => \total|q\(2),
	datac => \comparator|LessThan1~1_combout\,
	datad => \R[0]~input_o\,
	combout => \comparator|LessThan1~2_combout\);

-- Location: LCCOMB_X24_Y35_N2
\comparator|LessThan1~3\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \comparator|LessThan1~3_combout\ = (\total|q\(7)) # ((!\comparator|LessThan1~0_combout\ & ((!\comparator|LessThan1~2_combout\) # (!\total|q\(3)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000111110011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \total|q\(3),
	datab => \comparator|LessThan1~0_combout\,
	datac => \total|q\(7),
	datad => \comparator|LessThan1~2_combout\,
	combout => \comparator|LessThan1~3_combout\);

-- Location: LCCOMB_X24_Y35_N0
\coin_detector|c\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \coin_detector|c~combout\ = (\A[2]~input_o\ & (!\A[0]~input_o\ & !\A[1]~input_o\)) # (!\A[2]~input_o\ & (\A[0]~input_o\ $ (\A[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010101011010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \A[2]~input_o\,
	datac => \A[0]~input_o\,
	datad => \A[1]~input_o\,
	combout => \coin_detector|c~combout\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_end_addr => -1,
	addr_range2_offset => -1,
	addr_range3_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_tot_lt_s <= \tot_lt_s~output_o\;

ww_c <= \c~output_o\;

ww_tot_coins(0) <= \tot_coins[0]~output_o\;

ww_tot_coins(1) <= \tot_coins[1]~output_o\;

ww_tot_coins(2) <= \tot_coins[2]~output_o\;

ww_tot_coins(3) <= \tot_coins[3]~output_o\;

ww_tot_coins(4) <= \tot_coins[4]~output_o\;

ww_tot_coins(5) <= \tot_coins[5]~output_o\;

ww_tot_coins(6) <= \tot_coins[6]~output_o\;

ww_tot_coins(7) <= \tot_coins[7]~output_o\;
END structure;


