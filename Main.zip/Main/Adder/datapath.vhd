library IEEE;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity datapath is
 port(
	tot_ld, tot_clr : in std_logic;
	clk_sys : in std_logic;
	A : in std_logic_vector(2 downto 0);
	R : in std_logic_vector(1 downto 0);
	tot_lt_s, c : out std_logic;
	tot_coins : out std_logic_vector(7 downto 0)
	);
end datapath;

architecture arch of datapath is

	signal total_q 	: std_logic_vector(7 downto 0) := x"00";
	signal a_extended : std_logic_vector(7 downto 0) := x"00";
	signal adder_s 	: std_logic_vector(7 downto 0) := x"00";
	signal soda_selector_s : std_logic_vector(7 downto 0) := x"00";

begin

	-- instância do registrador total
	total: entity work.total 
		port map (
			clock 	=> clk_sys,
			ld 	=> tot_ld,
			clr 	=> tot_clr,
			I		=> adder_s,
			Q		=> total_q
		);
	
	-- instância do somador
	adder: entity work.adder 
		port map (
			A 	=> total_q,
			B 	=> a_extended,
			S	=>	adder_s	
		);
	
	-- 
	a_extended <= "00000" & A;
	
	soda_selector: entity work.soda_selector
		port map(
			r => R,
			s => soda_selector_s
		);
		
	comparator: entity work.comparator
		port map(
			a => total_q,
			b => soda_selector_s,
			lt => tot_lt_s
		);
		
	coin_detector: entity work.coin_detector
		port map(
			a2 => A(2),
			a1 => A(1),
			a0 => A(0),
			c => c
		);
		
	tot_coins <= total_q;
		
end arch;