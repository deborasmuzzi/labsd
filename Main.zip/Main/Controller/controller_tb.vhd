
library IEEE;
use IEEE.std_logic_1164.all;


entity tb_controller is
end entity tb_controller;


architecture arch of tb_controller is 
	signal clk_tb : std_logic := '0';
	signal e_tb, m_tb, c_tb, tot_lt_s_tb : std_logic := '0';
	signal d_tb, tot_clr_tb, tot_ld_tb, sys_on_tb	: std_logic;
	signal estado_atual_tb : std_logic_vector(2 downto 0);
	
begin 
	dut: entity work.controller
	port map (
	e => e_tb,
	m => m_tb,
	c => c_tb,
	tot_lt_s => tot_lt_s_tb,
	clk => clk_tb,
	d => d_tb,
	tot_clr => tot_clr_tb,
	tot_ld => tot_ld_tb,
	sys_on => sys_on_tb,
	estado_atual => estado_atual_tb
	);
	
	clk_tb <= not clk_tb after 10 ns;
	
	stimulus: process 
	begin
	
	wait for 5ns;
	e_tb <= '0'; m_tb <= '0'; c_tb <= '0'; tot_lt_s_tb <= '1';
	wait for 60 ns;
	
	e_tb <= '1';
	c_tb <= '1';
	wait for 60 ns;
	
	c_tb <= '0';
	wait for 30 ns;
	
	m_tb <= '1';
	wait for 60 ns;
	
	m_tb <= '0';
		wait for 30 ns;
	
	tot_lt_s_tb <= '0';
	e_tb <= '0';
	wait for 60 ns;
	
	wait;
	end process;
end;
	

