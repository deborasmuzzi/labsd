	-- Máquina de Refrigerantes
-- Laboratório de Sistemas Digitais
-- Universidade Federal de Minas Gerais
-- Julho de 2026
--
-- Arquivo: controller.vhd
-- Bloco de controle

-- Inclusão de bibliotecas
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

-- declaração da interface da entity
entity controller is
	PORT(
		e, m, clk						: in 	STD_LOGIC;
		c, tot_lt_s						: in 	STD_LOGIC;
		d, tot_clr, tot_ld, sys_on	: out STD_LOGIC;
		estado_atual: out STD_LOGIC_VECTOR(2 downto 0)	-- apenas para mostrar o estado no LED
	);
end;

-- INPUTS
-- 	Switches: 		
--			SW0: c
--			SW1: m
--			SW2: tot_lt_s
-- 	Push-buttons:	
-- 		KEY0: clk
--			KEY1: e
-- OUTPUTs
-- 		LEDR0: sys_on
--			LEDR1: tot_clr
--			LEDR2: tot_ld
--			LEDR3: d
-- ESTADOS - LED07 A 09 (a3a2a0, respectivamente)
-- 	S0: 000 
---	S1: 001
-- 	S2: 010
--	   S3: 011
--	 	S4: 100
-- 	S5: 101


architecture fsm of controller is
-- declaração de sinais e de tipos definidos pelo usuário
	type state_type is (S0, S1, S2, S3, S4, S5);
	signal PS : state_type := S0;
	signal NS : state_type;
		

begin

	-- processo 1
	 sync_proc: process (clk)
		begin
		if(rising_edge(clk)) then
			PS <= NS;
		end if;
		end process sync_proc;
			
	-- processo 2
		comb_proc : process (PS, c, m, e, tot_lt_s)
		begin
		sys_on <= '1';
		tot_clr <= '0';
		tot_ld <= '0';
		d <= '0';
		
		NS <= PS;
		
		case PS is
			when S0 =>
				tot_clr <= '1';
				NS <= S1;
				
			when S1 =>
				if(e = '1' and c = '1' and m = '0') then NS <= S2;
				elsif(e = '0' and tot_lt_s = '0') then NS <= S4;
				elsif( m = '1') then NS <= S5;
				end if;
				
			when S2 => 
				tot_ld <= '1';
				NS <= S3;
				
			when S3 =>
				if (c = '0') then NS <= S1;
				elsif(c = '0') then NS <= S3;
				end if;
				
			when S4 =>
				d <= '1';
				NS <= S0;
				
			when S5 =>
				sys_on <= '0';
				if(m = '1') then 	NS <= S5;
				else	NS <= S1;
				end if;
				
			when others =>
				NS <= S0;
			end case;
		end process comb_proc;	
		
		with PS select 
			estado_atual <= "000" when S0,
									"001" when S1,
									"010" when S2,
									"011" when S3,
									"100" when S4,
									"101" when S5,
									"000" when others;
			
-- 	S0: 000 
---	S1: 001
-- 	S2: 010
--	   S3: 011
--	 	S4: 100
-- 	S5: 101
end fsm;