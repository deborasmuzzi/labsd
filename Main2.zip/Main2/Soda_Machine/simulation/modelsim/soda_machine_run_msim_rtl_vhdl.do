transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {/home/usuario/lab_sd08/Main2/Total/total.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Soda_selector/soda_selector.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Comparator/comparator.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Coin_Detector/coin_detector.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Adder/adder.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Soda_Machine/clock_div.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Controller/controller.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Datapath/datapath.vhd}
vcom -93 -work work {/home/usuario/lab_sd08/Main2/Soda_Machine/soda_machine.vhd}

