
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;


entity adder is
	PORT(
		A, B 	: in 	STD_LOGIC_VECTOR(7 downto 0); 
		sel : in std_logic;
		S		: out	STD_LOGIC_VECTOR(7 downto 0);
		P : in std_logic_vector (7 downto 0)
	);
end;


architecture arch of adder is

begin
	with sel select 
	S <= std_logic_vector(unsigned(A) + unsigned(B)) when '0',
			std_logic_vector(unsigned(A) - unsigned(P)) when '1';

end;
