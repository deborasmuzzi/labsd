library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

-- Entity declaration
entity tb_comparator is
end tb_comparator;

-- Architecture declaration
architecture test of tb_comparator is

	-- Component declaration
	component comparator is
		generic(
			data_width : natural := 8
		);
		port(
			a, b : in std_logic_vector((data_width-1) downto 0);
			gt   : out std_logic;
			eq   : out std_logic;
			lt   : out std_logic
		);
	end component;

	signal pin_a, pin_b : std_logic_vector(3 downto 0);
	signal pin_gt, pin_eq, pin_lt : std_logic;

begin

	-- Instantiate the design under test
	-- The component is instantiated with 4-bit inputs to keep the simulation simple
	dut: comparator
		generic map(
			data_width => 4
			)
		port map(
			a  => pin_a,
			b  => pin_b,
			gt => pin_gt,
			eq => pin_eq,
			lt => pin_lt
			);

	-- Stimulus generation
	-- 4-bit input data is represented in hexadecimal notation using the prefix 'x'
	pin_a <= x"0", x"8" after 20 ns, x"7" after 40 ns, x"4" after 60 ns;
	pin_b <= x"0", x"7" after 10 ns, x"8" after 30 ns, x"1" after 50 ns;

end test;