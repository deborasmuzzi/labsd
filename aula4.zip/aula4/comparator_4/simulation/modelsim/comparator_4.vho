-- Copyright (C) 2020  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and any partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details, at
-- https://fpgasoftware.intel.com/eula.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 20.1.0 Build 711 06/05/2020 SJ Lite Edition"

-- DATE "09/01/2026 18:44:30"

-- 
-- Device: Altera 10M50DAF484C7G Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	hard_block IS
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic
	);
END hard_block;

-- Design Ports Information
-- ~ALTERA_TMS~	=>  Location: PIN_H2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TCK~	=>  Location: PIN_G2,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDI~	=>  Location: PIN_L4,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_TDO~	=>  Location: PIN_M5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_CONFIG_SEL~	=>  Location: PIN_H10,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- ~ALTERA_nCONFIG~	=>  Location: PIN_H9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_nSTATUS~	=>  Location: PIN_G9,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default
-- ~ALTERA_CONF_DONE~	=>  Location: PIN_F8,	 I/O Standard: 2.5 V Schmitt Trigger,	 Current Strength: Default


ARCHITECTURE structure OF hard_block IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL \~ALTERA_TMS~~padout\ : std_logic;
SIGNAL \~ALTERA_TCK~~padout\ : std_logic;
SIGNAL \~ALTERA_TDI~~padout\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~padout\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~padout\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~padout\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~padout\ : std_logic;
SIGNAL \~ALTERA_TMS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TCK~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_TDI~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONFIG_SEL~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nCONFIG~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_nSTATUS~~ibuf_o\ : std_logic;
SIGNAL \~ALTERA_CONF_DONE~~ibuf_o\ : std_logic;

BEGIN

ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;
END structure;


LIBRARY FIFTYFIVENM;
LIBRARY IEEE;
USE FIFTYFIVENM.FIFTYFIVENM_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	comparator_4 IS
    PORT (
	a_4 : IN std_logic_vector(3 DOWNTO 0);
	b_4 : IN std_logic_vector(3 DOWNTO 0);
	gt_4 : BUFFER std_logic;
	eq_4 : BUFFER std_logic;
	lt_4 : BUFFER std_logic
	);
END comparator_4;

-- Design Ports Information
-- gt_4	=>  Location: PIN_D14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- eq_4	=>  Location: PIN_A11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- lt_4	=>  Location: PIN_B11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b_4[3]	=>  Location: PIN_C11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a_4[2]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b_4[2]	=>  Location: PIN_D12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a_4[3]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a_4[1]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- a_4[0]	=>  Location: PIN_F15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b_4[0]	=>  Location: PIN_A12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- b_4[1]	=>  Location: PIN_C12,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF comparator_4 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_a_4 : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_b_4 : std_logic_vector(3 DOWNTO 0);
SIGNAL ww_gt_4 : std_logic;
SIGNAL ww_eq_4 : std_logic;
SIGNAL ww_lt_4 : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_ADC2~_CHSEL_bus\ : std_logic_vector(4 DOWNTO 0);
SIGNAL \~QUARTUS_CREATED_GND~I_combout\ : std_logic;
SIGNAL \~QUARTUS_CREATED_UNVM~~busy\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC1~~eoc\ : std_logic;
SIGNAL \~QUARTUS_CREATED_ADC2~~eoc\ : std_logic;
SIGNAL \gt_4~output_o\ : std_logic;
SIGNAL \eq_4~output_o\ : std_logic;
SIGNAL \lt_4~output_o\ : std_logic;
SIGNAL \b_4[3]~input_o\ : std_logic;
SIGNAL \a_4[3]~input_o\ : std_logic;
SIGNAL \b_4[2]~input_o\ : std_logic;
SIGNAL \a_4[2]~input_o\ : std_logic;
SIGNAL \dut|Equal0~0_combout\ : std_logic;
SIGNAL \b_4[1]~input_o\ : std_logic;
SIGNAL \b_4[0]~input_o\ : std_logic;
SIGNAL \a_4[0]~input_o\ : std_logic;
SIGNAL \a_4[1]~input_o\ : std_logic;
SIGNAL \dut|LessThan0~1_combout\ : std_logic;
SIGNAL \dut|LessThan0~0_combout\ : std_logic;
SIGNAL \dut|LessThan0~2_combout\ : std_logic;
SIGNAL \dut|Equal0~1_combout\ : std_logic;
SIGNAL \dut|Equal0~2_combout\ : std_logic;
SIGNAL \dut|LessThan1~1_combout\ : std_logic;
SIGNAL \dut|LessThan1~0_combout\ : std_logic;
SIGNAL \dut|LessThan1~2_combout\ : std_logic;

COMPONENT hard_block
    PORT (
	devoe : IN std_logic;
	devclrn : IN std_logic;
	devpor : IN std_logic);
END COMPONENT;

BEGIN

ww_a_4 <= a_4;
ww_b_4 <= b_4;
gt_4 <= ww_gt_4;
eq_4 <= ww_eq_4;
lt_4 <= ww_lt_4;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\~QUARTUS_CREATED_ADC1~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);

\~QUARTUS_CREATED_ADC2~_CHSEL_bus\ <= (\~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\ & \~QUARTUS_CREATED_GND~I_combout\);
auto_generated_inst : hard_block
PORT MAP (
	devoe => ww_devoe,
	devclrn => ww_devclrn,
	devpor => ww_devpor);

-- Location: LCCOMB_X44_Y52_N16
\~QUARTUS_CREATED_GND~I\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \~QUARTUS_CREATED_GND~I_combout\ = GND

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	combout => \~QUARTUS_CREATED_GND~I_combout\);

-- Location: IOOBUF_X56_Y54_N9
\gt_4~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \dut|LessThan0~2_combout\,
	devoe => ww_devoe,
	o => \gt_4~output_o\);

-- Location: IOOBUF_X51_Y54_N9
\eq_4~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \dut|Equal0~2_combout\,
	devoe => ww_devoe,
	o => \eq_4~output_o\);

-- Location: IOOBUF_X49_Y54_N9
\lt_4~output\ : fiftyfivenm_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \dut|LessThan1~2_combout\,
	devoe => ww_devoe,
	o => \lt_4~output_o\);

-- Location: IOIBUF_X51_Y54_N22
\b_4[3]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b_4(3),
	o => \b_4[3]~input_o\);

-- Location: IOIBUF_X54_Y54_N15
\a_4[3]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a_4(3),
	o => \a_4[3]~input_o\);

-- Location: IOIBUF_X51_Y54_N1
\b_4[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b_4(2),
	o => \b_4[2]~input_o\);

-- Location: IOIBUF_X58_Y54_N29
\a_4[2]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a_4(2),
	o => \a_4[2]~input_o\);

-- Location: LCCOMB_X54_Y53_N20
\dut|Equal0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|Equal0~0_combout\ = (\b_4[3]~input_o\ & (\a_4[3]~input_o\ & (\b_4[2]~input_o\ $ (!\a_4[2]~input_o\)))) # (!\b_4[3]~input_o\ & (!\a_4[3]~input_o\ & (\b_4[2]~input_o\ $ (!\a_4[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001000000001001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[3]~input_o\,
	datab => \a_4[3]~input_o\,
	datac => \b_4[2]~input_o\,
	datad => \a_4[2]~input_o\,
	combout => \dut|Equal0~0_combout\);

-- Location: IOIBUF_X54_Y54_N29
\b_4[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b_4(1),
	o => \b_4[1]~input_o\);

-- Location: IOIBUF_X54_Y54_N22
\b_4[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_b_4(0),
	o => \b_4[0]~input_o\);

-- Location: IOIBUF_X69_Y54_N1
\a_4[0]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a_4(0),
	o => \a_4[0]~input_o\);

-- Location: IOIBUF_X56_Y54_N1
\a_4[1]~input\ : fiftyfivenm_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	listen_to_nsleep_signal => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_a_4(1),
	o => \a_4[1]~input_o\);

-- Location: LCCOMB_X54_Y53_N26
\dut|LessThan0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan0~1_combout\ = (\b_4[1]~input_o\ & (!\b_4[0]~input_o\ & (\a_4[0]~input_o\ & \a_4[1]~input_o\))) # (!\b_4[1]~input_o\ & ((\a_4[1]~input_o\) # ((!\b_4[0]~input_o\ & \a_4[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111010100010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[1]~input_o\,
	datab => \b_4[0]~input_o\,
	datac => \a_4[0]~input_o\,
	datad => \a_4[1]~input_o\,
	combout => \dut|LessThan0~1_combout\);

-- Location: LCCOMB_X54_Y53_N0
\dut|LessThan0~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan0~0_combout\ = (\b_4[3]~input_o\ & (((!\b_4[2]~input_o\ & \a_4[2]~input_o\)) # (!\a_4[3]~input_o\))) # (!\b_4[3]~input_o\ & (!\a_4[3]~input_o\ & (!\b_4[2]~input_o\ & \a_4[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101100100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[3]~input_o\,
	datab => \a_4[3]~input_o\,
	datac => \b_4[2]~input_o\,
	datad => \a_4[2]~input_o\,
	combout => \dut|LessThan0~0_combout\);

-- Location: LCCOMB_X54_Y53_N22
\dut|LessThan0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan0~2_combout\ = (\dut|LessThan0~0_combout\) # ((\dut|Equal0~0_combout\ & \dut|LessThan0~1_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \dut|Equal0~0_combout\,
	datac => \dut|LessThan0~1_combout\,
	datad => \dut|LessThan0~0_combout\,
	combout => \dut|LessThan0~2_combout\);

-- Location: LCCOMB_X54_Y53_N16
\dut|Equal0~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|Equal0~1_combout\ = (\b_4[1]~input_o\ & (\a_4[1]~input_o\ & (\b_4[0]~input_o\ $ (!\a_4[0]~input_o\)))) # (!\b_4[1]~input_o\ & (!\a_4[1]~input_o\ & (\b_4[0]~input_o\ $ (!\a_4[0]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000001001000001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[1]~input_o\,
	datab => \b_4[0]~input_o\,
	datac => \a_4[0]~input_o\,
	datad => \a_4[1]~input_o\,
	combout => \dut|Equal0~1_combout\);

-- Location: LCCOMB_X54_Y53_N10
\dut|Equal0~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|Equal0~2_combout\ = (\dut|Equal0~0_combout\ & \dut|Equal0~1_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100110000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \dut|Equal0~0_combout\,
	datad => \dut|Equal0~1_combout\,
	combout => \dut|Equal0~2_combout\);

-- Location: LCCOMB_X54_Y53_N6
\dut|LessThan1~1\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan1~1_combout\ = (\b_4[1]~input_o\ & (((\b_4[0]~input_o\ & !\a_4[0]~input_o\)) # (!\a_4[1]~input_o\))) # (!\b_4[1]~input_o\ & (\b_4[0]~input_o\ & (!\a_4[0]~input_o\ & !\a_4[1]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100010101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[1]~input_o\,
	datab => \b_4[0]~input_o\,
	datac => \a_4[0]~input_o\,
	datad => \a_4[1]~input_o\,
	combout => \dut|LessThan1~1_combout\);

-- Location: LCCOMB_X54_Y53_N12
\dut|LessThan1~0\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan1~0_combout\ = (\b_4[3]~input_o\ & (\a_4[3]~input_o\ & (\b_4[2]~input_o\ & !\a_4[2]~input_o\))) # (!\b_4[3]~input_o\ & ((\a_4[3]~input_o\) # ((\b_4[2]~input_o\ & !\a_4[2]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100010011010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \b_4[3]~input_o\,
	datab => \a_4[3]~input_o\,
	datac => \b_4[2]~input_o\,
	datad => \a_4[2]~input_o\,
	combout => \dut|LessThan1~0_combout\);

-- Location: LCCOMB_X54_Y53_N24
\dut|LessThan1~2\ : fiftyfivenm_lcell_comb
-- Equation(s):
-- \dut|LessThan1~2_combout\ = (\dut|LessThan1~0_combout\) # ((\dut|LessThan1~1_combout\ & \dut|Equal0~0_combout\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111110001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \dut|LessThan1~1_combout\,
	datab => \dut|Equal0~0_combout\,
	datad => \dut|LessThan1~0_combout\,
	combout => \dut|LessThan1~2_combout\);

-- Location: UNVM_X0_Y40_N40
\~QUARTUS_CREATED_UNVM~\ : fiftyfivenm_unvm
-- pragma translate_off
GENERIC MAP (
	addr_range1_end_addr => -1,
	addr_range1_offset => -1,
	addr_range2_end_addr => -1,
	addr_range2_offset => -1,
	addr_range3_offset => -1,
	is_compressed_image => "false",
	is_dual_boot => "false",
	is_eram_skip => "false",
	max_ufm_valid_addr => -1,
	max_valid_addr => -1,
	min_ufm_valid_addr => -1,
	min_valid_addr => -1,
	part_name => "quartus_created_unvm",
	reserve_block => "true")
-- pragma translate_on
PORT MAP (
	nosc_ena => \~QUARTUS_CREATED_GND~I_combout\,
	xe_ye => \~QUARTUS_CREATED_GND~I_combout\,
	se => \~QUARTUS_CREATED_GND~I_combout\,
	busy => \~QUARTUS_CREATED_UNVM~~busy\);

-- Location: ADCBLOCK_X43_Y52_N0
\~QUARTUS_CREATED_ADC1~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 1,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC1~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC1~~eoc\);

-- Location: ADCBLOCK_X43_Y51_N0
\~QUARTUS_CREATED_ADC2~\ : fiftyfivenm_adcblock
-- pragma translate_off
GENERIC MAP (
	analog_input_pin_mask => 0,
	clkdiv => 1,
	device_partname_fivechar_prefix => "none",
	is_this_first_or_second_adc => 2,
	prescalar => 0,
	pwd => 1,
	refsel => 0,
	reserve_block => "true",
	testbits => 66,
	tsclkdiv => 1,
	tsclksel => 0)
-- pragma translate_on
PORT MAP (
	soc => \~QUARTUS_CREATED_GND~I_combout\,
	usr_pwd => VCC,
	tsen => \~QUARTUS_CREATED_GND~I_combout\,
	chsel => \~QUARTUS_CREATED_ADC2~_CHSEL_bus\,
	eoc => \~QUARTUS_CREATED_ADC2~~eoc\);

ww_gt_4 <= \gt_4~output_o\;

ww_eq_4 <= \eq_4~output_o\;

ww_lt_4 <= \lt_4~output_o\;
END structure;


