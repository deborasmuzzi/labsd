library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity comparator_4 is
	port(
			a_4, b_4 : in std_logic_vector(3 downto 0);
			gt_4   : out std_logic;
			eq_4   : out std_logic;
			lt_4   : out std_logic
		);
end comparator_4;


architecture arch of comparator_4 is

		-- Component declaration
	component comparator is
		generic(
			data_width : natural := 8
		);
		port(
			a, b : in std_logic_vector((data_width-1) downto 0);
			gt   : out std_logic;
			eq   : out std_logic;
			lt   : out std_logic
		);
	end component;

	signal pin_a, pin_b : std_logic_vector(3 downto 0);
	signal pin_gt, pin_eq, pin_lt : std_logic;

begin 
	
dut: comparator
		generic map(
			data_width => 4
			)
		port map(
			a  => pin_a,
			b  => pin_b,
			gt => pin_gt,
			eq => pin_eq,
			lt => pin_lt
			);


		pin_a <= a_4;
		pin_b <= b_4;
		gt_4 <= pin_gt;
		eq_4 <= pin_eq;
		lt_4 <= pin_lt;



end arch;